"""
To Do:

Hide mouse

"""

import pygame
import random
import math
import os
import pickle
import numpy as np

name = input("Name: ")


try:
    high_scores = pickle.load(open("spark.save", "rb"))
except:
    high_scores = []

unlocked_ships = ["rebelion"]

for i in high_scores:
    if i[0] == name:
        unlocked_ships = i[2]

ship_type = "rebelion"


pygame.init()

clock = pygame.time.Clock()

HEIGHT = 1200
WIDTH = 1920

# Set up the drawing window
screen = pygame.display.set_mode([WIDTH + 6, HEIGHT + 47])


def angle2(pos2, pos1):
    n = 0
    n = math.atan2(pos2[1] - pos1[1], pos2[0] - pos1[0])
    return n - 45 / math.pi


def rect_alpha(x, y, w, h, c):
    rect = pygame.Rect(x, y, w, h)
    shape_surf = pygame.Surface(pygame.Rect(rect).size, pygame.SRCALPHA)
    pygame.draw.rect(shape_surf, c, shape_surf.get_rect())
    screen.blit(shape_surf, rect)


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def add_line(screen, text, x, y, color=(255, 255, 255), size=40):
    # used to print the status of the variables
    font = pygame.font.Font("minecraft_font2.ttf", size)
    text = font.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (int(x / 1200 * WIDTH), int(y / 600 * HEIGHT))
    screen.blit(text, text_rect)


def add_center_line(screen, text, x, y, color=(255, 255, 255), size=40):
    # used to print the status of the variables
    font = pygame.font.Font("minecraft_font2.ttf", size)
    text = font.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.center = (int(x / 1200 * WIDTH), int(y / 600 * HEIGHT))
    screen.blit(text, text_rect)


shoots = []
ships = []
beams = []
explosions = []
posx = 600
posy = 500
operations = False
stage = "choose_ship"
lives = 5
time1 = 0
level = 1
power = 0
stars = []

for i in range(100):
    stars.append(
        [
            random.random() * 1200,
            random.random() * 600,
            random.random() * 5,
            (random.random() * 255, random.random() * 255, random.random() * 255),
        ]
    )

shots = 0
hits = 0
score = 0
ion = 0

STAR_SIZE = 5

do_render = False
accelerate_render = False

level_type = "rebelion"

# "name": [speed, health, fire speed, explode at death, shoot types]

vesels = {
    "rebelion": [1, 1, 1, False, ["plazma"]],
    "engi": [2, 1, 1, False, ["plazma", "ion"]],
    "zolton": [0.7, 1, 1, True, ["plazma"]],
    "rock": [0.3, 1.5, 0.5, False, ["plazma", "missle"]],
    "mantis": [0.7, 1, 1.5, False, ["plazma"]],
    "midnight": [3, 1, 1, False, ["plazma", "warp"]],
    "crystal": [0.6, 1.2, 0.6, True, ["plazma", "plazma", "missle"]],
    "chaos": [2, 1.5, 1.5, False, ["plazma", "time"]],
}

vesels2 = {
    "rebelion": [1, 1, 1, False, ["plazma"]],
    "engi": [1.5, 1, 1, False, ["plazma", "plazma", "ion"]],
    "zolton": [0.8, 1.3, 1.2, True, ["plazma"]],
    "rock": [0.5, 2, 0.75, False, ["plazma", "missle"]],
    "mantis": [0.7, 1, 1.4, False, ["plazma"]],
    "midnight": [2, 1, 1, False, ["plazma", "warp"]],
    "crystal": [0.7, 1.5, 0.85, True, ["plazma", "plazma", "missle"]],
    "chaos": [1.5, 1.5, 1.4, False, ["plazma", "time"]],
}


def probability(probs):
    m = 0
    for i in probs:
        m += i[1]
    for i in probs:
        i[1] /= m
    x = random.random()
    for i in probs:
        if x < i[1]:
            return i[0]
        else:
            x -= i[1]


def explode(i, power):
    this_dir = os.path.dirname(__file__)
    image_file = os.path.join(this_dir, i[4] + ".png")
    image = pygame.image.load(image_file).convert()
    image.set_colorkey((0, 0, 0))
    image = pygame.transform.scale(image, (100, 100))
    rect = image.get_rect()
    rect.center = (
        i[0] / 1200 * WIDTH,
        i[1] / 600 * HEIGHT,
    )
    screen.blit(image, rect)
    for m in range(power * 3):
        try:
            pos = [
                int(i[0] / 1200 * WIDTH + random.random() * 50 - 25),
                int(i[1] * 2 + random.random() * 50 - 25),
            ]
            y = random.random() * 100
            color = screen.get_at(pos)
            if color != (0, 0, 0):
                explosions.append(
                    [
                        pos[0] / WIDTH * 1200,
                        pos[1] / 2,
                        random.random() * 10 + 10,
                        color,
                        math.sin(y) * (random.random() + 1) * 2,
                        math.cos(y) * (random.random() + 1) * 2,
                    ]
                )
        except:
            pass
    screen.fill((0, 0, 0))


# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((0, 0, 0))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    if keys[pygame.K_m]:
        if keys[pygame.K_i]:
            if keys[pygame.K_c]:
                operations = True

    time1 += 1

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if stage == "play":
        for i in explosions:
            if random.random() > 0.975:
                explosions.remove(i)
        if keys[pygame.K_p]:
            stage = "paused"
        if not ion:
            if keys[pygame.K_a]:
                posx -= 5 * vesels2[ship_type][0]
            if keys[pygame.K_d]:
                posx += 5 * vesels2[ship_type][0]
            if keys[pygame.K_w]:
                posy -= 5 * vesels2[ship_type][0]
            if keys[pygame.K_s]:
                posy += 5 * vesels2[ship_type][0]

        ion -= 1
        if ion < 0:
            ion = 0

        if time1 < 4 and not level % 5 == 0:
            ships.append([random.random() * 1000 + 100, -50, 0, 0, level_type, 0, 0])
        if time1 == 1 and level % 5 == 0:
            ships.append(
                [
                    600,
                    -25,
                    0,
                    0,
                    level_type,
                    int((level * 2 + 15) * vesels[level_type][1]),
                    0,
                ]
            )
            boss_start_health = int((level * 2 + 15) * vesels[level_type][1])

        posx = min(posx, 1200)
        posx = max(posx, 0)

        posy = min(posy, 570)
        posy = max(posy, 300)

        if not time1 % int(1000 / (level / 2 + 1.5)) and not level % 5 == 0:
            for i in range(3):
                ships.append(
                    [random.random() * 1000 + 100, -50, 0, 0, level_type, 0, 0]
                )
        elif not time1 % int(1000 / (level / 2 + 1.5)) and level % 5 == 0:
            for i in range(2):
                ships.append(
                    [random.random() * 1000 + 100, -50, 0, 0, level_type, 0, 0]
                )

        for i in ships:
            prob = 1
            if i[5]:
                prob = 2.5
            if random.random() < 0.003 * vesels[i[4]][2] * prob and not i[6]:
                if random.random() < 0.5:
                    shoots.append(
                        [
                            i[0],
                            i[1],
                            (posx - i[0]) / dis((i[0], i[1]), (posx, posy)) * 3,
                            (posy - i[1]) / dis((i[0], i[1]), (posx, posy)) * 3,
                            random.choice(vesels[i[4]][4]),
                        ]
                    )
                elif random.random() < 0.5:
                    shot_type = random.choice(vesels[i[4]][4])
                    for k in range(0, 6):
                        shoots.append(
                            [
                                i[0],
                                i[1],
                                math.cos(k / 5 * math.pi) * 3,
                                math.sin(k / 5 * math.pi) * 3,
                                shot_type,
                            ]
                        )
                else:
                    angle = random.random()
                    shot_type = random.choice(vesels[i[4]][4])
                    for k in range(0, 4):
                        shoots.append(
                            [
                                i[0],
                                i[1],
                                math.cos(k / 40 * math.pi + angle * math.pi) * 6,
                                math.sin(k / 40 * math.pi + angle * math.pi) * 6,
                                shot_type,
                            ]
                        )
            i[6] -= 1
            if i[6] < 0:
                i[6] = 0
            if not i[6]:
                i[0] += i[2]
                i[1] += i[3]
                if dis((i[2], i[3]), (0, 0)) > 5:
                    i[2] *= 0.95
                    i[3] *= 0.95
                if i[1] > 400:
                    i[3] -= 0.05
                i[0] = i[0] % 1200
                if i[1] < 0:
                    i[1] += 0.1
                    i[3] += 0.01
                if i[0] < 100:
                    i[2] += 0.05
                if i[0] > 1100:
                    i[2] -= 0.05
                i[2] += (random.random() * 0.1 - 0.05) * vesels[i[4]][0]
                i[3] += (random.random() * 0.1 - 0.05) * vesels[i[4]][0]
            if dis((i[0], i[1]), (posx, posy)) < 40:
                if random.random() < 1 / vesels2[ship_type][1]:
                    stage = "shot"
                    time1 = 0
                if not i[5]:
                    explode(i, 10)
                    ships.remove(i)

        for i in ships:
            for j in beams:
                new_dis = 30
                if i[5]:
                    new_dis = 60
                if dis((i[0], i[1]), (j[0], j[1])) < new_dis:
                    if j[4] == "ion":
                        if 1 / vesels[i[4]][1] > random.random():
                            i[6] = 250
                        beams.remove(j)
                        break
                    if 1 / vesels[i[4]][1] > random.random() and not i[5]:
                        if random.random() > 0.5 and vesels[i[4]][3]:
                            if i[4] == "zolton":
                                shot_type = random.choice(vesels[i[4]][4])
                                for k in range(0, 6):
                                    shoots.append(
                                        [
                                            i[0],
                                            i[1],
                                            math.cos(k / 6 * math.pi * 2) * 3,
                                            math.sin(k / 6 * math.pi * 2) * 3,
                                            shot_type,
                                        ]
                                    )
                            elif i[4] == "crystal":
                                shoots.append(
                                    [
                                        i[0],
                                        i[1],
                                        (posx - i[0])
                                        / dis((i[0], i[1]), (posx, posy))
                                        * 6,
                                        (500 - i[1])
                                        / dis((i[0], i[1]), (posx, posy))
                                        * 6,
                                        random.choice(vesels[i[4]][4]),
                                    ]
                                )
                        explode(i, 10)
                        ships.remove(i)
                    elif i[5]:
                        if i[5] > 1:
                            i[5] -= 1
                        elif i[5] == 1 or i[5] == 2:
                            time1 = 1
                            if i[4] == "zolton":
                                shot_type = random.choice(vesels[i[4]][4])
                                for k in range(0, 15):
                                    shoots.append(
                                        [
                                            i[0],
                                            i[1],
                                            math.cos(k / 15 * math.pi * 2) * 3,
                                            math.sin(k / 15 * math.pi * 2) * 3,
                                            shot_type,
                                        ]
                                    )
                            elif i[4] == "crystal":
                                for k in range(10):
                                    shoots.append(
                                        [
                                            i[0],
                                            i[1],
                                            (posx - i[0])
                                            / dis((i[0], i[1]), (posx, posy))
                                            * 6
                                            + random.random() * 2
                                            - 1,
                                            (500 - i[1])
                                            / dis((i[0], i[1]), (posx, posy))
                                            * 6
                                            + random.random() * 2
                                            - 1,
                                            random.choice(vesels[i[4]][4]),
                                        ]
                                    )
                            explode(i, 90)
                            ships.remove(i)
                    beams.remove(j)
                    hits += 1
                    break

        for i in shoots:
            if i[4] == "ion":
                i[0] += i[2] * 3.5
                i[1] += i[3] * 3.5
            elif i[4] == "missle":
                i[0] += i[2] * 0.5
                i[1] += i[3] * 0.5
                i[2] += (posx - i[0]) / dis((posx, posy), (i[0], i[1])) / 20
                i[3] += (posy - i[1]) / dis((posx, posy), (i[0], i[1])) / 20
                if dis((i[2], i[3]), (0, 0)) > 10:
                    i[2] *= 0.95
                    i[3] *= 0.95
            elif i[4] == "warp":
                i[0] += i[2] * 0.5
                i[1] += i[3] * 0.5
                posx += (i[0] - posx) / abs(i[0] - posx) / 3 / vesels2[ship_type][1]
            elif i[4] == "time":
                i[0] += i[2] * 0.5
                i[1] += i[3] * 0.5
                if (
                    random.random() > dis((i[0], i[1]), (posx, posy)) / 750 + 0.5
                    and random.random() > 0.5
                    and ion == 0
                ):
                    ion = 1
            else:
                i[0] += i[2]
                i[1] += i[3]
            if dis((i[0], i[1]), (posx, posy)) < 20:
                if i[4] == "ion":
                    if 1 / vesels2[ship_type][1] > random.random():
                        ion = 70
                    shoots.remove(i)
                    continue
                elif i[4] == "warp" or i[4] == "time":
                    shoots.remove(i)
                    continue
                else:
                    if 1 / vesels2[ship_type][1] > random.random():
                        stage = "shot"
                        time1 = 0
                    else:
                        shoots.remove(i)
                        continue
            if i[0] % 1200 != i[0] or i[1] % 600 != i[1]:
                shoots.remove(i)

        power += 1.35 * vesels2[ship_type][2]
        if power > 255:
            power = 255

        if (
            keys[pygame.K_SPACE]
            and power > 50
            and time1 % int(10 / vesels2[ship_type][2]) == 0
            and not ion
        ):
            beams.append([posx, posy, 0, -7, random.choice(vesels2[ship_type][4])])
            power -= 30
            shots += 1
            if power < 50:
                power = 0

        for i in beams:
            if i[4] == "ion":
                i[0] += i[2] * 3.5
                i[1] += i[3] * 3.5
            elif i[4] == "missle":
                i[0] += i[2] * 0.5
                i[1] += i[3] * 0.5
                if dis((i[2], i[3]), (0, 0)) > 10:
                    i[2] *= 0.95
                    i[3] *= 0.95
            elif i[4] == "warp":
                i[0] += i[2] * 0.5
                i[1] += i[3] * 0.5
            elif i[4] == "time":
                i[0] += i[2] * 0.5
                i[1] += i[3] * 0.5
            else:
                i[0] += i[2]
                i[1] += i[3]
            n = (600, -1000)
            for j in ships:
                if dis((i[0], i[1]), (j[0], j[1])) < dis((i[0], i[1]), n):
                    n = (j[0], j[1])
                if i[4] == "warp":
                    j[0] += (i[0] - j[0]) / abs(i[0] - j[0]) / 3 / vesels[j[4]][1]
                elif (
                    i[4] == "time"
                    and j[6] == 0
                    and random.random() > dis((i[0], i[1]), (j[0], j[1])) / 750 + 0.5
                ):
                    j[6] = 2
            if i[4] == "missle":
                i[2] += (n[0] - i[0]) / dis(n, (i[0], i[1])) / 5
                i[3] += (n[1] - i[1]) / dis(n, (i[0], i[1])) / 5
            if (i[0] + 100) % 1400 != i[0] + 100 or (i[1] + 100) % 800 != i[1] + 100:
                beams.remove(i)

        for i in stars:
            i[1] += i[2]
            if i[1] > 600:
                i[0] = random.random() * 1200
                i[1] = i[1] % 600

        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)

        for i in explosions:
            i[0] += i[4]
            i[1] += i[5]

        do_render = True

        add_line(screen, f"Lives: {lives}", 0, 0, size=30)

        add_line(
            screen,
            f"Power bar {int(power / 255 * 100)}%",
            0,
            40,
            size=30,
            color=(power, power, 255 - power),
        )
        boss_there = False
        boss_health = 0
        for i in ships:
            if i[5]:
                boss_there = True
                boss_health = i[5] / boss_start_health
        if not boss_there:
            add_line(
                screen,
                f"FTL drive {int(time1 / 1950 * 100)}% charged",
                0,
                120,
                size=30,
                color=(
                    time1 / 1950 * 255 / 2,
                    255 - time1 / 1950 * 255,
                    time1 / 1950 * 255,
                ),
            )
        else:
            add_line(
                screen,
                f"Boss health {int(boss_health * 100)}%",
                0,
                120,
                size=30,
                color=(
                    boss_health * 255 / 2,
                    255 - boss_health * 255,
                    boss_health * 255,
                ),
            )
        if time1 > 1950 and level % 5 != 0:
            stage = "stats"
            time1 = 0
            ion = 0
        elif level % 5 == 0 and not boss_there and time1 % 200 == 0:
            stage = "stats"
            time1 = 0
            ion = 0
            if level_type not in unlocked_ships and level > 5:
                unlocked_ships.append(level_type)
    elif stage == "paused":
        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)
        add_center_line(screen, "Paused", 600, 250)
        if keys[pygame.K_RETURN]:
            stage = "play"
        time1 -= 1
    elif stage == "start":
        for i in stars:
            i[1] += i[2] * 3
            if i[1] > 600:
                i[0] = random.random() * 1200
                i[1] = i[1] % 600
        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)
        if time1 < 100:
            add_center_line(screen, "Get ready!", 600, 250)
        elif time1 < 150:
            add_center_line(
                screen,
                "Go!",
                600,
                250,
                color=(
                    random.random() * 255,
                    random.random() * 255,
                    random.random() * 255,
                ),
            )
        else:
            stage = "leveling"
            time1 = 0
            hits = 0
            shots = 0
    elif stage == "leveling":
        for i in stars:
            i[1] += i[2] * 3
            if i[1] > 600:
                i[0] = random.random() * 1200
                i[1] = i[1] % 600
        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)

        do_render = True
        accelerate_render = True

        add_line(screen, f"Lives: {lives}", 0, 0, size=30)
        if time1 < 100:
            add_center_line(
                screen,
                f"Level {level}",
                600,
                250,
                color=(
                    random.random() * 255,
                    random.random() * 255,
                    random.random() * 255,
                ),
            )
        else:
            stage = "play"
            time1 = 0
            shoots = []
            ships = []
            beams = []
    elif stage == "shot":
        for i in stars:
            i[1] -= i[2] * 3
            if i[1] < 0:
                i[0] = random.random() * 1200
                i[1] = i[1] % 600
        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)

        do_render = True

        if time1 == 50:
            lives -= 1

        add_line(screen, f"Lives: {lives}", 0, 0, size=30)
        if time1 < 100:
            add_center_line(
                screen,
                "You lost a life.",
                600,
                250,
                color=(random.random() * 255, 0, 0),
            )
        else:
            if lives != 0:
                stage = "leveling"
                time1 = 0
                shoots = []
                ships = []
                beams = []
                ion = 0
            else:
                stage = "gameover"
                time1 = 0
    elif stage == "stats":
        for i in stars:
            i[1] += i[2] * 3
            if i[1] > 600:
                i[0] = random.random() * 1200
                i[1] = i[1] % 600
        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)

        do_render = True
        accelerate_render = True

        if not 495 < posy < 505:
            posy -= (posy - 500) / abs(posy - 500) * 3
        if not 595 < posx < 605:
            posx -= (posx - 600) / abs(posx - 600) * 3

        add_line(screen, f"Lives: {lives}", 0, 0, size=30)
        if 150 > time1 > 25:
            add_line(
                screen,
                "Stats:",
                500,
                100,
                color=(255, 255, 255),
            )
        if 175 > time1 > 50:
            add_line(
                screen,
                f"Shots: {shots}",
                500,
                150,
                color=(255, 255, 255),
            )
        if 200 > time1 > 75:
            add_line(
                screen,
                f"Hits: {hits}",
                500,
                200,
                color=(255, 255, 255),
            )
        if 225 > time1 > 100 and shots:
            if hits / shots < 0.4:
                add_line(
                    screen,
                    f"Accuracy: {int(hits / shots * 100)}%",
                    500,
                    250,
                    color=(255, 255, 255),
                )
            elif hits / shots < 0.6:
                add_line(
                    screen,
                    f"Accuracy: {int(hits / shots * 100)}%",
                    500,
                    250,
                    color=(
                        255 * random.random(),
                        255 * random.random(),
                        255 * random.random(),
                    ),
                )
            else:
                add_line(
                    screen,
                    f"Accuracy: {int(hits / shots * 100)}% ULTRA",
                    500,
                    250,
                    color=(
                        0,
                        255 * random.random(),
                        255 * random.random(),
                    ),
                )
        if time1 > 100 and shots:
            score += hits**2 / shots / 5 * level
        if time1 > 250:
            stage = "leveling"
            if lives < 5 and level % 5 == 0:
                lives += 1
            level += 1
            time1 = 0
            shoots = []
            ships = []
            beams = []
            hits = 0
            shots = 0
            level_type = probability(
                [
                    ["rebelion", 1],
                    ["engi", 1],
                    ["rock", 1],
                    ["mantis", 1],
                    ["zolton", 1],
                    ["crystal", 1],
                    ["midnight", 0.5],
                    ["chaos", 0.1],
                ]
            )
    elif stage == "choose_ship":
        for i in stars:
            i[1] += i[2] * 4
            if i[1] > 600:
                i[0] = random.random() * 1200
                i[1] = i[1] % 600
        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)
        add_center_line(
            screen,
            "Choose your ship:",
            600,
            200,
            color=(
                (time1 - 200) * 1.1 % 255,
                (time1 - 200) * 3.654 % 255,
                (time1 - 200) * 2 % 255,
            ),
        )
        for i in range(len(unlocked_ships)):
            if (
                i * 100 + WIDTH / 2 - len(unlocked_ships) * 50
                < mx
                < i * 100 + WIDTH / 2 - len(unlocked_ships) * 50 + 100
            ):
                if 550 < my < 650:
                    map1 = pygame.Rect(
                        i * 100 + WIDTH / 2 - len(unlocked_ships) * 50,
                        550,
                        100,
                        100,
                    )
                    pygame.draw.rect(screen, (128, 255, 255), map1)
                    if mouse_held[0]:
                        ship_type = unlocked_ships[i]
                        stage = "start"
                        time1 = 0

            this_dir = os.path.dirname(__file__)
            if unlocked_ships[i] == "rebelion":
                image_file = os.path.join(this_dir, "ship.png")
            else:
                image_file = os.path.join(this_dir, unlocked_ships[i] + ".png")
            image = pygame.image.load(image_file).convert()
            image.set_colorkey((0, 0, 0))
            image = pygame.transform.scale(image, (100, 100))
            if unlocked_ships[i] == "rebelion":
                image = pygame.transform.rotate(image, 180)
            rect = image.get_rect()
            rect.center = (i * 100 + WIDTH / 2 - len(unlocked_ships) * 50 + 50, 600)
            screen.blit(image, rect)
    elif stage == "gameover":
        for i in stars:
            i[1] += i[2] * 6
            if i[1] > 600:
                i[0] = random.random() * 1200
                i[1] = i[1] % 600
        for i in stars:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH, i[1] / 600 * HEIGHT, i[2] * 2 + 1, i[2] * 2 + 1
            )
            pygame.draw.rect(screen, i[3], map1)
        if time1 > 200:
            add_center_line(
                screen,
                "press space to play again",
                600,
                500,
                color=(
                    (time1 - 200) * 1.1 % 255,
                    (time1 - 200) * 3.654 % 255,
                    (time1 - 200) * 2 % 255,
                ),
            )

        add_center_line(
            screen,
            "Game Over",
            600,
            250,
            color=(
                255,
                255,
                255,
            ),
        )
        if time1 < 100:
            add_center_line(
                screen,
                "Score: " + str(int(min(score / 100 * time1, score))),
                600,
                400,
                color=(
                    255,
                    255,
                    255,
                ),
            )
        else:
            add_center_line(
                screen,
                "Score: " + str(int(min(score / 100 * time1, score))),
                600,
                400,
                color=(
                    random.random() * 255,
                    random.random() * 255,
                    random.random() * 255,
                ),
            )
        if keys[pygame.K_SPACE] and time1 > 200:
            has_scores = False
            for i in high_scores:
                if i[0] == name:
                    has_scores = True
                    if score > i[1]:
                        i[1] = score

            if not has_scores:
                high_scores.append([name, score])
            stage = "choose_ship"

            shoots = []
            ships = []
            beams = []
            posx = 600
            posy = 500
            lives = 5
            time1 = 0
            level = 1
            power = 0
            score = 0
            level_type = "rebelion"

    if do_render:
        for i in explosions:
            map1 = pygame.Rect(
                i[0] / 1200 * WIDTH,
                i[1] / 600 * HEIGHT + accelerate_render * time1**2 / 4 / 600 * HEIGHT,
                i[2],
                i[2],
            )
            pygame.draw.rect(screen, i[3], map1)
        for i in beams:
            this_dir = os.path.dirname(__file__)
            image_file = os.path.join(this_dir, i[4] + ".png")
            image = pygame.image.load(image_file).convert()
            image.set_colorkey((0, 0, 0))
            image = pygame.transform.scale(image, (100, 100))
            image = pygame.transform.rotate(
                image, 360 - angle2([i[2], i[3]], [0, 0]) / math.pi * 180 - 11.5
            )
            rect = image.get_rect()
            rect.center = (
                i[0] / 1200 * WIDTH,
                i[1] / 600 * HEIGHT
                + 50
                + accelerate_render * time1**2 / 4 / 600 * HEIGHT,
            )
            screen.blit(image, rect)

        for i in ships:
            this_dir = os.path.dirname(__file__)
            image_file = os.path.join(this_dir, i[4] + ".png")
            image = pygame.image.load(image_file).convert()
            image.set_colorkey((0, 0, 0))
            if not i[5]:
                image = pygame.transform.scale(image, (100, 100))
            else:
                image = pygame.transform.scale(image, (300, 300))
            if i[6] > 2:
                image = pygame.transform.rotate(image, time1 * 10)
            rect = image.get_rect()
            rect.center = (
                i[0] / 1200 * WIDTH,
                i[1] / 600 * HEIGHT
                + 50
                + accelerate_render * time1**2 / 4 / 600 * HEIGHT,
            )
            screen.blit(image, rect)

        for i in shoots:
            this_dir = os.path.dirname(__file__)
            image_file = os.path.join(this_dir, i[4] + ".png")
            image = pygame.image.load(image_file).convert()
            image.set_colorkey((0, 0, 0))
            image = pygame.transform.scale(image, (100, 100))
            image = pygame.transform.rotate(
                image, 360 - angle2([i[2], i[3]], [0, 0]) / math.pi * 180 - 11.5
            )
            rect = image.get_rect()
            rect.center = (
                i[0] / 1200 * WIDTH,
                i[1] / 600 * HEIGHT
                + 15
                + accelerate_render * time1**2 / 4 / 600 * HEIGHT,
            )
            screen.blit(image, rect)

        this_dir = os.path.dirname(__file__)
        if ship_type == "rebelion":
            image_file = os.path.join(this_dir, "ship.png")
        else:
            image_file = os.path.join(this_dir, ship_type + ".png")
        image = pygame.image.load(image_file).convert()
        image.set_colorkey((0, 0, 0))
        image = pygame.transform.scale(image, (100, 100))
        if ion > 1:
            image = pygame.transform.rotate(image, time1 * 10)
        else:
            if not ship_type == "rebelion":
                image = pygame.transform.rotate(image, 180)
        rect = image.get_rect()
        rect.center = (posx / 1200 * WIDTH, posy / 600 * HEIGHT)
        screen.blit(image, rect)

    do_render = False
    accelerate_render = False

    if stage not in ["gameover", "start", "choose_ship"]:
        add_line(screen, f"Score: {int(score)}", 0, 80, size=30)
        add_line(screen, f"Level: {level}", 0, 160, size=30)

    if stage not in ["play", "shot", "paused"]:
        explosions = []

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()

has_scores = False
for i in high_scores:
    if i[0] == name:
        has_scores = True
        if score > i[1]:
            i[1] = score

if not has_scores:
    high_scores.append([name, score, unlocked_ships])

# get sorted score indices
indices = np.argsort([score for name, score, ship1 in high_scores])[::-1]

print()
print("########## High Scores ##########")
for index in indices:
    name, score, ship1 = high_scores[index]
    print(f"{name:15s}   {int(score):15d}")

if operations:
    while True:
        np = input("Operations? ")
        if np:
            if np == "c":
                lk = input("Change which high score? ")
                for i in high_scores:
                    if i[0] == lk:
                        i[1] = int(input("New number? "))
            elif np == "n":
                lk = input("New high score name? ")
                high_scores.append([lk, input("Number? ")])
            elif np == "d":
                lk = input("Delete which high score? ")
                for i in high_scores:
                    if i[0] == lk:
                        if input("Are you sure (y/n)") == "y":
                            high_scores.remove(i)
            elif np == "s":
                for i in high_scores:
                    print(f"high score for {i[0]}: {i[1]}")
            elif np == "m":
                pos = input("Which high score? ")
                for i in high_scores:
                    if i[0] == pos:
                        lk = input("add or remove [a/r]? ").lower()
                        if lk == "a":
                            m = input("add which ship option? ")
                            if m not in i[2]:
                                i[2].append(m)
                        elif lk == "r":
                            m = input("remove which ship option? ")
                            if m in i[2]:
                                i[2].remove(m)
            elif np == "h":
                print("""
                c: change high scores
                n: add new high scores
                d: delete high scores
                s: display high scores
                m: change ship options
                h: display help
                """)
        else:
            print("Saving changes")
            break


pickle.dump(high_scores, open("spark.save", "wb"))
