import pygame
import random
import math

pygame.init()

clock = pygame.time.Clock()

screenx = 1900
screeny = 1200

# Set up the drawing window
screen = pygame.display.set_mode([screenx, screeny])

size = 100


blocks = []

chunks = {}

seed = []

for i in range(30):
    seed.append(
        [
            (random.random() ** 2 * 30 + 2) / 4,
            random.random() * 100,
            random.random() * 100,
        ]
    )

seed3d = []

for i in range(30):
    seed3d.append(
        [
            (random.random() ** 2 * 30 + 2) / 4,
            random.random() * 100,
        ]
    )


def add_line(
    screen,
    text,
    x,
    y,
    color=(255, 0, 255),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 30),
):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def dis3d(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    z = (pos2[2] - pos1[2]) ** 2
    return (x + y + z) ** 0.5


def chunker(z, y, x):
    return (
        str(neg_int(z - z % 16))
        + " "
        + str(neg_int(y - y % 16))
        + " "
        + str(neg_int(x - x % 16))
    )


def rs(z, y, x):
    chunker1 = chunker(z, y, x)
    z1 = z % 16
    y1 = y % 16
    x1 = x % 16
    if chunker1 not in chunks:
        chunks.update({chunker1: build_chunk(z, y, x)})
    return chunks[chunker1][z1][y1][x1]


def ac(z, y, x, type1):
    chunker1 = chunker(z, y, x)
    z1 = z % 16
    y1 = y % 16
    x1 = x % 16
    if chunker1 not in chunks:
        chunks.update({chunker1: build_chunk(z, y, x)})
    chunks[chunker1][z1][y1][x1][3] = type1


def build_chunk(z, y, x):
    z1 = z % 16
    y1 = y % 16
    x1 = x % 16
    blocks1 = []
    height_map = []
    for j in range(16):
        o = []
        for i in range(16):
            height = 0
            for k in seed:
                height += (
                    math.sin(
                        (
                            (x + i - x1) / 10 * math.sin(k[2])
                            + (z + j - z1) / 10 * math.cos(k[2])
                        )
                        / k[0]
                        + k[1]
                    )
                    * 5
                    / 2
                )
            height2 = 0
            for k in seed:
                height2 += (
                    math.sin(
                        (
                            (x + i - x1 + 100000000) / 10 * math.sin(k[2])
                            + (z + j - z1) / 10 * math.cos(k[2])
                        )
                        / k[0]
                        + k[1]
                    )
                    * 5
                    / 2
                )
            height3 = 0
            for k in seed:
                height3 += (
                    math.sin(
                        (
                            (x + i - x1 + 1000000000) / 10 * math.sin(k[2])
                            + (z + j - z1) / 10 * math.cos(k[2])
                        )
                        / k[0]
                        + k[1]
                    )
                    * 5
                    / 2
                )
            o.append([height, height2, height3])
        height_map.append(o)

    for k in range(16):
        o = []
        for j in range(16):
            cave = 0
            for g in seed3d:
                cave += math.sin(g[0] * (j + y - y1) / 10 + g[1])
            cave2 = 0
            for g in seed3d:
                cave2 += math.sin(g[0] * (j + y - y1 + 100000) / 10 + g[1])
            p = []
            for i in range(16):
                n = 0
                if j + y - y1 > height_map[k][i][0]:
                    n = 1
                if height_map[k][i][0] + 5 > j + y - y1 > height_map[k][i][0]:
                    n = 2
                if (
                    height_map[k][i][0] + 1 > j + y - y1 > height_map[k][i][0]
                    and not j + y - y1 > 0
                ):
                    n = 3
                if (
                    2 > cave + height_map[k][i][2] > -2
                    and 2 > cave2 + height_map[k][i][1] > -2
                ):
                    n = 0
                if j + y - y1 <= height_map[k][i][0] and j + y - y1 > 0:
                    n = 4
                if n == 0:
                    if (
                        height_map[k][i][0] - 5 < j + y - y1 <= height_map[k][i][0]
                        and height_map[k][i][0] <= 0
                    ):
                        if height_map[k][i][0] % 1 < 0.01:
                            n = 5
                p.append([i, j, k, n])
            o.append(p)
        blocks1.append(o)
    return blocks1


def neg_int(numb):
    return int(numb - (numb % 1))


mobs = []

posx = 5
posy = -30
posz = 5
vely = 0

colors = {
    0: (255, 255, 255),
    1: (128, 128, 128),
    2: (128, 75, 0),
    3: (0, 200, 0),
    4: (0, 0, 255),
    5: (150, 100, 50),
}

selection = [1, 2, 3, 5]
select = 0

flows = [0, 4]

held = False

veiw = 0

see_range = 26

health = 100

speed = 0.0999

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((255, 255, 255))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    if health <= 0:
        running = False
    if health < 100:
        health += 0.01

    n = 0
    if veiw != 2:
        if keys[pygame.K_a]:
            n = -speed
        if keys[pygame.K_d]:
            n = speed
    else:
        if keys[pygame.K_LSHIFT]:
            n = -speed
        if keys[pygame.K_SPACE]:
            n = speed

    if not held and keys[pygame.K_TAB]:
        veiw = (veiw + 1) % 3
        held = True

    if not held and keys[pygame.K_e]:
        select = (select - 1) % len(selection)
        held = True
    if not held and keys[pygame.K_r]:
        select = (select + 1) % len(selection)
        held = True

    if not keys[pygame.K_TAB] and not keys[pygame.K_e] and not keys[pygame.K_r]:
        held = False

    if rs(neg_int(posz), neg_int(posy), neg_int((posx + n)))[3] in flows:
        posx += n

    n = 0
    if veiw == 0:
        if keys[pygame.K_LSHIFT]:
            n = -speed
        if keys[pygame.K_SPACE]:
            n = speed
    elif veiw == 1:
        if keys[pygame.K_w]:
            n = -speed
        if keys[pygame.K_s]:
            n = speed
    elif veiw == 2:
        if keys[pygame.K_a]:
            n = -speed
        if keys[pygame.K_d]:
            n = speed

    if rs(neg_int((posz + n)), neg_int(posy), neg_int(posx))[3] in flows:
        posz += n

    if rs(neg_int(posz), neg_int(posy), neg_int(posx))[3] != 4:
        vely += 0.01
    else:
        vely += 0.003

    n = vely

    if rs(neg_int(posz), neg_int((posy + n)), neg_int(posx))[3] in flows:
        posy += n
        if rs(neg_int(posz), neg_int((posy + n)), neg_int(posx))[3] == 4:
            if (keys[pygame.K_w] and veiw != 1) or (keys[pygame.K_SPACE] and veiw == 1):
                vely = -0.1
    else:
        n = vely
        vely = 0
        if (
            (keys[pygame.K_w] and veiw != 1) or (keys[pygame.K_SPACE] and veiw == 1)
        ) and n >= 0:
            vely = -0.175

    if veiw == 0:
        z = neg_int(posz)
        y = neg_int(((my - screeny / 2) / size + posy))
        x = neg_int(((mx - screenx / 2) / size + posx))
    elif veiw == 1:
        z = neg_int(((my - screeny / 2) / size + posz))
        y = neg_int(posy)
        x = neg_int(((mx - screenx / 2) / size + posx))
    elif veiw == 2:
        z = neg_int(((mx - screenx / 2) / size + posz))
        y = neg_int(((my - screeny / 2) / size + posy))
        x = neg_int(posx)

    if mouse_held[0]:
        ac(z, y, x, selection[select])
    if mouse_held[2]:
        ac(z, y, x, 0)

    if random.random() > 0.9:
        z = neg_int(posz + random.random() * 100 - 50)
        y = neg_int(posy + random.random() * 100 - 50)
        x = neg_int(posx + random.random() * 100 - 50)
        if (
            rs(z, y, x)[3] == 0
            and rs(z, y + 1, x)[3] not in flows
            and dis3d((z, y, x), (0, 0, 0)) > 20
        ):
            mobs.append([x, y, z, 0, 0, 0])

    for i in mobs:
        distance = dis3d((i[0], i[1], i[2]), (posx, posy, posz))
        if distance < 0.7:
            health -= 0.5

        xv = i[4]
        if random.random() > 0.95 and distance < 10:
            if posx > i[0]:
                i[4] = 0.08
            else:
                i[4] = -0.08
        zv = i[5]
        if random.random() > 0.95 and distance < 10:
            if posz > i[2]:
                i[5] = 0.08
            else:
                i[5] = -0.08

        if rs(neg_int(i[2]), neg_int(i[1]), neg_int(i[0] + xv))[3] in flows:
            i[0] += xv

        if rs(neg_int(i[2] + zv), neg_int(i[1]), neg_int(i[0]))[3] in flows:
            i[2] += zv

        if rs(neg_int(i[2]), neg_int(i[1]), neg_int(i[0]))[3] != 4:
            i[3] += 0.01
        else:
            i[3] += 0.003

        n = i[3]

        if rs(neg_int(i[2]), neg_int((i[1] + n)), neg_int(i[0]))[3] in flows:
            i[1] += n
            if rs(neg_int(i[2]), neg_int((i[1] + n)), neg_int(i[0]))[3] == 4:
                if posy < i[1] and distance < 10:
                    i[3] = -0.1
        else:
            n = i[3]
            i[3] = 0
            if posy < i[1] and n >= 0 and distance < 10:
                i[3] = -0.175

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if veiw == 0:
        for j in range(see_range):
            for i in range(see_range):
                m = rs(
                    neg_int(posz),
                    neg_int(posy + j - see_range / 2),
                    neg_int(posx + i - see_range / 2),
                )
                map1 = pygame.Rect(
                    neg_int(posx + i - see_range / 2) * size
                    - posx * size
                    + screenx / 2,
                    neg_int(posy + j - see_range / 2) * size - posy * 100 + screeny / 2,
                    size + 1,
                    size + 1,
                )
                pygame.draw.rect(screen, colors[m[3]], map1)

        for i in mobs:
            if dis((0, posz), (0, i[2])) < 0.5:
                map1 = pygame.Rect(
                    screenx / 2 - size / 4 + i[0] * size - posx * size,
                    screeny / 2 - size + i[1] * size - posy * size,
                    size / 2,
                    size,
                )
                pygame.draw.rect(screen, (0, 255, 0), map1)

        map1 = pygame.Rect(
            screenx / 2 - size / 4,
            screeny / 2 - size,
            size / 2,
            size,
        )
        pygame.draw.rect(screen, (255, 0, 0), map1)
    elif veiw == 1:
        for j in range(see_range):
            for i in range(see_range):
                m = rs(
                    neg_int(posz + j - see_range / 2),
                    neg_int(posy),
                    neg_int(posx + i - see_range / 2),
                )
                map1 = pygame.Rect(
                    neg_int(posx + i - see_range / 2) * size
                    - posx * size
                    + screenx / 2,
                    neg_int(posz + j - see_range / 2) * size - posz * 100 + screeny / 2,
                    size + 1,
                    size + 1,
                )
                pygame.draw.rect(screen, colors[m[3]], map1)

        for i in mobs:
            if dis((0, posy), (0, i[1])) < 0.5:
                map1 = pygame.Rect(
                    screenx / 2 - size / 4 + i[0] * size - posx * size,
                    screeny / 2 - size / 4 + i[2] * size - posz * size,
                    size / 2,
                    size / 2,
                )
                pygame.draw.rect(screen, (0, 255, 0), map1)

        map1 = pygame.Rect(
            screenx / 2 - size / 4,
            screeny / 2 - size / 4,
            size / 2,
            size / 2,
        )
        pygame.draw.rect(screen, (255, 0, 0), map1)
    elif veiw == 2:
        for j in range(see_range):
            for i in range(see_range):
                m = rs(
                    neg_int(posz + i - see_range / 2),
                    neg_int(posy + j - see_range / 2),
                    neg_int(posx),
                )
                map1 = pygame.Rect(
                    neg_int(posz + i - see_range / 2) * size
                    - posz * size
                    + screenx / 2,
                    neg_int(posy + j - see_range / 2) * size - posy * 100 + screeny / 2,
                    size + 1,
                    size + 1,
                )
                pygame.draw.rect(screen, colors[m[3]], map1)

        for i in mobs:
            if dis((0, posx), (0, i[0])) < 0.5:
                map1 = pygame.Rect(
                    screenx / 2 - size / 4 + i[2] * size - posz * size,
                    screeny / 2 - size + i[1] * size - posy * size,
                    size / 2,
                    size,
                )
                pygame.draw.rect(screen, (0, 255, 0), map1)

        map1 = pygame.Rect(
            screenx / 2 - size / 4,
            screeny / 2 - size,
            size / 2,
            size,
        )
        pygame.draw.rect(screen, (255, 0, 0), map1)

    map1 = pygame.Rect(
        screenx / 4,
        screeny * 0.8,
        screenx / 2 * health / 100,
        20,
    )
    pygame.draw.rect(screen, (255, 0, 0), map1)

    add_line(screen, str(veiw), 0, 0)
    add_line(screen, str(select), 0, 30)
    add_line(
        screen,
        str(neg_int(posx)) + ", " + str(neg_int(posy)) + ", " + str(neg_int(posz)),
        0,
        60,
    )

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
