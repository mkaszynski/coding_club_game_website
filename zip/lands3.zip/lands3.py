import pygame
import random
import time
import math

pygame.init()

clock = pygame.time.Clock()

# Set up the drawing window
screen = pygame.display.set_mode([1800, 900])

seed = []

for i in range(30):
    seed.append(
        [
            (random.random() ** 2 * 30 + 2) / 4,
            random.random() * 100,
            random.random() * 100,
        ]
    )


def word():
    consanents = [
        "b",
        "c",
        "d",
        "f",
        "g",
        "h",
        "j",
        "k",
        "l",
        "m",
        "n",
        "p",
        "qu",
        "r",
        "s",
        "t",
        "v",
        "w",
        "x",
        "y",
        "z",
    ]

    vouels = ["a", "e", "i", "o", "u", "y"]
    leter = random.choice(consanents + vouels)

    word = leter

    for i in range(int(random.random() * 3) + 1):
        if leter in consanents:
            leter = random.choice(vouels)
            word += leter
        if leter in vouels:
            leter = random.choice(consanents)
            word += leter

    if leter == "i":
        word.replace("i", "y")
    elif leter == "u" or leter == "v" or leter == "qu":
        word += "e"

    return word


def int_rand(numb):
    n = int(numb)
    if random.random() < numb - n:
        n += 1
    return n


def rand_color():
    return (random.random() * 255, random.random() * 255, random.random() * 255)


land = []

size = 50

SIZE = 20

for i in range(size):
    o = []
    for j in range(size):
        height = 0
        for k in seed:
            height += math.sin(
                (i / 2 * math.sin(k[2]) + j / 2 * math.cos(k[2])) / k[0] + k[1]
            )
        height2 = 0
        for k in seed:
            height2 += math.sin(
                ((i / 2 + 10000000) * math.sin(k[2]) + j / 2 * math.cos(k[2])) / k[0]
                + k[1]
            )
        matrix = ""
        if random.random() < 0.1:
            matrix = word()
        if height > 0:
            o.append(
                [
                    i,
                    j,
                    1,
                    matrix,
                    0.5,
                    0.5,
                    height,
                    word(),
                ]
            )
        else:
            o.append(
                [
                    i,
                    j,
                    0,
                    "",
                    0.5,
                    min(1, max(0, height2 / 10 + 0.5)),
                    0,
                    "",
                ]
            )
    land.append(o)


def add_line(
    screen,
    text,
    x,
    y,
    color=(0, 0, 0),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 30),
):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def add_center_line(
    screen,
    text,
    x,
    y,
    color=(0, 0, 0),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 30),
):
    # used to print the status of the variables

    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.center = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


strengths = {0: 1, 1: 0.2, 2: 0.02}


time1 = 0

held = False

select_type = 2

colors = {"": (255, 255, 255)}

posx = 0
posy = 0

speed = 20

timespeed = size**2 / 30

fps = time.time()

lables = {}

year = random.randint(-1000, 3000)

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((255, 255, 255))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    time1 += 1

    if keys[pygame.K_1]:
        select_type = 1
    if keys[pygame.K_2]:
        select_type = 2
    if keys[pygame.K_3]:
        select_type = 3
    if keys[pygame.K_w]:
        posy -= speed / SIZE
    if keys[pygame.K_s]:
        posy += speed / SIZE
    if keys[pygame.K_a]:
        posx -= speed / SIZE
    if keys[pygame.K_d]:
        posx += speed / SIZE
    if keys[pygame.K_e]:
        SIZE /= 0.97
    if keys[pygame.K_r]:
        SIZE *= 0.97
    if keys[pygame.K_z]:
        timespeed = max(0, timespeed - 6)
    if keys[pygame.K_x]:
        timespeed += 6
    if keys[pygame.K_SPACE]:
        timespeed = 0

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for k in range(int(timespeed)):
        x = random.randint(0, size - 1)
        y = random.randint(0, size - 1)
        i = land[x][y]
        i[4] = min(
            1, max(0, (size / 2 - abs(i[1] - size / 2)) / size - i[6] / 30 + 0.2)
        )
        if i[2] != 0:
            s = []
            if i[0] > 0:
                s.append(land[i[0] - 1][i[1]])
            if i[0] < size - 1:
                s.append(land[(i[0] + 1) % size][i[1]])
            if i[1] > 0:
                s.append(land[i[0]][i[1] - 1])
            if i[1] < size - 1:
                s.append(land[i[0]][(i[1] + 1) % size])
            n = 0
            for u in s:
                if u[5] > n:
                    n = u[5]
            i[5] = n * (1 - i[6] / 15)
        if i[2] == 2 and random.random() < 0.001:
            i[2] = 1
        if i[2] == 1:
            if random.random() < (i[4] + i[5] - 0.4) / 5000:
                i[2] = 2

        if i[3] != "":
            s = []
            if i[0] > 0:
                s.append(land[i[0] - 1][i[1]])
            if i[0] < size - 1:
                s.append(land[(i[0] + 1) % size][i[1]])
            if i[1] > 0:
                s.append(land[i[0]][i[1] - 1])
            if i[1] < size - 1:
                s.append(land[i[0]][(i[1] + 1) % size])
            t = []
            for u in s:
                if u[3] != i[3]:
                    t.append(u)
            if t:
                u = random.choice(t)
                if (
                    strengths[u[2]] / strengths[i[2]] * (1 / 2) ** (i[6] ** 2 / 10)
                    > random.random()
                ):
                    land[u[0]][u[1]][3] = i[3]
        land[x][y] = i

    for k in range(int_rand(timespeed / 20000)):
        if lables:
            n = []
            for i in lables:
                n.append(i)
            split = random.choice(n)
            if random.random() > 0.2:
                new = word()
                for j in land:
                    for i in j:
                        if random.random() > 0.5 and i[3] == split and split != "":
                            i[3] = new
            else:
                for j in land:
                    for i in j:
                        if i[3] == split:
                            i[3] = ""

    if time1 % 10 == 0:
        lables = {}

    for j in land:
        for i in j:
            if i[2] > 0 and time1 % 10 == 0:
                if i[3] not in lables:
                    lables.update({i[3]: [i[0], i[1], 1]})
                else:
                    lables[i[3]][0] += i[0]
                    lables[i[3]][1] += i[1]
                    lables[i[3]][2] += 1

            if i[3] not in colors:
                colors.update({i[3]: rand_color()})
            color = [0, 0, 0]

            if i[2] == 1 or i[2] == 2:
                if i[4] > 0.3:
                    color = [255, 255, 0]
                    color = [
                        color[0] * i[4],
                        (color[1] + (1 - i[4]) * 0) / 2,
                        (color[2] + (1 - i[4]) * 255) / 2,
                    ]
                    color = [
                        color[0] * (1 - i[5]),
                        (color[1] + i[5] * 255) / 2,
                        color[2],
                    ]
                else:
                    color = [150, 130, 100]
                    color = [
                        (color[1] + i[5] * 255) / 2,
                        (color[1] + i[5] * 255) / 2,
                        (color[1] + i[5] * 255) / 2,
                    ]

            else:
                color = [0, 0, 255]

            if i[2] == 1 or i[2] == 2:
                color2 = [255, 255, 255]

                color2 = colors[i[3]]
            else:
                color2 = [0, 0, 255]

                color2 = colors[i[3]]
                color2 = [
                    color2[0] * 0.15,
                    color2[1] * 0.15,
                    color2[2] * 0.15 + 255 * 0.85,
                ]

            if select_type == 1:
                map1 = pygame.Rect(
                    (i[0] - posx) * SIZE + 900,
                    (i[1] - posy) * SIZE + 450,
                    SIZE + 1,
                    SIZE + 1,
                )
                pygame.draw.rect(screen, color, map1)
            elif select_type == 2:
                map1 = pygame.Rect(
                    (i[0] - posx) * SIZE + 900,
                    (i[1] - posy) * SIZE + 450,
                    SIZE + 1,
                    SIZE + 1,
                )
                pygame.draw.rect(screen, color2, map1)
            elif select_type == 3:
                map1 = pygame.Rect(
                    (i[0] - posx) * SIZE + 900,
                    (i[1] - posy) * SIZE + 450,
                    SIZE + 1,
                    SIZE + 1,
                )
                pygame.draw.rect(
                    screen,
                    [
                        color[0] * 0.5 + color2[0] * 0.5,
                        color[1] * 0.5 + color2[1] * 0.5,
                        color[2] * 0.5 + color2[2] * 0.5,
                    ],
                    map1,
                )
            if i[2] == 2:
                map1 = pygame.Rect(
                    (i[0] - posx + 1 / 4) * SIZE + 900,
                    (i[1] - posy + 1 / 4) * SIZE + 450,
                    SIZE / 2 + 1,
                    SIZE / 2 + 1,
                )
                pygame.draw.rect(screen, [100, 100, 100], map1)

            x = (i[0] - posx) * SIZE + 900
            y = (i[1] - posy) * SIZE + 450

            if i[3] != land[i[0]][i[1] - 1][3]:
                pygame.draw.line(
                    screen,
                    (255, 0, 0),
                    (x, y),
                    (x + SIZE, y),
                    width=2,
                )
            if i[3] != land[i[0]][(i[1] + 1) % size][3]:
                pygame.draw.line(
                    screen,
                    (255, 0, 0),
                    (x, y + SIZE),
                    (x + SIZE, y + SIZE),
                    width=2,
                )
            if i[3] != land[i[0] - 1][i[1]][3]:
                pygame.draw.line(
                    screen,
                    (255, 0, 0),
                    (x, y),
                    (x, y + SIZE),
                    width=2,
                )
            if i[3] != land[(i[0] + 1) % size][i[1]][3]:
                pygame.draw.line(
                    screen,
                    (255, 0, 0),
                    (x + SIZE, y),
                    (x + SIZE, y + SIZE),
                    width=2,
                )

            if i[2] != land[i[0]][i[1] - 1][2] and (
                not i[2] or not land[i[0]][i[1] - 1][2]
            ):
                pygame.draw.line(
                    screen,
                    (255, 200, 0),
                    (x, y),
                    (x + SIZE, y),
                    width=2,
                )
            if i[2] != land[i[0]][(i[1] + 1) % size][2] and (
                not i[2] and not land[i[0]][(i[1] + 1) % size][2]
            ):
                pygame.draw.line(
                    screen,
                    (255, 200, 0),
                    (x, y + SIZE),
                    (x + SIZE, y + SIZE),
                    width=2,
                )
            if i[2] != land[i[0] - 1][i[1]][2] and (
                not i[2] or not land[i[0] - 1][i[1]][2]
            ):
                pygame.draw.line(
                    screen,
                    (255, 200, 0),
                    (x, y),
                    (x, y + SIZE),
                    width=2,
                )
            if i[2] != land[(i[0] + 1) % size][i[1]][2] and (
                not i[2] or not land[(i[0] + 1) % size][i[1]][2]
            ):
                pygame.draw.line(
                    screen,
                    (255, 200, 0),
                    (x + SIZE, y),
                    (x + SIZE, y + SIZE),
                    width=2,
                )

    n = 0

    for i in lables:
        add_center_line(
            screen,
            i,
            (lables[i][0] / lables[i][2] - posx) * SIZE + 900,
            (lables[i][1] / lables[i][2] - posy) * SIZE + 450,
            font2=pygame.font.Font(
                "freesansbold.ttf", int(lables[i][2] ** (1 / 3) * 5 * SIZE / 20)
            ),
        )
        map1 = pygame.Rect(
            n,
            0,
            lables[i][2] / size**2 * 1800 + 1,
            10,
        )
        pygame.draw.rect(screen, colors[i], map1)
        n += lables[i][2] / size**2 * 1800

    try:
        i = land[int((mx - 900) / SIZE + posx)][int((my - 450) / SIZE + posy)]
        if i[2] > 1:
            add_line(
                screen,
                "nation: " + i[3] + ", city: " + i[7],
                mx + 20,
                my,
            )
        elif i[2] > 0:
            add_line(
                screen,
                "nation: " + i[3] + ", province: " + i[7],
                mx + 20,
                my,
            )
        else:
            add_line(
                screen,
                "nation: " + i[3],
                mx + 20,
                my,
            )
        add_line(
            screen,
            "height: " + str(int(i[6] ** 2 * 100)) + "m",
            mx + 20,
            my + 30,
        )
        add_line(
            screen,
            "temp: "
            + str(int((i[4] * 90 - 20) * 10) / 10)
            + "*C, "
            + "precipitation: "
            + str(int((i[5] ** 2 * 500) * 10) / 10)
            + "cm",
            mx + 20,
            my + 60,
        )
    except:
        pass

    year += timespeed / 2000

    add_line(screen, "year " + str(int(year)), 0, 0)

    add_line(screen, str(int(timespeed / size**2 * 3000) / 100) + "x", 0, 30)

    add_line(screen, str(int(1000 / (time.time() - fps)) / 1000) + " fps", 600, 0)
    fps = time.time()

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
