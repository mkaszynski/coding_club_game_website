import pygame
import time
import random
import os


def coloid2(pos1, pos2):
    if pos1[0] > pos2[0] - pos1[2] and pos1[0] < pos2[0] + pos2[2]:
        if pos1[1] > pos2[1] - pos1[3] and pos1[1] < pos2[1] + pos2[3]:
            return True


map_level = []

for k in range(10):
    tiles = []
    things = []

    for i in range(40):
        for j in range(40):
            tiles.append([i * 20 - 400, j * 20 - 400, True, False, False])

    x, y = 0, 0
    for j in range(1000):
        for i in tiles:
            if x == i[0] and y == i[1]:
                i[2] = False
        if random.random() > 0.99:
            things.append([x, y, "enemy", x, y, 100 * (k + 1), "enemy"])
        if random.random() > 0.999:
            things.append([x, y, "map", x, y, 100, "map"])
        if random.random() > 0.9965:
            things.append([x, y, "potion", x, y, 100, "potion"])
        if random.random() > 0.9965:
            things.append([x, y, "shield_potion", x, y, 100, "shield_potion"])
        if random.random() > 0.9985:
            things.append([x, y, "seeing_potion", x, y, 100, "seeing_potion"])
        if random.random() > 0.9985:
            things.append([x, y, "speed_potion", x, y, 100, "speed_potion"])
        if random.random() > 0.9985:
            things.append([x, y, "strength_potion", x, y, 100, "strength_potion"])
        if random.random() > 0.9985:
            things.append([x, y, "shadow_potion", x, y, 100, "shadow_potion"])
        if random.random() > 0.99865:
            things.append([x, y, "sword", x, y, 100, "sword"])
        if random.random() > 0.99865:
            things.append([x, y, "armor", x, y, 100, "armor"])
        if j == 999:
            things.append([x, y, "enemy", x, y, 300 * (k + 1), "boss"])
            if not k == 9:
                things.append([x, y, "stairs", x, y, 100, "stairs"])
        if random.random() > 0.5:
            x += random.choice([-20, 20])
        else:
            y += random.choice([-20, 20])
        if x > 300:
            x = 300
        if x < -300:
            x = -300
        if y > 300:
            y = 300
        if y < -300:
            y = -300
    for o in range(5):
        x = [random.randint(-300, 100), random.randint(-300, 100)]
        y = [random.randint(0, 200), random.randint(0, 200)]
        for j in tiles:
            if coloid2((x[0], x[1], y[0], y[1]), (j[0], j[1], 20, 20)):
                j[2] = False

    n = []
    n.append(tiles)
    n.append(things)
    map_level.append(n)

level = 0

armor = 1

effects = []

effect = []

tiles = map_level[level][0]
things = map_level[level][1]

pygame.init()

font = pygame.font.Font("freesansbold.ttf", 16)


def add_line(screen, text, x, y, color=(0, 255, 0)):
    # used to print the status of the variables
    text = font.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    x = abs(pos2[0] - pos1[0]) ** 2
    y = abs(pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def coloid(pos1, pos2):
    if pos1[0] > pos2[0] - pos1[2] and pos1[0] < pos2[0] + pos2[2]:
        if pos1[1] > pos2[1] - pos1[3] and pos1[1] < pos2[1] + pos2[3]:
            return True


# Set up the drawing window
screen = pygame.display.set_mode([1800, 900])


go = False

size = 2

posx, posy = 0, 0
posxl, posyl = 0, 0


def sight(tiles, posx, posy):
    light = []
    for i in tiles:
        if 100 < dis((i[0], i[1]), (posx, posy)) < 120:
            light.append(
                [
                    posx,
                    posy,
                    (i[0] - posx) / dis((i[0], i[1]), (posx, posy)) * 20,
                    (i[1] - posy) / dis((i[0], i[1]), (posx, posy)) * 20,
                ]
            )
    while light:
        for i in light:
            if dis((i[0], i[1]), (posx, posy)) > 70:
                light.remove(i)
        for i in light:
            i[0] += i[2]
            i[1] += i[3]
            for j in tiles:
                if coloid((i[0], i[1], 0, 0), (j[0], j[1], 20, 20)):
                    j[3] = True
                    if j[2]:
                        try:
                            light.remove(i)
                        except:
                            pass
    return tiles


health = 100
click = False

sword = [100, 60, 40]

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((0, 0, 0))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    if keys[pygame.K_e]:
        size *= 0.5
    if keys[pygame.K_r]:
        size /= 0.5

    if size > 16:
        size = 16
    if size < 0.25:
        size = 0.25

    speed1 = 1
    if "speed" in effect:
        speed1 = 0.5

    if not click:
        if keys[pygame.K_w]:
            posy -= 20
            if random.random() < speed1:
                go = True
            click = True
        if keys[pygame.K_s]:
            posy += 20
            if random.random() < speed1:
                go = True
            click = True
        if keys[pygame.K_a]:
            posx -= 20
            if random.random() < speed1:
                go = True
            click = True
        if keys[pygame.K_d]:
            posx += 20
            if random.random() < speed1:
                go = True
            click = True
        if keys[pygame.K_f]:
            for i in things:
                if dis((i[0], i[1]), (posx, posy)) < sword[1]:
                    if i[2] == "enemy":
                        i[5] -= random.randint(0, sword[2])
                        if "strength" in effect:
                            i[5] -= random.randint(0, sword[2])
                        for k in effects:
                            if k[0] == "shadow":
                                effects.remove(k)
            go = True
            click = True
        if keys[pygame.K_p]:
            for i in things:
                if dis((i[0], i[1]), (posx, posy)) < sword[1]:
                    if i[2] == "map":
                        things.remove(i)
                        for j in tiles:
                            if not j[2]:
                                j[4] = True
                    elif i[2] == "potion":
                        things.remove(i)
                        if health <= 100:
                            health = 100
                    elif i[2] == "shield_potion":
                        things.remove(i)
                        health += 50
                    elif i[2] == "seeing_potion":
                        things.remove(i)
                        if "seeing" not in effect:
                            effects.append(["seeing", (0, 255, 128), 30])
                    elif i[2] == "speed_potion":
                        things.remove(i)
                        if "speed" not in effect:
                            effects.append(["speed", (0, 255, 255), 30])
                    elif i[2] == "strength_potion":
                        things.remove(i)
                        if "strength" not in effect:
                            effects.append(["strength", (255, 0, 128), 30])
                    elif i[2] == "shadow_potion":
                        things.remove(i)
                        if "shadow" not in effect:
                            effects.append(["shadow", (128, 0, 255), 20])
                    elif i[2] == "stairs":
                        map_level[level][0] = tiles
                        map_level[level][1] = things
                        level += 1
                        tiles = map_level[level][0]
                        things = map_level[level][1]
                        posx = 0
                        posy = 0
                        posxl = 0
                        posyl = 0
                    elif i[2] == "sword":
                        things.remove(i)
                        sword[0] += 100
                        sword[2] += 20
                        sword[2] = int(sword[2])
                    elif i[2] == "armor":
                        things.remove(i)
                        armor += 0.75

            go = True
            click = True
        if keys[pygame.K_SPACE]:
            go = True
            click = True

    for i in effects:
        if go:
            i[2] -= 1
        if i[2] <= 0:
            effects.remove(i)
            effect = []
        else:
            effect.append(i[0])

    n = False
    for i in keys:
        if i:
            n = True
    if not n:
        click = False

    for i in tiles:
        if i[2]:
            if posx == i[0] and posy == i[1]:
                posx = posxl
                posy = posyl
    tiles = sight(tiles, posx + 10, posy + 10)
    if go:
        for i in tiles:
            for j in things:
                if j[0] == i[0] and j[1] == i[1]:
                    if j[2] == "enemy":
                        if i[3] and "shadow" not in effect:
                            if random.random() > 0.1:
                                if dis((j[0], j[1]), (posx, posy)) <= 40:
                                    if j[6] == "enemy":
                                        health -= (
                                            int(
                                                random.randint(0, 10)
                                                / armor
                                                * (level + 1)
                                            )
                                            + 1
                                        )
                                    else:
                                        health -= (
                                            int(
                                                random.randint(0, 25)
                                                / armor
                                                * (level + 1)
                                            )
                                            + 1
                                        )
                                else:
                                    n = [0, 0]
                                    m = 1000
                                    if dis((j[0] + 20, j[1]), (posx, posy)) < m:
                                        m = dis((j[0] + 20, j[1]), (posx, posy))
                                        n = [20, 0]
                                    if dis((j[0] - 20, j[1]), (posx, posy)) < m:
                                        m = dis((j[0] - 20, j[1]), (posx, posy))
                                        n = [-20, 0]
                                    if dis((j[0], j[1] + 20), (posx, posy)) < m:
                                        m = dis((j[0], j[1] + 20), (posx, posy))
                                        n = [0, 20]
                                    if dis((j[0], j[1] - 20), (posx, posy)) < m:
                                        m = dis((j[0], j[1] - 20), (posx, posy))
                                        n = [0, -20]
                                    j[0] += n[0]
                                    j[1] += n[1]
                        else:
                            if random.random() > 0.5:
                                j[0] += random.choice([-20, 0, 20])
                            else:
                                j[1] += random.choice([-20, 0, 20])
        for i in tiles:
            for j in things:
                if j[0] == i[0] and j[1] == i[1]:
                    if j[2] == "enemy":
                        if i[2]:
                            if j[0] == i[0] and j[1] == i[1]:
                                j[0] = j[3]
                                j[1] = j[4]
    for i in tiles:
        if i[3]:
            i[4] = i[3]

    for i in things:
        i[3] = i[0]
        i[4] = i[1]
        if i[5] <= 0:
            things.remove(i)

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for i in tiles:
        if i[4]:
            if i[2]:
                map1 = pygame.Rect(
                    (i[0] - posx) * size + 900,
                    (i[1] - posy) * size + 450,
                    20 * size,
                    20 * size,
                )
                pygame.draw.rect(screen, (50, 25, 0), map1)
            else:
                map1 = pygame.Rect(
                    (i[0] - posx) * size + 900,
                    (i[1] - posy) * size + 450,
                    20 * size,
                    20 * size,
                )
                pygame.draw.rect(screen, (100, 100, 100), map1)
        if i[3]:
            if i[2]:
                map1 = pygame.Rect(
                    (i[0] - posx) * size + 900,
                    (i[1] - posy) * size + 450,
                    20 * size,
                    20 * size,
                )
                pygame.draw.rect(screen, (128, 64, 0), map1)
            else:
                map1 = pygame.Rect(
                    (i[0] - posx) * size + 900,
                    (i[1] - posy) * size + 450,
                    20 * size,
                    20 * size,
                )
                pygame.draw.rect(screen, (255, 255, 255), map1)

    map1 = pygame.Rect(900, 450, 20 * size, 20 * size)
    pygame.draw.rect(screen, (255, 255, 255), map1)

    for i in tiles:
        if i[3]:
            for j in things:
                if i[0] == j[0] and i[1] == j[1]:
                    this_dir = os.path.dirname(__file__)
                    image_file = os.path.join(this_dir, j[6] + ".png")
                    image = pygame.image.load(image_file).convert()
                    image.set_colorkey((0, 0, 0))
                    image = pygame.transform.scale(image, (20 * size, 20 * size))
                    rect = image.get_rect()
                    rect.center = (
                        (j[0] - posx + 10) * size + 900,
                        (j[1] - posy + 10) * size + 450,
                    )
                    screen.blit(image, rect)
                    if j[2] == "enemy":
                        add_line(
                            screen,
                            f"health: {j[5]}",
                            (j[0] - posx + 5) * size + 900,
                            (j[1] - posy + 5) * size + 450,
                        )
        if "seeing" in effect:
            for j in things:
                if i[0] == j[0] and i[1] == j[1]:
                    this_dir = os.path.dirname(__file__)
                    image_file = os.path.join(this_dir, j[6] + ".png")
                    image = pygame.image.load(image_file).convert()
                    image.set_colorkey((0, 0, 0))
                    image = pygame.transform.scale(image, (20 * size, 20 * size))
                    rect = image.get_rect()
                    rect.center = (
                        (j[0] - posx + 10) * size + 900,
                        (j[1] - posy + 10) * size + 450,
                    )
                    screen.blit(image, rect)
                    if j[2] == "enemy":
                        add_line(
                            screen,
                            f"health: {j[5]}",
                            (j[0] - posx + 5) * size + 900,
                            (j[1] - posy + 5) * size + 450,
                        )

    if "shadow" not in effect:
        this_dir = os.path.dirname(__file__)
        image_file = os.path.join(this_dir, "person.png")
        image = pygame.image.load(image_file).convert()
        image.set_colorkey((0, 0, 0))
        image = pygame.transform.scale(image, (20 * size, 20 * size))
        rect = image.get_rect()
        rect.center = (900 + 10 * size, 450 + 10 * size)
        screen.blit(image, rect)

    for i in effects:
        map1 = pygame.Rect(effects.index(i) * 40, 40, 40, 40)
        pygame.draw.rect(screen, i[1], map1)
        add_line(
            screen,
            str(i[2]),
            effects.index(i) * 40,
            40,
            color=(255 - i[1][0], 255 - i[1][1], 255 - i[1][2]),
        )

    if health <= 100:
        map1 = pygame.Rect(0, 0, (100 - health) * 9, 10)
        pygame.draw.rect(screen, (255, 0, 0), map1)

        map1 = pygame.Rect(1800 - (100 - health) * 9, 0, (100 - health) * 9, 10)
        pygame.draw.rect(screen, (255, 0, 0), map1)
    else:
        map1 = pygame.Rect(0, 0, (health - 100) * 9, 10)
        pygame.draw.rect(screen, (255, 200, 0), map1)

        map1 = pygame.Rect(1800 - (health - 100) * 9, 0, (health - 100) * 9, 10)
        pygame.draw.rect(screen, (255, 200, 0), map1)

    if go:
        if health < 100:
            health += 1

    for i in tiles:
        i[3] = False

    if go:
        effect = []

    go = False

    add_line(screen, f"health: {health}", 875, 0)

    if health <= 0:
        running = False

    n = False
    for i in things:
        if i[2] == "enemy":
            n = True
    if not n:
        if level == 10:
            m = 33
            add_line(screen, "You have cleared the cave of monsters!", 500, 300)
            for i in tiles:
                i[0] += random.random() * 20 - 10
                i[1] += random.random() * 20 - 10

    posxl = posx
    posyl = posy

    time.sleep(1 / 30)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()

print("you reached level " + str(level + 1))
