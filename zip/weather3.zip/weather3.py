import pygame
import random
import math

pygame.init()

clock = pygame.time.Clock()

# Set up the drawing window
screen = pygame.display.set_mode([1800, 900])

land = []
for k in range(5):
    seed = []

    level = int(random.random() * 9 - 4)

    for i in range(10):
        seed.append([random.random() * 100 + 50, random.random() * 1000])
    for i in range(10):
        seed.append([random.random() * 300 + 150, random.random() * 1000])

    n = []
    for i in range(int(random.random() * 90 + 1)):
        collum = []
        for j in range(30):
            height = 20 + level

            for k in seed:
                height += math.sin((i + k[1]) / k[0] * 30) * 1.5

            if j > height:  # x  y typ temp moisture
                collum.append([i, j, 2, 0.5, 0, True, False])
            else:
                if j > 19:
                    collum.append([i, j, 1, 0.5, 0.1, True, False])
                else:
                    collum.append([i, j, 0, 0.1, 0.1, True, False])
        n.append(collum)
    land.append(n)


current_land = -1


def add_line(
    screen,
    text,
    x,
    y,
    color=(255, 255, 255),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 30),
):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def humidity(hum, temp):
    if hum > temp + 0.03:
        return True
    else:
        return False


SIZE = 20

time1 = 0


# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((0, 0, 0))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    if keys[pygame.K_w]:
        land[current_land][int(mx / SIZE) % len(land[current_land])][
            int(my / SIZE) % 30
        ][3] *= 1.01
    if keys[pygame.K_s]:
        land[current_land][int(mx / SIZE) % len(land[current_land])][
            int(my / SIZE) % 30
        ][3] *= 0.99
    if keys[pygame.K_a]:
        land[current_land][int(mx / SIZE) % len(land[current_land])][
            int(my / SIZE) % 30
        ][4] *= 0.99
    if keys[pygame.K_d]:
        land[current_land][int(mx / SIZE) % len(land[current_land])][
            int(my / SIZE) % 30
        ][4] *= 1.01

    if mouse_held[2]:
        current_land = -1

    time1 += 1

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for planet in land:
        for j in planet:
            for i in j:
                i[4] *= 0.99995
                if i[1] == 0:
                    if (i[0] + time1 * 0.04 * len(planet) / 60) % len(planet) > len(
                        planet
                    ) / 2:
                        i[5] = True
                    else:
                        i[5] = False
                else:
                    i[5] = planet[i[0]][i[1] - 1][5]
                    if humidity(planet[i[0]][i[1] - 1][4], planet[i[0]][i[1] - 1][3]):
                        i[5] = False
                    if planet[i[0]][i[1] - 1][2] > 0:
                        i[5] = False
                if i[2] == 2:
                    if planet[i[0]][i[1] - 1][2] == 0:
                        if i[5]:
                            i[3] = i[3] * 0.995 + 0.005
                        else:
                            i[3] = i[3] * 0.999 + 0.001

                elif i[2] == 1:
                    if planet[i[0]][i[1] - 1][2] == 0:
                        if i[5]:
                            i[3] = i[3] * 0.99 + 0.01
                            i[4] = i[4] * (1 - 0.003) + 0.003
                        else:
                            i[3] = i[3] * 0.999 + 0.001

                elif i[2] == 0:
                    if not planet[i[0]][i[1] - 1][6] and random.random() > 0.9:
                        i[6] = False
                    if i[6]:
                        if planet[i[0]][i[1] + 1][2] == 0:
                            planet[i[0]][i[1] + 1][6] = True
                    s = []
                    s.append(planet[i[0] - 1][i[1]])
                    s.append(planet[(i[0] + 1) % len(planet)][i[1]])
                    s.append(planet[i[0]][i[1] - 1])
                    s.append(planet[i[0]][(i[1] + 1) % 30])
                    u = random.choice(s)
                    n = i[4]
                    m = u[4]
                    i[4] = n * 0.99 + m * 0.01
                    planet[u[0]][u[1]][4] = m * 0.99 + n * 0.01
                    n = i[3]
                    m = u[3]
                    i[3] = n * 0.995 + m * 0.005
                    planet[u[0]][u[1]][3] = m * 0.995 + n * 0.005
                    i[3] *= 0.99975
                    if humidity(i[4] / 1.05, i[3]):
                        i[4] *= 0.5
                        i[6] = True

    totemp = 0
    tohum = 0

    for planet in land:
        wide = []
        for j in planet:
            a = (0, 0, 0)
            m = False
            for i in j:
                if land.index(planet) == current_land:
                    totemp += i[3]
                    tohum += i[4]
                if i[2] == 2:
                    if planet[i[0]][i[1] - 1][2] == 0:
                        color = [255, 255, 0]
                        color = [
                            color[0] * i[3],
                            (color[1] + (1 - i[3]) * 255) / 2,
                            (color[2] + (1 - i[3]) * 255) / 2,
                        ]
                        color = [
                            color[0] * (1 - i[4] * 4),
                            (color[1] + i[4] * 4 * 255) / 2,
                            color[2],
                        ]
                    else:
                        color = [128, 70, 0]
                elif i[2] == 1:
                    color = [0, 0, 200]
                else:
                    if not humidity(i[4], i[3]):
                        color = [100, 200, 255]
                    else:
                        color = [200, 200, 200]
                    if i[6] and random.random() > 0.9:
                        color = [0, 100, 255]

                color[0] = max(0, min(255, color[0]))
                color[1] = max(0, min(255, color[1]))
                color[2] = max(0, min(255, color[2]))

                c = 1

                if not i[5]:
                    color = [color[0] / 4, color[1] / 4, color[2] / 4]
                    c = 3

                if land.index(planet) == current_land:
                    map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                    pygame.draw.rect(
                        screen, [color[0] * c, color[1] * c, color[2] * c], map1
                    )
                if not m:
                    a = color
                    if i[2] > 0 or humidity(i[4], i[3]):
                        m = True
            wide.append(a)

        if current_land > -1:
            wide = []

        n = 0
        for i in wide:
            n += 1
            map1 = pygame.Rect(
                math.cos(
                    (n / len(wide)) * 2 * math.pi
                    + time1 * 0.04 * len(planet) / 60 / len(wide) * 2 * math.pi
                    - math.pi / 2
                )
                * 100
                / 60
                * len(planet)
                + 900
                + math.cos(land.index(planet) / len(land) * math.pi * 2) * 300,
                math.sin(
                    (n / len(wide)) * 2 * math.pi
                    + time1 * 0.04 * len(planet) / 60 / len(wide) * 2 * math.pi
                    - math.pi / 2
                )
                * 100
                / 60
                * len(planet)
                + 450
                + math.sin(land.index(planet) / len(land) * math.pi * 2) * 300,
                10,
                10,
            )
            pygame.draw.rect(screen, i, map1)

        if mouse_held[0] and dis(
            (mx, my),
            (
                900 + math.cos(land.index(planet) / len(land) * math.pi * 2) * 300,
                450 + math.sin(land.index(planet) / len(land) * math.pi * 2) * 300,
            ),
        ) < 100 / 60 * len(planet):
            current_land = land.index(planet)

    n = land[current_land][int(mx / SIZE) % len(land[current_land])][
        int(my / SIZE) % 30
    ]
    add_line(
        screen,
        f"temp: {(n[3] * 50 - 10):.2f}*C, humidity: {max(0, (n[4] / (n[3] + 0.03000001) * 100)):.2f}%",
        0,
        0,
    )

    add_line(
        screen,
        f"total temperature: {(totemp):.2f}, ",
        0,
        30,
    )

    add_line(
        screen,
        f"total humidity: {(tohum):.2f}, ",
        0,
        60,
    )

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
