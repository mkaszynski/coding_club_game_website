import pygame
import time
import random
import math

def perlin():
    imgx = 60
    imgy = 30  # image size
    octaves = int(math.log(max(imgx, imgy), 1.5))
    persistence = 0.7
    imgAr = [[0.0 for i in range(imgx)] for j in range(imgy)]  # image array
    totAmp = 0.0
    for k in range(octaves):
        freq = 2 ** k
        amp = persistence ** k
        totAmp += amp
        # create an image from n by m grid of random numbers (w/ amplitude)
        # using Bilinear Interpolation
        n = freq + 1
        m = freq + 1  # grid size
        ar = [[random.random() * amp for i in range(n)] for j in range(m)]
        nx = imgx / (n - 1.0)
        ny = imgy / (m - 1.0)
        for ky in range(imgy):
            for kx in range(imgx):
                o = 0
                i = int(kx / nx)
                j = int(ky / ny)
                dx0 = kx - i * nx
                dx1 = nx - dx0
                dy0 = ky - j * ny
                dy1 = ny - dy0
                if int(imgAr[ky][kx] / totAmp * 255) - 10 > 128:
                    o += 1
                z = ar[j][i] * dx1 * dy1
                z += ar[j][i + 1] * dx0 * dy1
                z += ar[j + 1][i] * dx1 * dy0
                z += ar[j + 1][i + 1] * dx0 * dy0
                z /= nx * ny
                imgAr[ky][kx] += z  # add image layers together
    
    # # paint image
    # for ky in range(imgy):
    #     for kx in range(imgx):
    #         c = int((imgAr[ky][kx] / totAmp * 255) * water_level)
    #         if c > 255:
    #             c = 255
    #         if c < 0:
    #             c = 0
    #         if c < 128:
    #             pixels[kx, ky] = (0, 0, c)
    #         elif c < 129:
    #             pixels[kx, ky] = (c, c, 0)
    #         elif c > 150:
    #             pixels[kx, ky] = (c, c, c)
    #         elif c > 140:
    #             pixels[kx, ky] = (int(c * 0.5), int(c * 0.5), int(c * 0.5))
    #         elif c > 135:
    #             pixels[kx, ky] = (0, c, 0)
    #         else:
    #             pixels[kx, ky] = (0, int(c * 0.5), 0)
    pick = []
    for i in range(imgy):
        pick.append([])
        for j in range(imgx):
            pick[i].append([])
    for ky in range(imgy):
        for kx in range(imgx):
            if int((imgAr[ky][kx] / totAmp * 255) * 0.9) < 120:
                pick[ky][kx] = [False, int((imgAr[ky][kx] / totAmp * 255) * 0.9)]
            else:
                pick[ky][kx] = [True, int((imgAr[ky][kx] / totAmp * 255) * 0.9)]
    return pick
pygame.init()

# Set up the drawing window
screen = pygame.display.set_mode([1200, 650])

font = pygame.font.Font("freesansbold.ttf", 20)

def add_line(screenm, text, x, y, color=(0, 0, 0), size=30, font2=pygame.font.Font("freesansbold.ttf", 30)):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)

def word():
    consanents = ['b', 'c', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'p', 'qu', 'r', 's', 't', 'v', 'w', 'x', 'y', 'z']

    vouels = ['a', 'e', 'i', 'o', 'u', 'y']
    leter = random.choice(consanents + vouels)
    
    word = leter
    
    for i in range(int(random.random()*3) + 1):
        if leter in consanents:
            leter = random.choice(vouels)
            word += leter
        if leter in vouels:
            leter = random.choice(consanents)
            word += leter
    
    if leter == 'i':
        word.replace('i', 'y')
    elif leter == 'u' or leter == 'v' or leter == 'qu':
        word += 'e'
    
    return word

lands = []

ships = []

np = perlin()

for i in range(60):
    for j in range(30):
        if np[j][i][0]:
            if random.random() > 0.975:
                lands.append([i*20, j*20, word(), (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255)), 
                              random.choice([word(), None, 
                                              None, None, 
                                              None, None, 
                                              None, None, 
                                              None, None, ]), np[j][i][1]])
            else:
                lands.append([i*20, j*20, None, (0, 255, 0), random.choice([word(), None, 
                                None, None, 
                                None, None, 
                                None, None, 
                                None, None, ]), np[j][i][1]])

def dis(pos1, pos2):
    x = abs(pos2[0] - pos1[0]) ** 2
    y = abs(pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5

paused = False

k = False

year = random.randint(0, 3000)

r = False

peace = []

def find_peace(land1, land2, peace):
    y = []
    treaty = False
    for i in peace:
        if land1 in i:
            y = [i]
            y.remove(land1)
            if land2 in y:
                treaty = True
    for i in peace:
        if land2 in i:
            y = [i]
            y.remove(land2)
            if land1 in y:
                treaty = True
    return treaty

stats = []

timing = [0, 0, 0, 0]

time3 = time.time()


# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((0, 0, 255))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()
    
    if not paused:
        stats.append([len(ships), year])
    
    if not paused:
        year += 1
    
    if keys[pygame.K_SPACE]:
        if not k:
            paused = not paused
            k = True
    else:
        k = False
    
    if keys[pygame.K_e]:
        r = True
    if keys[pygame.K_r]:
        r = False
    
    if mouse_held[0]:
        x, y = int(mx/20)*20, int(my/20)*20
        n = False
        for i in lands:
            if i[0] == x and i[1] == y:
                n = True
        if not n:
            lands.append([x, y, None, (0, 255, 0), None, random.randint(128, 150)])
    if mouse_held[2]:
        x, y = int(mx/20)*20, int(my/20)*20
        for i in lands:
            if i[0] == x and i[1] == y:
                lands.remove(i)
    
    if mouse_held[0] and keys[pygame.K_t]:
        x, y = int(mx/20)*20, int(my/20)*20
        for i in lands:
            if i[0] == x and i[1] == y and i[2] == None:
                i[2] = word()
                i[3] = (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
    
    timing[0] = timing[0]*0.99 + 0.01*(time.time() - time3)
    
    time3 = time.time()
    
    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    if not paused:
        for i in lands:
            if i[2]:
                if not i[4]:
                    if random.random() > 0.9975:
                        ships.append([i[0] + random.random()*60 - 30, i[1] + random.random()*60 - 30, i[2], i[3], False, random.random()*2 - 1, random.random()*2 - 1])
                else:
                    if random.random() > 0.9:
                        ships.append([i[0] + random.random()*60 - 30, i[1] + random.random()*60 - 30, i[2], i[3], False, random.random()*2 - 1, random.random()*2 - 1])
        for i in ships:
            for j in lands:
                if dis((i[0], i[1]), (j[0] + 10, j[1] + 10)) < 20:
                    if i[4]:
                        j[2] = i[2]
                        j[3] = i[3]
                    else:
                        try:
                            ships.remove(i)
                        except:
                            pass
                    try:
                        ships.remove(i)
                    except:
                        pass
            i[0] += i[5]
            i[1] += i[6]
            i[5] += random.random()*10 - 5
            i[6] += random.random()*10 - 5
            if i[0] > 1200:
                i[0] = 0
            if i[0] < 0:
                i[0] = 1200
            if i[1] > 600:
                i[1] = 0
            if i[1] < 0:
                i[1] = 600
            for i in ships:
                for j in ships:
                    if not i[2] == j[2]:
                        if dis((i[0], i[1]), (j[0], j[1])) < 15:
                            try:
                                if random.random() > 0.5:
                                    ships.remove(j)
                                else:
                                    ships.remove(i)
                            except:
                                pass
        
        for i in lands:
            if (i[5] - 120)*87 > 1750:
                i[2] = None
                i[3] = (0, 255, 0)
                i[4] = None
            if random.random() > 0.9:
                if i[2]:
                    n = []
                    for j in lands:
                        if dis((i[0], i[1]), (j[0], j[1])) <= 30:
                            if not i[2] == j[2]:
                                n.append(j)
                    try:
                        m = random.choice(n)
                        for j in lands:
                            if m == j:
                                if not j[4]:
                                    j[2] = i[2]
                                    j[3] = i[3]
                                else:
                                    if j[2] != None:
                                        if i[2]:
                                            if random.random() > 0.95:
                                                j[2] = i[2]
                                                j[3] = i[3]
                                        else:
                                            j[2] = i[2]
                                            j[3] = i[3]
                                    else:
                                        if i[2]:
                                            j[2] = i[2]
                                            j[3] = i[3]
                                        else:
                                            j[2] = i[2]
                                            j[3] = i[3]
                    except:
                        pass
            if random.random() > 0.999:
                i[4] = None
            if random.random() > 0.99985 - 0.00002*(-(i[5] - 120)/1.5 + 40 - abs(i[1] - 300)/5):
                i[4] = word()
            
    
    n = []
    for i in lands:
        if i[2]:
            if not i[2] in n:
                n.append(i[2])
    
    if not paused:
        for i in n:
            if random.random() > 0.995:
                if random.random() > 0.5:
                    h = random.randint(0, 1200)
                    g = [word(), (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))]
                    for j in lands:
                        if j[2] == i:
                            if j[0] > h:
                                j[2] = g[0]
                                j[3] = g[1]
                    if random.random() > 0.75:
                        for j in lands:
                            if j[2] == i:
                                j[2] = None
                                j[3] = (0, 255, 0)
                        for u in ships:
                            if u[2] == i:
                                try:
                                    ships.remove(u)
                                except:
                                    pass
                else:
                    h = random.randint(0, 600)
                    g = [word(), (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))]
                    for j in lands:
                        if j[2] == i:
                            if j[1] > h:
                                j[2] = g[0]
                                j[3] = g[1]
                    if random.random() > 0.75:
                        for j in lands:
                            if j[2] == i:
                                j[2] = None
                                j[3] = (0, 255, 0)
        
        n = []
        for i in lands:
            if i[2]:
                if not i[2] in n:
                    n.append(i[2])
        if random.random() > 0.9:
            if n:
                peace.append([random.choice(n), random.choice(n)])
    
    timing[1] = timing[1]*0.99 + 0.01*(time.time() - time3)
    
    time3 = time.time()
    
    for i in ships:
        map1 = pygame.Rect(i[0], i[1], 10, 10)
        pygame.draw.rect(screen, i[3], map1)
        add_line(screen, i[2], i[0], i[1], font2=pygame.font.Font("freesansbold.ttf", 15))
    
    for i in lands:
        map1 = pygame.Rect(i[0] - 2, i[1] - 2, 24, 24)
        pygame.draw.rect(screen, (255, 200, 50), map1)
    
    for i in lands:
        if not r:
            map1 = pygame.Rect(i[0], i[1], 20, 20)
            pygame.draw.rect(screen, i[3], map1)
        else:
            map1 = pygame.Rect(i[0], i[1], 20, 20)
            pygame.draw.rect(screen, ((i[5] - 120)*3, 255 - (i[5] - 120)*3, abs(i[1] - 300)/300*128), map1)
            if i[4]:
                map1 = pygame.Rect(i[0] + 5, i[1] + 5, 10, 10)
                pygame.draw.rect(screen, (255, 0, 0), map1)
                
        if (i[5] - 120)*87 > 1750:
            map1 = pygame.Rect(i[0], i[1], 20, 20)
            pygame.draw.rect(screen, (150, 150, 150), map1)
            map1 = pygame.Rect(i[0] + 1, i[1] + 1, 18, 18)
            pygame.draw.rect(screen, (0, 150, 200), map1)
    for i in lands:
        if i[4]:
            add_line(screen, i[4], i[0], i[1], font2=pygame.font.Font("freesansbold.ttf", 15))
    
    
    timing[2] = timing[2]*0.99 + 0.01*(time.time() - time3)
    
    time3 = time.time()
    
    n = []
    for i in lands:
        if i[2]:
            if not i[2] in n:
                n.append(i[2])
    
    centers = []
    
    for j in n:
        centers.append([])
        for i in lands:
            if i[2] == j:
                centers[n.index(j)].append([i[0], i[1], j])
    
    centers2 = []
    
    for i in centers:
        h = [0, 0]
        for j in i:
            h[0] += j[0]
            h[1] += j[1]
        h[0] *= 1/len(i)
        h[1] *= 1/len(i)
        centers2.append([h[0], h[1], i[0][2], len(i)])
    
    map1 = pygame.Rect(0, 600, 1200, 50)
    pygame.draw.rect(screen, (0, 0, 0), map1)
    
    for i in centers2:
        add_line(screen, i[2], i[0] - len(i[2])/4*int(9*(i[3])**(1/3)), i[1], font2=pygame.font.Font("freesansbold.ttf", int(9*(i[3])**(1/3))))
    
    add_line(screen, f'year {year}', 600, 600, color=(255, 255, 255))
    
    
    for i in lands:
        if i[4]:
            if mx > i[0] and mx < i[0] + 20:
                if my > i[1] and my < i[1] + 20:
                    add_line(screen, str((i[5] - 120)*87) + 'm city: ' + str(i[4]) + ' nation: ' + str(i[2]) + ' temp:' + str(int(-(i[5] - 120)/1.5 + 40 - abs(i[1] - 300)/5)) + '*C', 0, 600, color=(255, 255, 255))
    
    for i in ships:
        if dis((mx, my), (i[0], i[1])) < 40:
            add_line(screen, 'nation: ' + i[2] + ', temp: ' + str(int(40 - abs(i[1] - 300)/5)) + '*C', 0, 600, color=(255, 255, 255))
    
    for i in range(4):
        pygame.draw.line(screen, (128, 128, 128), (i*300, 0), (i*300, 600))
        add_line(screen, str(i*30 - 180), i*300, 0)
        add_line(screen, str(i*30 - 180), i*300, 560)
    for i in range(2):
        pygame.draw.line(screen, (128, 128, 128), (0, i*300), (1200, i*300))
        add_line(screen, str(i*30 - 90), 0, i*300)
        add_line(screen, str(i*30 - 90), 1155, i*300)
    
    timing[3] = timing[3]*0.99 + 0.01*(time.time() - time3)
    
    time3 = time.time()
    
    clock = pygame.time.Clock()
    clock.tick(60)
    
    

    # Flip the display
    pygame.display.flip()
    
    if not paused:
        if random.random() > 0.9 and peace:
            peace.remove(random.choice(peace))
        for i in ships:
            i[4] = True
    

# Done! Time to quit.
pygame.quit()


from copy import copy
import numpy as np
import matplotlib.pyplot as plt

positions = []

for i in stats:
    positions.append(copy([i[1], i[0]]))

positions = np.array(positions)

plt.plot(positions[:, 0], positions[:, 1])
plt.show()
