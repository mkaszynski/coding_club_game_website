import pygame
import random

pygame.init()

clock = pygame.time.Clock()

size = int(input("Size: "))

# Set up the drawing window
screen = pygame.display.set_mode([1800, 900])

cube = []

for i in range(6):
    a = []
    for j in range(size):
        b = []
        for k in range(size):
            n = i
            b.append([j, k, n, n])
        a.append(b)
    cube.append(a)


def add_line(
    screen,
    text,
    x,
    y,
    color=(0, 0, 0),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 30),
):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


colors = [
    (255, 0, 0),
    (0, 255, 0),
    (255, 128, 0),
    (0, 0, 255),
    (255, 255, 255),
    (255, 255, 0),
]

held = False


# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((255, 255, 255))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    if (
        not keys[pygame.K_UP]
        and not keys[pygame.K_DOWN]
        and not keys[pygame.K_LEFT]
        and not keys[pygame.K_RIGHT]
        and not keys[pygame.K_w]
        and not keys[pygame.K_s]
        and not keys[pygame.K_a]
        and not keys[pygame.K_d]
    ):
        held = False

    if not held and keys[pygame.K_DOWN]:
        held = True
        x, y = int(mx / 40 - size), int(my / 40 - size)
        if 0 <= x < size and 0 <= y < size:
            for k in range(size):
                cube[0][x][k][3] = cube[4][x][k][2]
                cube[4][x][k][3] = cube[2][size - x - 1][size - k - 1][2]
                cube[2][size - x - 1][size - k - 1][3] = cube[5][x][k][2]
                cube[5][x][k][3] = cube[0][x][k][2]
            for k in cube:
                for j in k:
                    for i in j:
                        i[2] = i[3]
            if x == 0:
                for j in cube[3]:
                    for i in j:
                        i[3] = cube[3][i[1]][size - i[0] - 1][2]
                for j in cube[3]:
                    for i in j:
                        i[2] = i[3]
            elif x == size - 1:
                for j in cube[1]:
                    for i in j:
                        i[3] = cube[1][size - i[1] - 1][i[0]][2]
                for j in cube[1]:
                    for i in j:
                        i[2] = i[3]
    if not held and keys[pygame.K_w]:
        held = True
        for x in range(size):
            for k in range(size):
                cube[0][x][k][3] = cube[4][x][k][2]
                cube[4][x][k][3] = cube[2][size - x - 1][size - k - 1][2]
                cube[2][size - x - 1][size - k - 1][3] = cube[5][x][k][2]
                cube[5][x][k][3] = cube[0][x][k][2]
        for k in cube:
            for j in k:
                for i in j:
                    i[2] = i[3]

        for j in cube[3]:
            for i in j:
                i[3] = cube[3][i[1]][size - i[0] - 1][2]
        for j in cube[3]:
            for i in j:
                i[2] = i[3]

        for j in cube[1]:
            for i in j:
                i[3] = cube[1][size - i[1] - 1][i[0]][2]
        for j in cube[1]:
            for i in j:
                i[2] = i[3]
    if not held and keys[pygame.K_UP]:
        held = True
        x, y = int(mx / 40 - size), int(my / 40 - size)
        if 0 <= x < size and 0 <= y < size:
            for k in range(size):
                cube[4][x][k][3] = cube[0][x][k][2]
                cube[2][size - x - 1][size - k - 1][3] = cube[4][x][k][2]
                cube[5][x][k][3] = cube[2][size - x - 1][size - k - 1][2]
                cube[0][x][k][3] = cube[5][x][k][2]
            for k in cube:
                for j in k:
                    for i in j:
                        i[2] = i[3]
            if x == 0:
                for j in cube[3]:
                    for i in j:
                        i[3] = cube[3][size - i[1] - 1][i[0]][2]
                for j in cube[3]:
                    for i in j:
                        i[2] = i[3]
            elif x == size - 1:
                for j in cube[1]:
                    for i in j:
                        i[3] = cube[1][i[1]][size - i[0] - 1][2]
                for j in cube[1]:
                    for i in j:
                        i[2] = i[3]
    if not held and keys[pygame.K_s]:
        held = True
        for x in range(size):
            for k in range(size):
                cube[4][x][k][3] = cube[0][x][k][2]
                cube[2][size - x - 1][size - k - 1][3] = cube[4][x][k][2]
                cube[5][x][k][3] = cube[2][size - x - 1][size - k - 1][2]
                cube[0][x][k][3] = cube[5][x][k][2]
        for k in cube:
            for j in k:
                for i in j:
                    i[2] = i[3]

        for j in cube[3]:
            for i in j:
                i[3] = cube[3][size - i[1] - 1][i[0]][2]
        for j in cube[3]:
            for i in j:
                i[2] = i[3]

        for j in cube[1]:
            for i in j:
                i[3] = cube[1][i[1]][size - i[0] - 1][2]
        for j in cube[1]:
            for i in j:
                i[2] = i[3]
    if not held and keys[pygame.K_LEFT]:
        held = True
        x, y = int(mx / 40 - size), int(my / 40 - size)
        if 0 <= x < size and 0 <= y < size:
            for k in range(size):
                cube[0][k][y][3] = cube[1][k][y][2]
                cube[1][k][y][3] = cube[2][k][y][2]
                cube[2][k][y][3] = cube[3][k][y][2]
                cube[3][k][y][3] = cube[0][k][y][2]
            for k in cube:
                for j in k:
                    for i in j:
                        i[2] = i[3]
            if y == 0:
                for j in cube[4]:
                    for i in j:
                        i[3] = cube[4][i[1]][size - i[0] - 1][2]
                for j in cube[4]:
                    for i in j:
                        i[2] = i[3]
            elif y == size - 1:
                for j in cube[5]:
                    for i in j:
                        i[3] = cube[5][size - i[1] - 1][i[0]][2]
                for j in cube[5]:
                    for i in j:
                        i[2] = i[3]
    if not held and keys[pygame.K_d]:
        held = True
        for y in range(size):
            for k in range(size):
                cube[0][k][y][3] = cube[1][k][y][2]
                cube[1][k][y][3] = cube[2][k][y][2]
                cube[2][k][y][3] = cube[3][k][y][2]
                cube[3][k][y][3] = cube[0][k][y][2]
        for k in cube:
            for j in k:
                for i in j:
                    i[2] = i[3]

        for j in cube[4]:
            for i in j:
                i[3] = cube[4][i[1]][size - i[0] - 1][2]
        for j in cube[4]:
            for i in j:
                i[2] = i[3]
        for j in cube[5]:
            for i in j:
                i[3] = cube[5][size - i[1] - 1][i[0]][2]
        for j in cube[5]:
            for i in j:
                i[2] = i[3]
    if not held and keys[pygame.K_RIGHT]:
        held = True
        x, y = int(mx / 40 - size), int(my / 40 - size)
        if 0 <= x < size and 0 <= y < size:
            for k in range(size):
                cube[1][k][y][3] = cube[0][k][y][2]
                cube[2][k][y][3] = cube[1][k][y][2]
                cube[3][k][y][3] = cube[2][k][y][2]
                cube[0][k][y][3] = cube[3][k][y][2]
            for k in cube:
                for j in k:
                    for i in j:
                        i[2] = i[3]
            if y == 0:
                for j in cube[4]:
                    for i in j:
                        i[3] = cube[4][size - i[1] - 1][i[0]][2]
                for j in cube[4]:
                    for i in j:
                        i[2] = i[3]
            elif y == size - 1:
                for j in cube[5]:
                    for i in j:
                        i[3] = cube[5][i[1]][size - i[0] - 1][2]
                for j in cube[5]:
                    for i in j:
                        i[2] = i[3]
    if not held and keys[pygame.K_a]:
        held = True
        for y in range(size):
            for k in range(size):
                cube[1][k][y][3] = cube[0][k][y][2]
                cube[2][k][y][3] = cube[1][k][y][2]
                cube[3][k][y][3] = cube[2][k][y][2]
                cube[0][k][y][3] = cube[3][k][y][2]
        for k in cube:
            for j in k:
                for i in j:
                    i[2] = i[3]

        for j in cube[4]:
            for i in j:
                i[3] = cube[4][size - i[1] - 1][i[0]][2]
        for j in cube[4]:
            for i in j:
                i[2] = i[3]
        for j in cube[5]:
            for i in j:
                i[3] = cube[5][i[1]][size - i[0] - 1][2]
        for j in cube[5]:
            for i in j:
                i[2] = i[3]

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for j in cube[0]:
        for i in j:
            map1 = pygame.Rect(i[0] * 40 + 40 * size, i[1] * 40 + 40 * size, 40, 40)
            pygame.draw.rect(screen, (0, 0, 0), map1)
            map1 = pygame.Rect(i[0] * 40 + 40 * size, i[1] * 40 + 40 * size, 36, 36)
            pygame.draw.rect(screen, colors[i[2]], map1)
    for j in cube[1]:
        for i in j:
            map1 = pygame.Rect(i[0] * 40 + 80 * size, i[1] * 40 + 40 * size, 40, 40)
            pygame.draw.rect(screen, (0, 0, 0), map1)
            map1 = pygame.Rect(i[0] * 40 + 80 * size, i[1] * 40 + 40 * size, 36, 36)
            pygame.draw.rect(screen, colors[i[2]], map1)
    for j in cube[2]:
        for i in j:
            map1 = pygame.Rect(i[0] * 40 + 120 * size, i[1] * 40 + 40 * size, 40, 40)
            pygame.draw.rect(screen, (0, 0, 0), map1)
            map1 = pygame.Rect(i[0] * 40 + 120 * size, i[1] * 40 + 40 * size, 36, 36)
            pygame.draw.rect(screen, colors[i[2]], map1)
    for j in cube[3]:
        for i in j:
            map1 = pygame.Rect(i[0] * 40, i[1] * 40 + 40 * size, 40, 40)
            pygame.draw.rect(screen, (0, 0, 0), map1)
            map1 = pygame.Rect(i[0] * 40, i[1] * 40 + 40 * size, 36, 36)
            pygame.draw.rect(screen, colors[i[2]], map1)
    for j in cube[4]:
        for i in j:
            map1 = pygame.Rect(i[0] * 40 + size * 40, i[1] * 40, 40, 40)
            pygame.draw.rect(screen, (0, 0, 0), map1)
            map1 = pygame.Rect(i[0] * 40 + size * 40, i[1] * 40, 36, 36)
            pygame.draw.rect(screen, colors[i[2]], map1)
    for j in cube[5]:
        for i in j:
            map1 = pygame.Rect(i[0] * 40 + size * 40, i[1] * 40 + 80 * size, 40, 40)
            pygame.draw.rect(screen, (0, 0, 0), map1)
            map1 = pygame.Rect(i[0] * 40 + size * 40, i[1] * 40 + 80 * size, 36, 36)
            pygame.draw.rect(screen, colors[i[2]], map1)

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
