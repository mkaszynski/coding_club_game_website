import pygame
import time
import random

pygame.init()

# Set up the drawing window
screen = pygame.display.set_mode([1200, 600])

font = pygame.font.Font("freesansbold.ttf", 30)


def add_line(screen, text, x, y, color=(0, 0, 0)):
    # used to print the status of the variables
    text = font.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


blocks = []

place = [0, 1, 2, 3, 4, 5, 6, 7]
mine = [0, 1, 2, 3, 4, 5, 6, 7]
move = [0, 1, 2, 3, 4, 5, 6, 7]

SIZE = 20

things = [
    "air",
    "space",
    "lava",
    "molten_iron",
    "fire",
    "water",
    "stone",
    "ant",
    "holding ant",
    "plant",
    "wood",
    "activated_plant",
    "activated_wood",
    "deapslate",
    "vapor",
    "lightning",
    "iron",
    "copper",
    "hot_iron",
    "cold_iron",
    "ice",
    "wall",
    "person",
    "portal",
    "void",
]

flameables = [
    "ant",
    "plant",
    "wood",
]

pickable = [
    "wood",
    "iron",
    "cold_iron",
    "hot_iron",
    "copper",
    "plant",
    "fire",
]


def shuffle(list1):
    m = []
    while list1:
        k = random.choice(list1)
        list1.remove(k)
        m.append(k)
    return m


m = random.randint(0, len(things) - 1)

for i in range(int(60 / SIZE * 20)):
    blocks.append([])
    for j in range(int(30 / SIZE * 20)):
        if (
            i == 0
            or i == int(60 / SIZE * 20 - 1)
            or j == 0
            or j == int(30 / SIZE * 20 - 1)
        ):
            blocks[i].append([i, j, "barier"])
        else:
            blocks[i].append(
                [
                    i,
                    j,
                    "air",
                ]
            )


def coloid2(pos1, pos2):
    if pos1[0] > pos2[0] - pos1[2] and pos1[0] < pos2[0] + pos2[2]:
        if pos1[1] > pos2[1] - pos1[3] and pos1[1] < pos2[1] + pos2[3]:
            return True


def dis(pos1, pos2):
    x = abs(pos2[0] - pos1[0]) ** 2
    y = abs(pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


portals = []

time1 = 0

selection = 0

selection2 = 0

hold = False

gases = ["air", "vapor", "space", "lightning", "zaped_air", "zaping_air"]

temperatures = {
    "lava": 500,
    "molten_iron": 500,
    "space": -25,
    "fire": 250,
    "ice": -25,
    "water": 20,
    "hot_iron": 90,
    "cold_iron": 10,
    "lightning": 15000,
}


hunger = 3000
thirst = 1500
oxygen = 240
sleep = 0
heat = 50

block_hold = None

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((0, 0, 0))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    if keys[pygame.K_e] and not hold:
        selection = (selection - 1) % len(things)
        hold = True
    if keys[pygame.K_r] and not hold:
        selection = (selection + 1) % len(things)
        hold = True

    if keys[pygame.K_q] and not hold:
        selection2 = (selection2 - 1) % len(things)
        hold = True
    if keys[pygame.K_w] and not hold:
        selection2 = (selection2 + 1) % len(things)
        hold = True

    if (
        not keys[pygame.K_e]
        and not keys[pygame.K_r]
        and not keys[pygame.K_q]
        and not keys[pygame.K_w]
    ):
        hold = False

    time1 += 1

    if random.random() > 1:
        blocks[random.randint(1, 58)][1][2] = "water"

    if mouse_held[0]:
        for j in blocks:
            for i in j:
                if coloid2((mx, my, 0, 0), (i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)):
                    if not i[2] == "barier":
                        i[2] = things[selection]
    if mouse_held[2]:
        for j in blocks:
            for i in j:
                if coloid2((mx, my, 0, 0), (i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)):
                    if not i[2] == "barier":
                        i[2] = things[selection2]
    if keys[pygame.K_a]:
        for j in blocks:
            for i in j:
                if i[2] == things[selection]:
                    i[2] = things[selection2]
    if keys[pygame.K_z]:
        for j in blocks:
            for i in j:
                if i[2] == things[selection2]:
                    i[2] = things[selection]
    if keys[pygame.K_s]:
        for j in blocks:
            for i in j:
                if coloid2(
                    (mx, my, SIZE * 4, SIZE * 4), (i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                ):
                    if not i[2] == "barier":
                        i[2] = things[selection]
    if keys[pygame.K_d]:
        for j in blocks:
            for i in j:
                if coloid2(
                    (mx, my, SIZE * 4, SIZE * 4), (i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                ):
                    if not i[2] == "barier":
                        i[2] = things[selection2]

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    airs = ["air", "space", "ant", "vapor", "ice", "zaped_air"]

    person_move = False

    for j in blocks:
        sparks = []
        for x in range(int(30 / SIZE * 20)):
            sparks.append(x)
        sparks = shuffle(sparks)

        for part in range(len(j)):
            i = j[sparks[part]]
            if random.random() > 0.75:
                y = False
                if i[2] == "water":
                    try:
                        if blocks[i[0]][i[1] + 1][2] in airs:
                            i[2] = blocks[i[0]][i[1] + 1][2]
                            blocks[i[0]][i[1] + 1][2] = "water"
                        elif (
                            blocks[i[0] + 1][i[1] + 1][2] in airs
                            or blocks[i[0] - 1][i[1] + 1][2] in airs
                        ):
                            if (
                                blocks[i[0] + 1][i[1] + 1][2] in airs
                                and blocks[i[0] - 1][i[1] + 1][2] in airs
                            ):
                                if random.random() > 0.5:
                                    i[2] = blocks[i[0] + 1][i[1] + 1][2]
                                    blocks[i[0] + 1][i[1] + 1][2] = "water"
                                else:
                                    i[2] = blocks[i[0] - 1][i[1] + 1][2]
                                    blocks[i[0] - 1][i[1] + 1][2] = "water"
                            elif blocks[i[0] + 1][i[1] + 1][2] in airs:
                                i[2] = blocks[i[0] + 1][i[1] + 1][2]
                                blocks[i[0] + 1][i[1] + 1][2] = "water"
                            elif blocks[i[0] - 1][i[1] + 1][2] in airs:
                                i[2] = blocks[i[0] - 1][i[1] + 1][2]
                                blocks[i[0] - 1][i[1] + 1][2] = "water"
                        elif (
                            blocks[i[0] + 1][i[1]][2] in airs
                            or blocks[i[0] - 1][i[1]][2] in airs
                        ):
                            if (
                                blocks[i[0] + 1][i[1]][2] in airs
                                and blocks[i[0] - 1][i[1]][2] in airs
                            ):
                                if random.random() > 0.5:
                                    i[2] = blocks[i[0] + 1][i[1]][2]
                                    blocks[i[0] + 1][i[1]][2] = "water"
                                else:
                                    i[2] = blocks[i[0] - 1][i[1]][2]
                                    blocks[i[0] - 1][i[1]][2] = "water"
                            elif blocks[i[0] + 1][i[1]][2] in airs:
                                i[2] = blocks[i[0] + 1][i[1]][2]
                                blocks[i[0] + 1][i[1]][2] = "water"
                            elif blocks[i[0] - 1][i[1]][2] in airs:
                                i[2] = blocks[i[0] - 1][i[1]][2]
                                blocks[i[0] - 1][i[1]][2] = "water"
                        else:
                            if random.random() > 0.99975:
                                i[2] = "vapor"
                    except:
                        pass
            if random.random() > 0.9:
                if i[2] == "lava" or i[2] == "molten_iron":
                    self1 = i[2]
                    try:
                        if blocks[i[0]][i[1] + 1][2] in airs:
                            i[2] = blocks[i[0]][i[1] + 1][2]
                            blocks[i[0]][i[1] + 1][2] = self1
                        elif (
                            blocks[i[0] + 1][i[1] + 1][2] in airs
                            or blocks[i[0] - 1][i[1] + 1][2] in airs
                        ):
                            if (
                                blocks[i[0] + 1][i[1] + 1][2] in airs
                                and blocks[i[0] - 1][i[1] + 1][2] in airs
                            ):
                                if random.random() > 0.5:
                                    i[2] = blocks[i[0] + 1][i[1] + 1][2]
                                    blocks[i[0] + 1][i[1] + 1][2] = self1
                                else:
                                    i[2] = blocks[i[0] - 1][i[1] + 1][2]
                                    blocks[i[0] - 1][i[1] + 1][2] = self1
                            elif blocks[i[0] + 1][i[1] + 1][2] in airs:
                                i[2] = blocks[i[0] + 1][i[1] + 1][2]
                                blocks[i[0] + 1][i[1] + 1][2] = self1
                            elif blocks[i[0] - 1][i[1] + 1][2] in airs:
                                i[2] = blocks[i[0] - 1][i[1] + 1][2]
                                blocks[i[0] - 1][i[1] + 1][2] = self1
                        elif (
                            blocks[i[0] + 1][i[1]][2] in airs
                            or blocks[i[0] - 1][i[1]][2] in airs
                        ):
                            if (
                                blocks[i[0] + 1][i[1]][2] in airs
                                and blocks[i[0] - 1][i[1]][2] in airs
                            ):
                                if random.random() > 0.5:
                                    i[2] = blocks[i[0] + 1][i[1]][2]
                                    blocks[i[0] + 1][i[1]][2] = self1
                                else:
                                    i[2] = blocks[i[0] - 1][i[1]][2]
                                    blocks[i[0] - 1][i[1]][2] = self1
                            elif blocks[i[0] + 1][i[1]][2] in airs:
                                i[2] = blocks[i[0] + 1][i[1]][2]
                                blocks[i[0] + 1][i[1]][2] = self1
                            elif blocks[i[0] - 1][i[1]][2] in airs:
                                i[2] = blocks[i[0] - 1][i[1]][2]
                                blocks[i[0] - 1][i[1]][2] = self1
                        else:
                            if random.random() > 0.99 and self1 == "lava":
                                s = []
                                s.append(blocks[i[0]][i[1] - 1])
                                s.append(blocks[i[0] - 1][i[1] + 1])
                                s.append(blocks[i[0] - 1][i[1] - 1])
                                s.append(blocks[i[0] + 1][i[1] + 1])
                                s.append(blocks[i[0] + 1][i[1] - 1])
                                s.append(blocks[i[0] + 1][i[1]])
                                s.append(blocks[i[0] - 1][i[1]])
                                a = False
                                for u in s:
                                    if u[2] == "iron" or u[2] == "hot_iron":
                                        a = True
                                if not a:
                                    i[2] = "deapslate"
                            elif random.random() > 0.99 and self1 == "molten_iron":
                                i[2] = "iron"
                    except:
                        pass
            j[sparks[part]] = i

    for j in blocks:
        for i in j:
            try:
                s = []
                s.append(blocks[i[0]][i[1] + 1])
                s.append(blocks[i[0]][i[1] - 1])
                s.append(blocks[i[0] - 1][i[1] + 1])
                s.append(blocks[i[0] - 1][i[1] - 1])
                s.append(blocks[i[0] + 1][i[1] + 1])
                s.append(blocks[i[0] + 1][i[1] - 1])
                s.append(blocks[i[0] + 1][i[1]])
                s.append(blocks[i[0] - 1][i[1]])
            except:
                pass
            if i[2] == "space" and random.random() > 0.75:
                try:
                    u = random.choice(s)
                    if u[2] == "air":
                        i[2] = "air"
                        blocks[u[0]][u[1]][2] = "space"
                    elif u[2] == "water" and random.random() > 0.9:
                        blocks[u[0]][u[1]][2] = "ice"
                except:
                    pass
            if i[2] == "lightning" and random.random() > 0.75:
                try:
                    u = random.choice(s)
                    if u[2] == "air" or u[2] == "zaped_air":
                        i[2] = "zaped_air"
                        blocks[u[0]][u[1]][2] = "lightning"
                except:
                    pass
            if i[2] == "vapor" and random.random() > 0.75:
                try:
                    m = s
                    m.remove(m[0])
                    u = random.choice(m)

                    if random.random() > 0.9975:
                        i[2] = "water"
                    else:
                        if u[2] in gases:
                            if random.random() < 0.99975:
                                i[2] = blocks[u[0]][u[1]][2]
                                blocks[u[0]][u[1]][2] = "vapor"
                            elif u[2] == "air":
                                blocks[u[0]][u[1]][2] = "lightning"
                except:
                    pass
            elif i[2] == "ant":
                try:
                    if blocks[i[0]][i[1] + 1][2] == "air":
                        i[2] = "air"
                        blocks[i[0]][i[1] + 1][2] = "ant"
                    else:
                        u = s[random.choice(move)]
                        if u[2] == "air":
                            i[2] = "air"
                            blocks[u[0]][u[1]][2] = "ant"
                        elif u[2] == "plant":
                            if random.random() < 1 / 3:
                                blocks[u[0]][u[1]][2] = "ant"
                            else:
                                blocks[u[0]][u[1]][2] = "vapor"
                except:
                    pass
            elif i[2] == "person" and not person_move and time1 % 20 == 0:
                try:
                    for u in s:
                        if u[2] in temperatures:
                            heat = heat * 0.9975 + temperatures[u[2]] * 0.0025
                    heat = heat * 0.9975 + 0.0025 * 50
                except:
                    pass
                try:
                    hunger -= 1
                    thirst -= 1
                    inair = False
                    water1 = False
                    for u in s:
                        if u[2] == "air":
                            inair = True
                        elif u[2] == "water":
                            water1 = True
                    if not inair:
                        if water1:
                            oxygen -= 1
                        else:
                            oxygen -= 3
                    else:
                        if oxygen <= 234:
                            oxygen += 6
                        else:
                            oxygen = 240
                    if oxygen <= 0:
                        i[2] = "stone"
                        person_move = True
                        hunger = 3000
                        oxygen = 240
                        thirst = 1500
                        heat = 50
                        break
                    if hunger <= 0:
                        i[2] = "stone"
                        person_move = True
                        hunger = 3000
                        oxygen = 240
                        thirst = 1500
                        heat = 50
                        break
                    if thirst <= 0:
                        i[2] = "stone"
                        person_move = True
                        hunger = 3000
                        oxygen = 240
                        thirst = 1500
                        heat = 50
                        break
                    if not (0 <= heat <= 100):
                        if heat <= 0:
                            i[2] = "ice"
                        elif heat >= 100:
                            i[2] = "fire"
                        person_move = True
                        hunger = 3000
                        oxygen = 240
                        thirst = 1500
                        heat = 50
                        break

                    sleep += 1
                    if sleep > 1500 or keys[pygame.K_v]:
                        sleep = -300

                    fall = False
                    if (
                        blocks[i[0]][i[1] + 1][2] in gases
                        and blocks[i[0]][i[1] + 1][2] != "space"
                    ):
                        if not keys[pygame.K_c]:
                            i[2] = blocks[i[0]][i[1] + 1][2]
                            blocks[i[0]][i[1] + 1][2] = "person"
                            fall = True
                        else:
                            if (
                                blocks[i[0] - 1][i[1]][2] in gases
                                and blocks[i[0] - 1][i[1] + 1][2] not in gases
                            ) or (
                                blocks[i[0] + 1][i[1]][2] in gases
                                and blocks[i[0] + 1][i[1] + 1][2] not in gases
                            ):
                                fall = False
                            else:
                                i[2] = blocks[i[0]][i[1] + 1][2]
                                blocks[i[0]][i[1] + 1][2] = "person"
                                fall = True

                    if not fall and sleep >= 0:
                        move1 = []
                        if keys[pygame.K_LEFT]:
                            move1 = 7
                            if keys[pygame.K_UP]:
                                move1 = 3
                            if keys[pygame.K_DOWN]:
                                move1 = 2
                        elif keys[pygame.K_RIGHT]:
                            move1 = 6
                            if keys[pygame.K_UP]:
                                move1 = 5
                            if keys[pygame.K_DOWN]:
                                move1 = 4
                        elif keys[pygame.K_UP]:
                            move1 = 1
                        elif keys[pygame.K_DOWN]:
                            move1 = 0
                        u = s[move1]
                        if u[2] in gases:
                            if not keys[pygame.K_y]:
                                if not keys[pygame.K_x]:
                                    i[2] = blocks[u[0]][u[1]][2]
                                    blocks[u[0]][u[1]][2] = "person"
                            else:
                                if block_hold and time1 % 80 == 0:
                                    blocks[u[0]][u[1]][2] = block_hold
                                    block_hold = None
                        elif not keys[pygame.K_t]:
                            if time1 % 80 == 0 and keys[pygame.K_x]:
                                if (
                                    u[2] != "barier"
                                    and u[2] != "wall"
                                    and u[2] != "water"
                                ):
                                    if u[2] != "plant" or hunger > 2700:
                                        i[2] = blocks[u[0]][u[1]][2]
                                        blocks[u[0]][u[1]][2] = "person"
                                    else:
                                        if u[2] == "plant" and hunger < 2700:
                                            blocks[u[0]][u[1]][2] = "vapor"
                                            hunger += 300
                            if time1 % 40 == 0 and not keys[pygame.K_x]:
                                if u[2] == "water":
                                    i[2] = blocks[u[0]][u[1]][2]
                                    blocks[u[0]][u[1]][2] = "person"
                                    if random.random() > thirst / 1500:
                                        i[2] = "vapor"
                                    thirst = 1500
                        elif keys[pygame.K_t]:
                            if time1 % 80 == 0:
                                if u[2] in pickable and not block_hold:
                                    block_hold = u[2]
                                    blocks[u[0]][u[1]][2] = "air"

                        person_move = True
                except:
                    pass
            elif i[2] == "zaped_air":
                if random.random() > 0.999:
                    i[2] = "air"
            elif i[2] == "zaping_air":
                if random.random() > 0.9:
                    i[2] = "air"
            elif i[2] == "lightning":
                try:
                    for u in s:
                        if u[2] not in gases and u[2] != "water" and u[2] != "barier":
                            if u[2] in flameables:
                                blocks[u[0]][u[1]][2] = "fire"
                            if not u[2] == "person":
                                i[2] = "air"
                            for b in blocks:
                                for v in b:
                                    if v[2] == "zaped_air":
                                        v[2] = "zaping_air"
                except:
                    pass
            elif i[2] == "fire":
                try:
                    if random.random() > 0.993:
                        u = random.choice(s)
                        if u[2] in flameables:
                            blocks[u[0]][u[1]][2] = "fire"
                        if u[2] == "water" or u[2] == "space" or u[2] == "ice":
                            i[2] = "stone"
                    if random.random() > 0.99875:
                        i[2] = "stone"
                except:
                    pass
            if i[2] == "water" or i[2] == "ice":
                try:
                    for u in s:
                        if u[2] == "fire":
                            if random.random() > 0.75:
                                blocks[u[0]][u[1]][2] = "stone"
                except:
                    pass
            if i[2] == "lava":
                try:
                    if random.random() > 0.9:
                        u = random.choice(s)
                        if u[2] in flameables:
                            blocks[u[0]][u[1]][2] = "fire"
                        if u[2] == "water" or u[2] == "ice":
                            i[2] = "deapslate"
                            blocks[u[0]][u[1]][2] = "vapor"
                except:
                    pass
            elif i[2] == "molten_iron":
                try:
                    if random.random() > 0.9:
                        u = random.choice(s)
                        if u[2] in flameables:
                            blocks[u[0]][u[1]][2] = "fire"
                        if u[2] == "water" or u[2] == "ice":
                            i[2] = "iron"
                            blocks[u[0]][u[1]][2] = "vapor"
                except:
                    pass
            elif i[2] == "plant":
                try:
                    if random.random() > 0.9:
                        u = s[random.choice(move)]
                        if u[2] == "stone" or u[2] == "water":
                            i[2] = "activated_plant"
                            blocks[u[0]][u[1]][2] = "air"
                        if u[2] == "ice":
                            if random.random() < 0.7:
                                i[2] = "ice"
                                blocks[u[0]][u[1]][2] = "water"
                            else:
                                blocks[u[0]][u[1]][2] = "water"
                        if random.random() > 0.95:
                            if u[2] == "space":
                                blocks[u[0]][u[1]][2] = "air"
                except:
                    pass
            if i[2] == "activated_plant":
                try:
                    if random.random() > 0.9:
                        u = s[random.choice(move)]
                        if u[2] == "air":
                            if random.random() < 0.9:
                                i[2] = "plant"
                                blocks[u[0]][u[1]][2] = "plant"
                            else:
                                i[2] = "plant"
                                blocks[u[0]][u[1]][2] = "vapor"
                        if random.random() > 0.95:
                            if u[2] == "space":
                                blocks[u[0]][u[1]][2] = "air"
                except:
                    pass
            if i[2] == "activated_plant":
                try:
                    if random.random() > 0.9:
                        u = s[random.choice(move)]
                        if u[2] == "plant":
                            i[2] = "plant"
                            blocks[u[0]][u[1]][2] = "activated_plant"
                        if random.random() > 0.95:
                            if u[2] == "space":
                                blocks[u[0]][u[1]][2] = "air"
                except:
                    pass
            if i[2] == "activated_wood":
                try:
                    if random.random() > 0.9:
                        u = s[random.choice(move)]
                        if u[2] == "wood":
                            i[2] = "wood"
                            blocks[u[0]][u[1]][2] = "activated_wood"
                except:
                    pass
            if i[2] == "activated_wood":
                try:
                    if random.random() > 0.9:
                        u = s[random.choice(move)]
                        if u[2] == "plant":
                            i[2] = "wood"
                            blocks[u[0]][u[1]][2] = "activated_plant"
                except:
                    pass
            if i[2] == "holding ant":
                try:
                    if blocks[i[0]][i[1] + 1][2] == "air":
                        i[2] = "air"
                        blocks[i[0]][i[1] + 1][2] = "holding ant"
                    else:
                        u = s[random.choice(move)]
                        if u[2] == "air":
                            i[2] = "air"
                            blocks[u[0]][u[1]][2] = "holding ant"
                except:
                    pass
            if random.random() > 0.75:
                if i[2] == "ant":
                    try:
                        u = s[random.choice(mine)]
                        if u[2] == "stone" or u[2] == "wood":
                            i[2] = "holding ant"
                            blocks[u[0]][u[1]][2] = "air"
                    except:
                        pass
                if i[2] == "holding ant":
                    try:
                        u = s[random.choice(place)]
                        if u[2] == "air":
                            i[2] = "ant"
                            blocks[u[0]][u[1]][2] = "stone"
                    except:
                        pass
                if i[2] == "portal":
                    try:
                        u = s[random.choice(place)]
                        if (
                            u[2] != "portal"
                            and u[2] != "barier"
                            and u[2] != "wall"
                            and random.random() > 0.5
                        ):
                            if u[2] != "air":
                                portals.append(u[2])
                                blocks[u[0]][u[1]][2] = "air"
                            else:
                                blocks[u[0]][u[1]][2] = random.choice(portals)
                                portals.remove(blocks[u[0]][u[1]][2])

                    except:
                        pass
                if (i[2] == "wood" or i[2] == "plant") and random.random() > 0.9995:
                    a = False
                    for u in s:
                        if u[2] in ["plant", "stone"]:
                            a = True
                    if a:
                        i[2] = "stone"

            if i[2] == "activated_plant":
                try:
                    if random.random() > 0.9:
                        u = s[random.choice(move)]
                        if u[2] == "wood":
                            i[2] = "plant"
                            blocks[u[0]][u[1]][2] = "activated_wood"
                except:
                    pass
            if i[2] == "plant":
                try:
                    a = False
                    for k in s:
                        if k[2] == "air" or k[2] == "water":
                            a = True
                    if not a:
                        i[2] = "wood"
                    a = False
                    for k in s:
                        if (
                            k[2] == "stone"
                            or k[2] == "activated_plant"
                            or k[2] == "plant"
                            or k[2] == "wood"
                            or k[2] == "activated_wood"
                        ):
                            a = True
                    if not a:
                        i[2] = "stone"
                except:
                    pass
            elif i[2] == "stone":
                try:
                    if s[0][2] == "air":
                        i[2] = "air"
                        blocks[i[0]][i[1] + 1][2] = "stone"
                    if s[0][2] == "vapor":
                        i[2] = "vapor"
                        blocks[i[0]][i[1] + 1][2] = "stone"
                    if s[0][2] == "space":
                        i[2] = "space"
                        blocks[i[0]][i[1] + 1][2] = "stone"
                except:
                    pass
            elif i[2] == "iron":
                try:
                    u = random.choice(s)
                    if u[2] == "lava" or u[2] == "fire" or u[2] == "molten_iron":
                        if random.random() > 0.99:
                            i[2] = "hot_iron"
                    elif u[2] == "ice":
                        if random.random() > 0.99:
                            blocks[u[0]][u[1]][2] = "water"
                            i[2] = "cold_iron"
                    elif u[2] == "space":
                        if random.random() > 0.99:
                            i[2] = "cold_iron"
                except:
                    pass
            elif i[2] == "hot_iron":
                try:
                    u = random.choice(s)
                    if u[2] == "water":
                        if random.random() > 0.95:
                            i[2] = "iron"
                            blocks[u[0]][u[1]][2] = "vapor"
                    elif u[2] == "iron":
                        if random.random() > 0.9:
                            i[2] = "iron"
                            blocks[u[0]][u[1]][2] = "hot_iron"
                    elif u[2] in flameables and u[2] != "person":
                        if random.random() > 0.95:
                            blocks[u[0]][u[1]][2] = "fire"
                            i[2] = "iron"
                    elif u[2] == "ice":
                        if random.random() > 0.9:
                            blocks[u[0]][u[1]][2] = "water"
                    if random.random() > 0.9999:
                        i[2] = "iron"
                except:
                    pass
            elif i[2] == "cold_iron":
                try:
                    u = random.choice(s)
                    if u[2] == "water":
                        if random.random() > 0.95:
                            i[2] = "iron"
                            blocks[u[0]][u[1]][2] = "ice"
                    elif u[2] == "iron":
                        if random.random() > 0.9:
                            i[2] = "iron"
                            blocks[u[0]][u[1]][2] = "cold_iron"
                    elif u[2] == "hot_iron":
                        if random.random() > 0.9:
                            blocks[u[0]][u[1]][2] = "iron"
                            i[2] = "iron"
                    if random.random() > 0.9999:
                        i[2] = "iron"
                except:
                    pass
            elif i[2] == "ice":
                try:
                    if blocks[i[0]][i[1] - 1][2] == "air":
                        if random.random() > 0.9995:
                            i[2] = "vapor"
                    a = False
                    for u in s:
                        if u[2] not in ["air", "space", "vapor"]:
                            a = True
                    if not a:
                        i[2] = blocks[s[0][0]][s[0][1]][2]
                        blocks[s[0][0]][s[0][1]][2] = "ice"

                except:
                    pass
            elif i[2] == "copper":
                try:
                    c = []
                    c.append(blocks[i[0] - 2][i[1] - 2])
                    c.append(blocks[i[0] + 2][i[1] - 2])
                    c.append(blocks[i[0] - 2][i[1] + 2])
                    c.append(blocks[i[0] + 2][i[1] + 2])
                    d = []
                    d.append(blocks[i[0] - 2][i[1]])
                    d.append(blocks[i[0] + 2][i[1]])
                    d.append(blocks[i[0]][i[1] + 2])
                    d.append(blocks[i[0]][i[1] + 2])
                    power3 = False
                    for u in c:
                        if u[2] == "hot_iron":
                            if random.random() > 0.999:
                                blocks[u[0]][u[1]][2] = "iron"
                                break
                            power3 = True
                    for p in d:
                        if p[2] == "wall" or p[2] == "barier" or p[2] == "void":
                            power3 = False
                    if power3:
                        if random.random() > 0.9:
                            u = blocks[i[0] - 2][i[1]][2]
                            blocks[i[0] - 2][i[1]][2] = blocks[i[0] + 2][i[1]][2]
                            blocks[i[0] + 2][i[1]][2] = u
                        if random.random() > 0.9:
                            u = blocks[i[0]][i[1] - 2][2]
                            blocks[i[0]][i[1] - 2][2] = blocks[i[0]][i[1] + 2][2]
                            blocks[i[0]][i[1] + 2][2] = u
                except:
                    pass
            elif i[2] == "void":
                try:
                    for u in s:
                        if (
                            not u[2] == "barier"
                            and not u[2] == "wall"
                            and not u[2] == "void"
                        ):
                            blocks[u[0]][u[1]][2] = "air"
                except:
                    pass

    for j in blocks:
        for i in j:
            if i[2] == "air":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (255, 255, 255), map1)
            if i[2] == "void":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (50, 50, 50), map1)
            elif i[2] == "iron":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (175, 175, 175), map1)
            elif i[2] == "copper":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (185, 115, 50), map1)
            elif i[2] == "molten_iron":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (235, 170, 100), map1)
            elif i[2] == "hot_iron":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (255, 175, 175), map1)
            elif i[2] == "cold_iron":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (175, 175, 255), map1)
            elif i[2] == "ice":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (0, 255, 255), map1)
            elif i[2] == "lava":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (255, 128, 0), map1)
            elif i[2] == "stone":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (100, 60, 0), map1)
            elif i[2] == "deapslate":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (100, 100, 100), map1)
            elif i[2] == "ant":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (200, 0, 0), map1)
            elif i[2] == "holding ant":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (200, 30, 30), map1)
            elif i[2] == "plant":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (0, 128, 30), map1)
            elif i[2] == "activated_plant":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (0, 150, 30), map1)
            elif i[2] == "wood":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (128, 64, 0), map1)
            elif i[2] == "activated_wood":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (150, 75, 0), map1)
            elif i[2] == "water":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (0, 0, 128), map1)
            elif i[2] == "fire":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (255, 200, 0), map1)
            elif i[2] == "space":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (225, 225, 225), map1)
            elif i[2] == "lightning":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (255, 255, 255), map1)
            elif i[2] == "zaped_air":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (255, 255, 255), map1)
            elif i[2] == "zaping_air":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (225, 225, 175), map1)
            elif i[2] == "portal":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (128, 0, 225), map1)
            elif i[2] == "person":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (150, 125, 50), map1)
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE * hunger / 3000, 2)
                pygame.draw.rect(screen, (0, 255, 0), map1)
                map1 = pygame.Rect(
                    i[0] * SIZE, i[1] * SIZE + 6, SIZE - SIZE * oxygen / 240, 2
                )
                pygame.draw.rect(screen, (0, 255, 255), map1)
                map1 = pygame.Rect(
                    i[0] * SIZE, i[1] * SIZE + 2, SIZE * thirst / 1500, 2
                )
                pygame.draw.rect(screen, (0, 0, 255), map1)
                if sleep > 0:
                    map1 = pygame.Rect(
                        i[0] * SIZE, i[1] * SIZE + 4, SIZE * sleep / 1500, 2
                    )
                    pygame.draw.rect(screen, (200, 200, 200), map1)
                else:
                    map1 = pygame.Rect(
                        i[0] * SIZE, i[1] * SIZE + 4, SIZE * -sleep / 300, 2
                    )
                    pygame.draw.rect(screen, (200, 200, 200), map1)
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE + 8, SIZE * heat / 100, 2)
                pygame.draw.rect(screen, (255, 255, 0), map1)
            elif i[2] == "vapor":
                map1 = pygame.Rect(i[0] * SIZE, i[1] * SIZE, SIZE, SIZE)
                pygame.draw.rect(screen, (200, 255, 255), map1)

    add_line(screen, things[selection], SIZE, SIZE)
    add_line(screen, things[selection2], SIZE, SIZE + 60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
