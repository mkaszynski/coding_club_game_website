import pygame
import random
import math

pygame.init()

clock = pygame.time.Clock()

# Set up the drawing window
screen = pygame.display.set_mode([1800, 900])

seed = []

for i in range(30):
    seed.append(
        [
            (random.random() ** 2 * 30 + 2) / 4,
            random.random() * 100,
            random.random() * 100,
        ]
    )

seed2 = []

for i in range(15):
    seed2.append(
        [
            (random.random() ** 2 * 30 + 2) / 4,
            random.random() * 100,
        ]
    )

dest = 300000

destination = [(random.random() - 0.5) * dest, (random.random() - 0.5) * dest]


def add_line(
    screen,
    text,
    x,
    y,
    color=(0, 0, 0),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 30),
):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def dis3d(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    z = (pos2[2] - pos1[2]) ** 2
    return (x + y + z) ** 0.5


def land(x, y):
    height1 = 0
    for k in seed:
        height1 += (
            math.sin(
                ((x) / 500 * math.sin(k[2]) + (y) / 500 * math.cos(k[2])) / k[0] + k[1]
            )
            * 100
        )
    height2 = 0
    for k in seed:
        height2 += (
            math.sin(
                ((x) / 5000 * math.sin(k[2]) + (y + 10000) / 5000 * math.cos(k[2]))
                / k[0]
                + k[1]
            )
            * 60
        )
    height3 = 2000
    for k in seed:
        height3 += (
            math.sin(
                ((x + 10000) / 5000 * math.sin(k[2]) + (y) / 5000 * math.cos(k[2]))
                / k[0]
                + k[1]
            )
            * 1000
        )
    n = 0
    if height1 + height3 < height2:
        n = height1 + height3
    else:
        n = height2
    if n > 0:
        n *= 5
    return n


def winder(x, y, z):
    height1 = 0
    for k in seed:
        height1 += math.sin(
            ((x) / 5000 * math.sin(k[2]) + (y) / 5000 * math.cos(k[2])) / k[0] + k[1]
        )
    for k in seed2:
        height1 += math.sin(z / 5000 / k[0] + k[1])
    if 0 > z > -16000:
        height1 *= 1 - math.cos(-math.pi * (z + 2000) / 7000)
    else:
        height1 = 0
    return height1


def rect_alpha(x, y, w, h, c):
    rect = pygame.Rect(x, y, w, h)
    shape_surf = pygame.Surface(pygame.Rect(rect).size, pygame.SRCALPHA)
    pygame.draw.rect(shape_surf, c, shape_surf.get_rect())
    screen.blit(shape_surf, rect)


def circle_alpha(x, y, r, c):
    size = (r * 2, r * 2)
    shape_surf = pygame.Surface(size, pygame.SRCALPHA)
    pygame.draw.circle(shape_surf, c, (r, r), r)
    screen.blit(shape_surf, (x - r, y - r))


posx = (random.random() - 0.5) * dest
posy = (random.random() - 0.5) * dest
posz = land(posx, posy) - 10

while posz > 0 or posz < -500:
    posx = (random.random() - 0.5) * dest
    posy = (random.random() - 0.5) * dest
    posz = land(posx, posy) - 10

velx = 0
vely = 0
velz = 0

anglex = 0
angley = 0
anglez = 0

health = 100

fuel = 100

size = 1

wheels = True

time1 = 0

lmx = 0
lmy = 0

throttle = 0

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((100, 200, 255))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    time1 += 1

    if keys[pygame.K_c]:
        throttle -= 0.05
    if keys[pygame.K_v]:
        throttle += 0.05

    if throttle < 0:
        throttle = 0
    if throttle > 1:
        throttle = 1

    if fuel > 0:
        velx += math.cos(anglex) / 10 * throttle
        vely += math.sin(anglex) / 10 * throttle
        fuel -= 0.015 * throttle**3
    if keys[pygame.K_e]:
        size *= 0.95
    if keys[pygame.K_r]:
        size /= 0.95
    if keys[pygame.K_t]:
        size = 1

    if (
        land(destination[0], destination[1]) > 0
        or land(destination[0], destination[1]) < -500
    ):
        destination = [
            (random.random() - 0.5) * dest + posx,
            (random.random() - 0.5) * dest + posy,
        ]

    if keys[pygame.K_z]:
        wheels = False
    if keys[pygame.K_x]:
        wheels = True

    # if mouse_held[0]:
    #    anglex += (mx - lmx) / 300
    #    angley += (my - lmy) / 300
    if keys[pygame.K_w]:
        angley += 0.02
    if keys[pygame.K_s]:
        angley -= 0.02
    if keys[pygame.K_a]:
        anglex -= 0.02
    if keys[pygame.K_d]:
        anglex += 0.02

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    height1 = land(posx, posy)

    s = dis((velx, vely), (0, 0))

    if posz > height1:
        health -= max(2, (posz - height1) * s / 10) - 2
        posz = height1
        velz -= 0.15
        if not wheels:
            velx *= 0.95
            vely *= 0.95
            health -= (max(2, s / 3) - 2) / 3
        else:
            velx *= 0.993
            vely *= 0.993
        if dis((posx, posy), destination) < 1000:
            destination = [
                (random.random() - 0.5) * dest + posx,
                (random.random() - 0.5) * dest + posy,
            ]
            fuel = min(100, fuel + 50)
            health = min(100, health + 10)

    wind = [
        winder(posx + 1000000 + time1 * 5, posy + 1000000, posz),
        winder(posx - 1000000 + time1 * 5, posy + 1000000, posz),
        winder(posx + 1000000 + time1 * 5, posy - 1000000, posz),
    ]

    posx += velx
    posy += vely
    posz += velz

    velx -= wind[0]
    vely -= wind[1]
    velz -= wind[2]

    velz += 0.1

    velx *= 0.9995
    vely *= 0.9995
    velz *= 0.9995

    if wheels:
        velx = (velx - wind[0]) * 0.999 + wind[0]
        vely = (vely - wind[1]) * 0.999 + wind[1]
        velz = (velz - wind[2]) * 0.999 + wind[2]

    elif posz > 0:
        velz *= 0.9
        velx *= 0.9
        vely *= 0.9

    s = dis((velx, vely), (0, 0))
    velx = (math.cos(anglex) * s) * 0.01 + velx * 0.99
    vely = (math.sin(anglex) * s) * 0.01 + vely * 0.99

    airdense = max(0, 50000 + posz) / 50000

    if -math.pi < angley < 0:
        velx += (
            math.cos(angley - math.pi / 2)
            * abs(math.sin(angley))
            * dis((velx, vely), (0, 0))
            / 40
            * airdense
            * math.cos(anglex)
        )
        vely += (
            math.cos(angley - math.pi / 2)
            * abs(math.sin(angley))
            * dis((velx, vely), (0, 0))
            / 40
            * airdense
            * math.sin(anglex)
        )
        velz += (
            math.sin(angley - math.pi / 2)
            * -math.sin(angley)
            * dis((velx, vely), (0, 0))
            / 40
            * airdense
        )

        velz += (
            math.sin(angley + math.pi / 2)
            * abs(math.cos(angley))
            * -velz
            / 40
            * airdense
        )
        velx += (
            math.cos(angley + math.pi / 2)
            * math.cos(angley)
            * -velz
            / 40
            * airdense
            * math.cos(anglex)
        )
        vely += (
            math.cos(angley + math.pi / 2)
            * math.cos(angley)
            * -velz
            / 40
            * airdense
            * math.sin(anglex)
        )

    velx += wind[0]
    vely += wind[1]
    velz += wind[2]

    for i in range(20):
        for j in range(12):
            x = posx + (i - 9) * 100 * math.cos(anglex) * size
            y = posy + (i - 9) * 100 * math.sin(anglex) * size
            wind1 = [
                winder(
                    x + 1000000 + time1 * 5, y + 1000000, posz + (j - 4.5) * 100 * size
                ),
                winder(
                    x - 1000000 + time1 * 5, y + 1000000, posz + (j - 4.5) * 100 * size
                ),
                winder(
                    x + 1000000 + time1 * 5, y - 1000000, posz + (j - 4.5) * 100 * size
                ),
            ]
            if dis3d(wind1, (0, 0, 0)) > 5.01:
                # pygame.draw.circle(
                #    screen,
                #    (175, 175, 175),
                #    (i * 100, j * 100),
                #    min((dis3d(wind1, (0, 0, 0)) - 5) ** 0.5 * 25, 150),
                # )
                circle_alpha(
                    i * 100,
                    j * 100,
                    50 + (dis3d(wind1, (0, 0, 0)) - 5) * 3,
                    (175, 175, 175, min((dis3d(wind1, (0, 0, 0)) - 5) * 20, 255)),
                )

    for j in range(4):
        for i in range(200):
            height = land(
                posx
                + (i - 90) * 10 * math.cos(anglex) * size
                + math.cos(anglex + math.pi / 2) * 50 * (j - 3) * size,
                posy
                + (i - 90) * 10 * math.sin(anglex) * size
                + math.sin(anglex + math.pi / 2) * 50 * (j - 3) * size,
            )
            if height > 0:
                map1 = pygame.Rect(i * 10, (-posz) / size + 448, 10, 2000)
                pygame.draw.rect(screen, (0, 0, 200), map1)
            if height > -3000:
                map1 = pygame.Rect(i * 10, (height - posz) / size + 450, 10, 2000)
                pygame.draw.rect(screen, (0, 100 + 50 / 3 * j, 0), map1)
            else:
                map1 = pygame.Rect(i * 10, (height - posz) / size + 450, 10, 2000)
                pygame.draw.rect(
                    screen, (100 + 50 / 3 * j, 100 + 50 / 3 * j, 100 + 50 / 3 * j), map1
                )
            map1 = pygame.Rect(i * 10, (height - posz + 1000) / size + 450, 10, 2000)
            pygame.draw.rect(screen, (100, 64, 0), map1)

    if dis3d(wind, (0, 0, 0)) > 5:
        rect_alpha(
            0,
            0,
            2000,
            1500,
            (100, 100, 100, 255 * min(0.8, (dis3d(wind, (0, 0, 0)) - 5) / 10)),
        )

    map1 = pygame.Rect(-10, 500 - 10, 220, 220)
    pygame.draw.rect(screen, (100, 64, 0), map1)
    for i in range(20):
        for j in range(20):
            x = posx + (i - 10) * 100 * size
            y = posy + (j - 10) * 100 * size
            # x = x * math.cos(anglex) - y * math.sin(anglex)
            # y = x * math.sin(anglex) + y * math.cos(anglex)
            height = land(
                x,
                y,
            )
            if int(x / 100 / size) != int(destination[0] / 100 / size) or int(
                y / 100 / size
            ) != int(destination[1] / 100 / size):
                if height > 0:
                    map1 = pygame.Rect(i * 10, j * 10 + 500, 10, 10)
                    pygame.draw.rect(screen, (0, 0, 200), map1)
                elif height > -3000:
                    map1 = pygame.Rect(i * 10, j * 10 + 500, 10, 10)
                    pygame.draw.rect(screen, (0, 150, 0), map1)
                else:
                    map1 = pygame.Rect(i * 10, j * 10 + 500, 10, 10)
                    pygame.draw.rect(screen, (150, 150, 150), map1)
            else:
                map1 = pygame.Rect(i * 10, j * 10 + 500, 10, 10)
                pygame.draw.rect(screen, (255, 0, 255), map1)

    map1 = pygame.Rect(150, 300, 10, 100)
    pygame.draw.rect(screen, (120, 120, 120), map1)
    map1 = pygame.Rect(150, 401 - throttle * 100, 10, throttle * 100)
    pygame.draw.rect(screen, (0, 255, 0), map1)

    pygame.draw.line(
        screen,
        (0, 0, 0),
        (900 - math.cos(angley) * 50 / size, 450 - math.sin(angley) * 50 / size),
        (900 + math.cos(angley) * 100 / size, 450 + math.sin(angley) * 100 / size),
        width=int(10 / size + 1),
    )

    if wheels:
        pygame.draw.line(
            screen,
            (0, 0, 0),
            (900, 450),
            (900, 450 + 10 / size),
            width=int(5 / size + 1),
        )

    pygame.draw.line(
        screen,
        (255, 0, 0),
        (100, 600),
        (100 + math.cos(anglex) * 20, 600 + math.sin(anglex) * 20),
        width=int(3),
    )
    pygame.draw.line(
        screen,
        (0, 0, 200),
        (100, 600),
        (100 - math.cos(anglex) * 20, 600 - math.sin(anglex) * 20),
        width=int(3),
    )

    add_line(
        screen,
        "altitude: "
        + str(-int(posz))
        + "m, ground height: "
        + str(-int(height1))
        + "m",
        0,
        0,
    )
    add_line(
        screen,
        "velocity: "
        + str(int(dis3d((velx, vely, velz), (0, 0, 0)) * 3.6 * 4))
        + "km/h, wind relative velocity: "
        + str(int(dis3d((velx, vely, velz), wind) * 3.6 * 4))
        + "km/h",
        0,
        30,
    )
    add_line(
        screen,
        "plane health: " + str(int(health)) + "%, fuel: " + str(int(fuel)) + "%",
        0,
        60,
    )
    add_line(
        screen,
        "wind speed: " + str(int(dis3d(wind, (0, 0, 0)) * 3.6 * 4)) + "km/h",
        0,
        90,
    )

    add_line(
        screen,
        "vertical rise: " + str(int(-velz * 3.6 * 4)) + "km/h",
        0,
        120,
    )

    add_line(
        screen,
        "fuel use: " + str(int(0.015 * throttle**3 * 3.6 * 4 * 4000)) + "L/h",
        0,
        150,
    )

    add_line(
        screen,
        "nose angle: "
        + str(int(-angley / math.pi * 180))
        + "°, rotation angle: "
        + str(int(anglex / math.pi * 180 % 360))
        + "°",
        0,
        180,
    )

    if health <= 0:
        running = False

    lmx = mx
    lmy = my

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
