import pygame
import random
import pickle

pygame.init()

font = pygame.font.Font("freesansbold.ttf", 32)

directory = input("file name? ")

try:
    movie = pickle.load(open(directory + ".mov", "rb"))

except:
    movie = []
    u = []
    for i in range(60):
        o = []
        for j in range(30):
            o.append([i, j, [255, 255, 255]])
        u.append(o)

    movie.append(u)


def add_line(screen, text, x, y):
    # used to print the status of the variables
    text = font.render(text, True, (0, 0, 0))
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


clock = pygame.time.Clock()

# Set up the drawing window
screen = pygame.display.set_mode([1200, 600])


def rect_alpha(x, y, w, h, c):
    rect = pygame.Rect(x, y, w, h)
    shape_surf = pygame.Surface(pygame.Rect(rect).size, pygame.SRCALPHA)
    pygame.draw.rect(shape_surf, c, shape_surf.get_rect())
    screen.blit(shape_surf, rect)


def coloid2(pos1, pos2):
    if pos1[0] > pos2[0] - pos1[2] and pos1[0] < pos2[0] + pos2[2]:
        if pos1[1] > pos2[1] - pos1[3] and pos1[1] < pos2[1] + pos2[3]:
            return True


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


pos = 0

time1 = 0

color = [0, 0, 0]
color_2 = [255, 255, 255]

color_type = 2

color2 = False

size = 1

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((128, 128, 128))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    time1 += 1

    if keys[pygame.K_e]:
        if time1 % 15 == 0:
            pos -= 1
    if keys[pygame.K_r]:
        if time1 % 15 == 0:
            pos += 1

    if keys[pygame.K_p]:
        if time1 % 40 == 0:
            if len(movie) > 1:
                movie.remove(movie[pos])
                pos -= 1

    if pos < 0:
        pos = 0

    if pos + 1 > len(movie):
        u = []
        for i in range(60):
            o = []
            for j in range(30):
                o.append(
                    [
                        i,
                        j,
                        [
                            movie[pos - 1][i][j][2][0],
                            movie[pos - 1][i][j][2][1],
                            movie[pos - 1][i][j][2][2],
                        ],
                    ]
                )
            u.append(o)

        movie.append(u)

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if not color2 and mouse_held[0]:
        for j in movie[pos]:
            for i in j:
                if coloid2(
                    (mx - 5, my - 5, 10 * size, 10 * size),
                    (i[0] * 20, i[1] * 20, 20, 20),
                ):
                    movie[pos][movie[pos].index(j)][j.index(i)][2] = [
                        color[0],
                        color[1],
                        color[2],
                    ]

    if keys[pygame.K_z]:
        color2 = True
    if keys[pygame.K_x]:
        color2 = False

    if mouse_held[2] and time1 % 30 == 0:
        n = color
        color = color_2
        color_2 = n

    if keys[pygame.K_q]:
        size *= 0.97
    if keys[pygame.K_w]:
        size /= 0.97

    if keys[pygame.K_f]:
        color = [
            movie[pos][int(mx / 20)][int(my / 20)][2][0],
            movie[pos][int(mx / 20)][int(my / 20)][2][1],
            movie[pos][int(mx / 20)][int(my / 20)][2][2],
        ]

    if keys[pygame.K_c]:
        color[color_type] = (color[color_type] - 3) % 255
    if keys[pygame.K_v]:
        color[color_type] = (color[color_type] + 3) % 255

    if keys[pygame.K_a]:
        color_type = 0
    if keys[pygame.K_s]:
        color_type = 1
    if keys[pygame.K_d]:
        color_type = 2

    if color2:
        if mouse_held[0]:
            if mx < 400 and my < 400:
                if color_type == 2:
                    color[0] = mx / 400 * 255
                    color[1] = my / 400 * 255
                if color_type == 1:
                    color[0] = mx / 400 * 255
                    color[2] = my / 400 * 255
                if color_type == 0:
                    color[1] = mx / 400 * 255
                    color[2] = my / 400 * 255

    for j in movie[pos]:
        for i in j:
            if not keys[pygame.K_g]:
                map1 = pygame.Rect(i[0] * 20, i[1] * 20, 20, 20)
                pygame.draw.rect(screen, i[2], map1)
            else:
                map1 = pygame.Rect(i[0] * 20, i[1] * 20, 19, 19)
                pygame.draw.rect(screen, i[2], map1)

    if color2:
        for i in range(80):
            for j in range(80):
                if color_type == 2:
                    map1 = pygame.Rect(i * 5, j * 5, 5, 5)
                    pygame.draw.rect(
                        screen, (i / 80 * 255, j / 80 * 255, color[2]), map1
                    )
                if color_type == 1:
                    map1 = pygame.Rect(i * 5, j * 5, 5, 5)
                    pygame.draw.rect(
                        screen, (i / 80 * 255, color[1], j / 80 * 255), map1
                    )
                if color_type == 0:
                    map1 = pygame.Rect(i * 5, j * 5, 5, 5)
                    pygame.draw.rect(
                        screen, (color[0], i / 80 * 255, j / 80 * 255), map1
                    )

    map1 = pygame.Rect(mx - 5, my - 5, 10 * size, 10 * size)
    pygame.draw.rect(screen, color, map1)

    add_line(screen, str(pos), 200, 0)

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()

pickle.dump(movie, open(directory + ".mov", "wb"))
