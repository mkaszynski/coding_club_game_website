import pygame
import random
import time
import numpy as np
import math
import os
import copy

IMAGE_PATH = "assets/"

pygame.init()

clock = pygame.time.Clock()

HEIGHT, WIDTH = 1800, 900

# Set up the drawing window
screen = pygame.display.set_mode([HEIGHT, WIDTH])

AIR = 0
DIRT = 1
STONE = 2
BELT1 = 3
BELT2 = 4
BELT3 = 5
BELT4 = 6
PLANT = 7
SUNLIGHT = 8
POLE = 9
POLE_NEG = 10
POLE_POS = 11
SOLAR = 12
LAMP = 13
BATTERY = 14
BATTERY_ON = 15
BURNER = 16
IRON_CHUNK = 17
COPPER_CHUNK = 18
COAL = 19
MINER = 20
TRANSFORMER = 21
SMELTER = 22
IRON = 23
COPPER = 24
POLUTION = 25
INSERTER = 26
ASSEMBLER = 27
WIRE = 28
CIRCUT = 29
GEAR = 30

blocks = []

SIZE = 50
BSIZE = 50

brightness = 1

for i in range(SIZE * 2):
    collum = []
    for j in range(SIZE):
        if j > SIZE - 20 + random.randint(0, 1):
            collum.append([i, j, STONE])
        elif j > SIZE - 23 + random.randint(0, 2):
            collum.append([i, j, DIRT])
        else:
            collum.append([i, j, SUNLIGHT])
    blocks.append(collum)


labels = {
    AIR: "air",
    DIRT: "dirt",
    STONE: "stone",
    BELT1: "belt_down",
    BELT2: "belt_up",
    BELT3: "belt_right",
    BELT4: "belt_left",
    PLANT: "plant",
    SUNLIGHT: "sunlight",
    POLE: "pole",
    POLE_NEG: "pole_neg",
    POLE_POS: "pole_pos",
    SOLAR: "solar",
    LAMP: "lamp",
    BATTERY: "battery",
    BATTERY_ON: "battery_on",
    BURNER: "burner",
    IRON_CHUNK: "iron_chunk",
    COPPER_CHUNK: "copper_chunk",
    COAL: "coal",
    MINER: "miner",
    TRANSFORMER: "transformer",
    SMELTER: "smelter",
    IRON: "iron",
    COPPER: "copper",
    POLUTION: "polution",
    INSERTER: "inserter",
    ASSEMBLER: "assembler",
    WIRE: "wire",
    CIRCUT: "circut",
    GEAR: "gear",
}

belts = [BELT1, BELT2, BELT3, BELT4]

airs = [AIR, SUNLIGHT]

unmovable = [
    AIR,
    SUNLIGHT,
    BELT1,
    BELT2,
    BELT3,
    BELT4,
    POLE,
    POLE_POS,
    SOLAR,
    LAMP,
    BURNER,
    MINER,
    TRANSFORMER,
    SMELTER,
    POLUTION,
    INSERTER,
    ASSEMBLER,
]

flameable = {PLANT: 0.5, COAL: 0.05}

mineable = {STONE: [DIRT], DIRT: [IRON_CHUNK, COPPER_CHUNK, COAL]}

polute_factor = 0.5

crafts = [
    [[COPPER, COPPER, COPPER], WIRE],
    [[IRON, IRON, IRON], GEAR],
    [[IRON, IRON, WIRE], CIRCUT],
    [[IRON, GEAR, WIRE], MINER],
    [[IRON, COPPER, BURNER], SMELTER],
    [[IRON, COPPER, COPPER], BURNER],
    [[GEAR, CIRCUT, WIRE], ASSEMBLER],
    [[IRON, CIRCUT, WIRE], INSERTER],
    [[WIRE, WIRE], POLE],
    [[POLE, CIRCUT, WIRE], TRANSFORMER],
    [[WIRE, WIRE, CIRCUT], SOLAR],
    [[WIRE, CIRCUT, CIRCUT], SOLAR],
    [[POLE_POS, CIRCUT, WIRE], BATTERY],
    [[IRON, GEAR, GEAR], BELT1],
    [[BELT1], BELT2],
    [[BELT2], BELT3],
    [[BELT3], BELT4],
]


def polute():
    if random.random() > polute_factor:
        return AIR
    else:
        return POLUTION


def AIRcls(i, blocks1):
    if i[1] == 0:
        if random.random() < brightness:
            blocks1[i[0]][i[1]][2] = SUNLIGHT
        else:
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def POLUTIONcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    u = random.choice(s)
    if blocks1[u[0]][u[1]][2] in airs:
        i[2] = blocks1[u[0]][u[1]][2]
        blocks1[u[0]][u[1]][2] = POLUTION
    return blocks1


def DIRTcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = DIRT
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def IRON_CHUNKcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = IRON_CHUNK
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def COPPER_CHUNKcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = COPPER_CHUNK
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def COALcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = COAL
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def IRONcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = IRON
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def COPPERcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = COPPER
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def WIREcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = WIRE
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def CIRCUTcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = CIRCUT
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def GEARcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = GEAR
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def STONEcls(i, blocks1):
    return blocks1


def BELT1cls(i, blocks1):
    if (
        blocks1[i[0] + 1][i[1] + 1][2] in airs
        and blocks1[i[0] + 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] + 1][2] = blocks1[i[0] + 1][i[1]][2]
        blocks1[i[0] + 1][i[1]][2] = AIR
    if (
        blocks1[i[0] - 1][i[1] + 1][2] in airs
        and blocks1[i[0] - 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] + 1][2] = blocks1[i[0] - 1][i[1]][2]
        blocks1[i[0] - 1][i[1]][2] = AIR
    return blocks1


def BELT2cls(i, blocks1):
    if (
        blocks1[i[0] + 1][i[1] - 1][2] in airs
        and blocks1[i[0] + 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] - 1][2] = blocks1[i[0] + 1][i[1]][2]
        blocks1[i[0] + 1][i[1]][2] = AIR
    if (
        blocks1[i[0] - 1][i[1] - 1][2] in airs
        and blocks1[i[0] - 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] - 1][2] = blocks1[i[0] - 1][i[1]][2]
        blocks1[i[0] - 1][i[1]][2] = AIR
    return blocks1


def BELT3cls(i, blocks1):
    if (
        blocks1[i[0] + 1][i[1] + 1][2] in airs
        and blocks1[i[0]][i[1] + 1][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] + 1][2] = blocks1[i[0]][i[1] + 1][2]
        blocks1[i[0]][i[1] + 1][2] = AIR
    if (
        blocks1[i[0] + 1][i[1] - 1][2] in airs
        and blocks1[i[0]][i[1] - 1][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] - 1][2] = blocks1[i[0]][i[1] - 1][2]
        blocks1[i[0]][i[1] - 1][2] = AIR
    return blocks1


def BELT4cls(i, blocks1):
    if (
        blocks1[i[0] - 1][i[1] + 1][2] in airs
        and blocks1[i[0]][i[1] + 1][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] + 1][2] = blocks1[i[0]][i[1] + 1][2]
        blocks1[i[0]][i[1] + 1][2] = AIR
    if (
        blocks1[i[0] - 1][i[1] - 1][2] in airs
        and blocks1[i[0]][i[1] - 1][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] - 1][2] = blocks1[i[0]][i[1] - 1][2]
        blocks1[i[0]][i[1] - 1][2] = AIR
    return blocks1


def PLANTcls(i, blocks1):
    if blocks1[i[0]][i[1] + 1][2] == DIRT:
        if (
            blocks1[i[0] + 1][i[1] + 1][2] == DIRT
            and blocks1[i[0] + 1][i[1]][2] in airs
            and blocks1[i[0]][i[1] - 1][2] == SUNLIGHT
            and random.random() < 0.05
        ):
            blocks1[i[0] + 1][i[1]][2] = PLANT
        if (
            blocks1[i[0] - 1][i[1] + 1][2] == DIRT
            and blocks1[i[0] - 1][i[1]][2] in airs
            and blocks1[i[0]][i[1] - 1][2] == SUNLIGHT
            and random.random() < 0.05
        ):
            blocks1[i[0] - 1][i[1]][2] = PLANT
        if blocks1[i[0]][i[1] - 1][2] == POLUTION:
            blocks1[i[0]][i[1] - 1][2] = AIR
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def SUNLIGHTcls(i, blocks1):
    if blocks1[i[0]][i[1] - 1][2] != SUNLIGHT:
        if i[1] > 0:
            blocks1[i[0]][i[1]][2] = AIR
        else:
            if random.random() < brightness:
                blocks1[i[0]][i[1]][2] = SUNLIGHT
            else:
                blocks1[i[0]][i[1]][2] = AIR
    if blocks1[i[0]][i[1] + 1][2] == AIR:
        blocks1[i[0]][i[1] + 1][2] = SUNLIGHT
    return blocks1


def POLEcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    for u in s:
        if blocks1[i[0]][i[1]][2] == POLE:
            if u[2] == POLE_POS:
                blocks1[i[0]][i[1]][2] = POLE_POS
                blocks1[u[0]][u[1]][2] = POLE
    return blocks1


def POLE_NEGcls(i, blocks1):
    return blocks1


def POLE_POScls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    for u in s:
        if blocks1[i[0]][i[1]][2] == POLE_POS:
            if u[2] == POLE:
                blocks1[i[0]][i[1]][2] = POLE
                blocks1[u[0]][u[1]][2] = POLE_POS
    return blocks1


def SOLARcls(i, blocks1):
    if blocks1[i[0]][i[1] - 1][2] == SUNLIGHT and random.random() < 0.125:
        if blocks1[i[0]][i[1] + 1][2] == POLE:
            blocks1[i[0]][i[1] + 1][2] = POLE_POS
        elif blocks1[i[0] - 1][i[1]][2] == POLE:
            blocks1[i[0] - 1][i[1]][2] = POLE_POS
        elif blocks1[i[0] + 1][i[1]][2] == POLE:
            blocks1[i[0] + 1][i[1]][2] = POLE_POS
    return blocks1


def LAMPcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    u = random.choice(s)
    if u[2] == POLE_POS:
        if blocks1[i[0]][i[1] + 1][2] == AIR:
            blocks1[i[0]][i[1] + 1][2] = SUNLIGHT
            blocks1[u[0]][u[1]][2] = POLE
    return blocks1


def BATTERYcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    for u in s:
        if u[2] == POLE_POS and blocks1[i[0]][i[1]][2] == BATTERY:
            if random.random() > 0.99:
                blocks1[i[0]][i[1]][2] = BATTERY_ON
            blocks1[u[0]][u[1]][2] = POLE
    return blocks1


def BATTERY_ONcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    for u in s:
        if u[2] == POLE and blocks1[i[0]][i[1]][2] == BATTERY_ON:
            if random.random() > 0.99:
                blocks1[i[0]][i[1]][2] = BATTERY
            blocks1[u[0]][u[1]][2] = POLE_POS
    return blocks1


def BURNERcls(i, blocks1):
    if blocks1[i[0]][i[1] - 1][2] in flameable:
        s = []
        s.append(blocks1[i[0] - 1][i[1]])
        s.append(blocks1[i[0] + 1][i[1]])
        s.append(blocks1[i[0]][i[1] - 1])
        s.append(blocks1[i[0]][i[1] + 1])
        s.append(blocks1[i[0] - 2][i[1]])
        s.append(blocks1[i[0] + 2][i[1]])
        s.append(blocks1[i[0]][i[1] - 2])
        s.append(blocks1[i[0]][i[1] + 2])
        s.append(blocks1[i[0] - 3][i[1]])
        s.append(blocks1[i[0] + 3][i[1]])
        s.append(blocks1[i[0]][i[1] - 3])
        s.append(blocks1[i[0]][i[1] + 3])
        s.append(blocks1[i[0] - 4][i[1]])
        s.append(blocks1[i[0] + 4][i[1]])
        s.append(blocks1[i[0]][i[1] - 4])
        s.append(blocks1[i[0]][i[1] + 4])
        random.shuffle(s)
        for u in s:
            if u[2] == POLE and blocks1[i[0]][i[1] - 1][2] in flameable:
                if random.random() < flameable[blocks1[i[0]][i[1] - 1][2]]:
                    blocks1[i[0]][i[1] - 1][2] = polute()
                blocks1[u[0]][u[1]][2] = POLE_POS
    return blocks1


def MINERcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    if (
        blocks1[i[0]][i[1] - 1][2] in airs
        and blocks1[i[0]][i[1] + 1][2] in mineable
        and random.random() > 0.5
    ):
        for u in s:
            if u[2] == POLE_POS and blocks1[i[0]][i[1] - 1][2] in airs:
                if random.random() < 0.5:
                    blocks1[i[0]][i[1] - 1][2] = random.choice(
                        mineable[blocks1[i[0]][i[1] + 1][2]]
                    )
                blocks1[u[0]][u[1]][2] = POLE
                if random.random() < 0.2:
                    blocks1[i[0]][i[1] + 1][2] = POLUTION
    return blocks1


def SMELTERcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    for u in s:
        if (
            u[2] == POLE_POS
            and blocks1[i[0]][i[1] - 1][2] == COPPER_CHUNK
            and blocks1[i[0]][i[1] + 1][2] in airs
        ):
            if random.random() < 0.5:
                blocks1[i[0]][i[1] + 1][2] = COPPER
            blocks1[i[0]][i[1] - 1][2] = polute()
            blocks1[u[0]][u[1]][2] = POLE
        if (
            u[2] == POLE_POS
            and blocks1[i[0]][i[1] + 1][2] == IRON_CHUNK
            and blocks1[i[0]][i[1] - 1][2] in airs
        ):
            if random.random() < 0.5:
                blocks1[i[0]][i[1] - 1][2] = IRON
            blocks1[i[0]][i[1] + 1][2] = polute()
            blocks1[u[0]][u[1]][2] = POLE
    return blocks1


def ASSEMBLERcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    if blocks1[i[0]][i[1] - 1][2] in airs:
        u = random.choice(s)
        if u[2] == POLE_POS:
            m = []
            m.append(blocks1[i[0] - 1][i[1]][2])
            m.append(blocks1[i[0] + 1][i[1]][2])
            m.append(blocks1[i[0]][i[1] + 1][2])
            for k in crafts:
                j = copy.deepcopy(k[0])
                for v in m:
                    if v in j:
                        j.remove(v)
                if len(j) == 0:
                    blocks1[i[0] - 1][i[1]][2] = polute()
                    blocks1[i[0] + 1][i[1]][2] = polute()
                    blocks1[i[0]][i[1] + 1][2] = polute()
                    blocks1[i[0]][i[1] - 1][2] = k[1]
                    blocks1[u[0]][u[1]][2] = POLE
                    j = k[0]
                    break
    return blocks1


def TRANSFORMERcls(i, blocks1):
    if blocks1[i[0]][i[1] - 1][2] == POLE_POS and blocks1[i[0]][i[1] + 2][2] == POLE:
        blocks1[i[0]][i[1] - 1][2] = POLE
        blocks1[i[0]][i[1] + 2][2] = POLE_POS
    if blocks1[i[0]][i[1] + 1][2] == POLE_POS and blocks1[i[0]][i[1] - 2][2] == POLE:
        blocks1[i[0]][i[1] + 1][2] = POLE
        blocks1[i[0]][i[1] - 2][2] = POLE_POS
    if blocks1[i[0] - 1][i[1]][2] == POLE_POS and blocks1[i[0] + 2][i[1]][2] == POLE:
        blocks1[i[0] - 1][i[1]][2] = POLE
        blocks1[i[0] + 2][i[1]][2] = POLE_POS
    if blocks1[i[0] + 1][i[1]][2] == POLE_POS and blocks1[i[0] - 2][i[1]][2] == POLE:
        blocks1[i[0] + 1][i[1]][2] = POLE
        blocks1[i[0] - 2][i[1]][2] = POLE_POS
    return blocks1


def INSERTERcls(i, blocks1):
    if (
        (
            blocks1[i[0]][i[1] - 2][2] == blocks1[i[0]][i[1] - 1][2]
            or blocks1[i[0]][i[1] - 1][2] == 0
        )
        and blocks1[i[0]][i[1] + 4][2] in airs
        and blocks1[i[0]][i[1] - 2][2] not in airs
    ):
        blocks1[i[0]][i[1] + 4][2] = blocks1[i[0]][i[1] - 2][2]
        blocks1[i[0]][i[1] - 2][2] = AIR
    if (
        (
            blocks1[i[0]][i[1] + 2][2] == blocks1[i[0]][i[1] + 1][2]
            or blocks1[i[0]][i[1] + 1][2] == 0
        )
        and blocks1[i[0]][i[1] - 4][2] in airs
        and blocks1[i[0]][i[1] + 2][2] not in airs
    ):
        blocks1[i[0]][i[1] - 4][2] = blocks1[i[0]][i[1] + 2][2]
        blocks1[i[0]][i[1] + 2][2] = AIR
    if (
        (
            blocks1[i[0] - 2][i[1]][2] == blocks1[i[0] - 1][i[1]][2]
            or blocks1[i[0] - 1][i[1]][2] == 0
        )
        and blocks1[i[0] + 4][i[1]][2] in airs
        and blocks1[i[0] - 2][i[1]][2] not in airs
    ):
        blocks1[i[0] + 4][i[1]][2] = blocks1[i[0] - 2][i[1]][2]
        blocks1[i[0] - 2][i[1]][2] = AIR
    if (
        (
            blocks1[i[0] + 2][i[1]][2] == blocks1[i[0] + 1][i[1]][2]
            or blocks1[i[0] + 1][i[1]][2] == 0
        )
        and blocks1[i[0] - 4][i[1]][2] in airs
        and blocks1[i[0] + 2][i[1]][2] not in airs
    ):
        blocks1[i[0] - 4][i[1]][2] = blocks1[i[0] + 2][i[1]][2]
        blocks1[i[0] + 2][i[1]][2] = AIR
    return blocks1


functions = {
    AIR: AIRcls,
    DIRT: DIRTcls,
    STONE: STONEcls,
    BELT1: BELT1cls,
    BELT2: BELT2cls,
    BELT3: BELT3cls,
    BELT4: BELT4cls,
    PLANT: PLANTcls,
    SUNLIGHT: SUNLIGHTcls,
    POLE: POLEcls,
    POLE_NEG: POLE_NEGcls,
    POLE_POS: POLE_POScls,
    SOLAR: SOLARcls,
    LAMP: LAMPcls,
    BATTERY: BATTERYcls,
    BATTERY_ON: BATTERY_ONcls,
    BURNER: BURNERcls,
    IRON_CHUNK: IRON_CHUNKcls,
    COPPER_CHUNK: COPPER_CHUNKcls,
    COAL: COALcls,
    MINER: MINERcls,
    TRANSFORMER: TRANSFORMERcls,
    SMELTER: SMELTERcls,
    IRON: IRONcls,
    COPPER: COPPERcls,
    POLUTION: POLUTIONcls,
    INSERTER: INSERTERcls,
    WIRE: WIREcls,
    CIRCUT: CIRCUTcls,
    ASSEMBLER: ASSEMBLERcls,
}


def add_line(
    screen,
    text,
    x,
    y,
    color=(0, 0, 0),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 30),
):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def load_image(image_label):
    image_file = os.path.join(IMAGE_PATH, f"{image_label}.png")
    if not os.path.isfile(image_file):
        return None
    image = pygame.image.load(image_file).convert_alpha()
    image.set_colorkey((0, 0, 0))
    image = pygame.transform.scale(image, (BSIZE, BSIZE))
    return image


images = {block_label: load_image(label) for block_label, label in labels.items()}


held = False
select = 0

selection = [
    DIRT,
    STONE,
    PLANT,
    BELT1,
    BELT2,
    BELT3,
    BELT4,
    POLE,
    TRANSFORMER,
    SOLAR,
    LAMP,
    BATTERY,
    BURNER,
    MINER,
    SMELTER,
    COAL,
    IRON,
    COPPER,
    WIRE,
    CIRCUT,
    GEAR,
    INSERTER,
    ASSEMBLER,
]

fps = time.time()

time1 = 0

posx = 1000
posy = 1000

scrolx = 1000
scroly = 1000

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((100, 200, 255))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    time1 += 1

    if keys[pygame.K_w]:
        scroly -= 30
    if keys[pygame.K_s]:
        scroly += 30
    if keys[pygame.K_a]:
        scrolx -= 30
    if keys[pygame.K_d]:
        scrolx += 30

    posx = posx * 0.875 + scrolx * 0.125
    posy = posy * 0.875 + scroly * 0.125

    if not keys[pygame.K_e] and not keys[pygame.K_r]:
        held = False

    if keys[pygame.K_e] and not held:
        select = (select - 1) % len(selection)
        held = True
    if keys[pygame.K_r] and not held:
        select = (select + 1) % len(selection)
        held = True

    if mouse_held[0]:
        if SIZE * BSIZE * 2 > mx + posx > 0 and SIZE * BSIZE > my + posy > 0:
            blocks[int((mx + posx) / BSIZE)][int((my + posy) / BSIZE)][2] = selection[
                select
            ]
    if mouse_held[2]:
        if SIZE * BSIZE * 2 > mx + posx > 0 and SIZE * BSIZE > my + posy > 0:
            blocks[int((mx + posx) / BSIZE)][int((my + posy) / BSIZE)][2] = 0
    if keys[pygame.K_q]:
        if SIZE * BSIZE * 2 > mx + posx > 0 and SIZE * BSIZE > my + posy > 0:
            try:
                select = selection.index(
                    blocks[int((mx + posx) / BSIZE)][int((my + posy) / BSIZE)][2]
                )
            except:
                pass

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for m in range(400):
        pos = [
            random.randint(0, SIZE * 2 - 1),
            random.randint(0, SIZE - 1),
        ]
        try:
            i = blocks[pos[0]][pos[1]]
            blocks = functions[i[2]](i, blocks)
        except:
            pass

    for j in blocks:
        for i in j:
            image = images[i[2]]
            if image:
                rect = image.get_rect()
                rect.center = (
                    i[0] * BSIZE + BSIZE / 2 - posx,
                    i[1] * BSIZE + BSIZE / 2 - posy,
                )
                screen.blit(image, rect)

    add_line(screen, "fps: " + str(int(1 / (time.time() - fps))), 0, 0)
    add_line(screen, "select: " + labels[selection[select]], 0, 30)
    fps = time.time()

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
