import random

AIR = 0
DIRT = 1
STONE = 2
BELT1 = 3
BELT2 = 4
BELT3 = 5
BELT4 = 6
PLANT = 7
SUNLIGHT = 8
POLE = 9
POLE_NEG = 10
POLE_POS = 11
SOLAR = 12
LAMP = 13
BATTERY = 14
BATTERY_ON = 15
BURNER = 16
IRON_ORE = 17
COPPER_ORE = 18
COAL_ORE = 19
IRON_CHUNK = 20
COPPER_CHUNK = 21
COAL = 22
MINER = 23

SIZE = 50

belts = [BELT1, BELT2, BELT3, BELT4]

airs = [AIR, SUNLIGHT]

unmovable = [
    AIR,
    SUNLIGHT,
    BELT1,
    BELT2,
    BELT3,
    BELT4,
    POLE,
    POLE_POS,
    SOLAR,
    LAMP,
    BATTERY,
    BATTERY_ON,
    BURNER,
]

flameable = {PLANT: 0.5, COAL: 0.125}

mineable = {IRON_ORE: IRON_CHUNK, COPPER_ORE: COPPER_CHUNK, COAL_ORE: COAL}


def AIRcls(i, blocks1):
    if i[1] == 0:
        blocks1[i[0]][i[1]][2] = SUNLIGHT
    return blocks1


def DIRTcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = DIRT
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def IRON_CHUNKcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = IRON_CHUNK
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def COPPER_CHUNKcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = COPPER_CHUNK
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def COALcls(i, blocks1):
    if i[1] < SIZE - 1 and 0 < i[0] < SIZE * 2 - 1:
        if (
            blocks1[i[0]][i[1] + 1][2] in airs
            and blocks1[i[0] + 1][i[1]][2] not in belts
            and blocks1[i[0] - 1][i[1]][2] not in belts
        ):
            blocks1[i[0]][i[1] + 1][2] = COAL
            blocks1[i[0]][i[1]][2] = AIR
    return blocks1


def STONEcls(i, blocks1):
    return blocks1


def IRON_OREcls(i, blocks1):
    return blocks1


def COPPER_OREcls(i, blocks1):
    return blocks1


def COAL_OREcls(i, blocks1):
    return blocks1


def BELT1cls(i, blocks1):
    if (
        blocks1[i[0] + 1][i[1] + 1][2] in airs
        and blocks1[i[0] + 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] + 1][2] = blocks1[i[0] + 1][i[1]][2]
        blocks1[i[0] + 1][i[1]][2] = AIR
    if (
        blocks1[i[0] - 1][i[1] + 1][2] in airs
        and blocks1[i[0] - 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] + 1][2] = blocks1[i[0] - 1][i[1]][2]
        blocks1[i[0] - 1][i[1]][2] = AIR
    return blocks1


def BELT2cls(i, blocks1):
    if (
        blocks1[i[0] + 1][i[1] - 1][2] in airs
        and blocks1[i[0] + 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] - 1][2] = blocks1[i[0] + 1][i[1]][2]
        blocks1[i[0] + 1][i[1]][2] = AIR
    if (
        blocks1[i[0] - 1][i[1] - 1][2] in airs
        and blocks1[i[0] - 1][i[1]][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] - 1][2] = blocks1[i[0] - 1][i[1]][2]
        blocks1[i[0] - 1][i[1]][2] = AIR
    return blocks1


def BELT3cls(i, blocks1):
    if (
        blocks1[i[0] + 1][i[1] + 1][2] in airs
        and blocks1[i[0]][i[1] + 1][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] + 1][2] = blocks1[i[0]][i[1] + 1][2]
        blocks1[i[0]][i[1] + 1][2] = AIR
    if (
        blocks1[i[0] + 1][i[1] - 1][2] in airs
        and blocks1[i[0]][i[1] - 1][2] not in unmovable
    ):
        blocks1[i[0] + 1][i[1] - 1][2] = blocks1[i[0]][i[1] - 1][2]
        blocks1[i[0]][i[1] - 1][2] = AIR
    return blocks1


def BELT4cls(i, blocks1):
    if (
        blocks1[i[0] - 1][i[1] + 1][2] in airs
        and blocks1[i[0]][i[1] + 1][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] + 1][2] = blocks1[i[0]][i[1] + 1][2]
        blocks1[i[0]][i[1] + 1][2] = AIR
    if (
        blocks1[i[0] - 1][i[1] - 1][2] in airs
        and blocks1[i[0]][i[1] - 1][2] not in unmovable
    ):
        blocks1[i[0] - 1][i[1] - 1][2] = blocks1[i[0]][i[1] - 1][2]
        blocks1[i[0]][i[1] - 1][2] = AIR
    return blocks1


def PLANTcls(i, blocks1):
    if (
        blocks1[i[0] + 1][i[1] + 1][2] == DIRT
        and blocks1[i[0] + 1][i[1]][2] in airs
        and blocks1[i[0]][i[1] - 1][2] == SUNLIGHT
        and random.random() > 0.95
    ):
        blocks1[i[0] + 1][i[1]][2] = PLANT
    if (
        blocks1[i[0] - 1][i[1] + 1][2] == DIRT
        and blocks1[i[0] - 1][i[1]][2] in airs
        and blocks1[i[0]][i[1] - 1][2] == SUNLIGHT
        and random.random() > 0.95
    ):
        blocks1[i[0] - 1][i[1]][2] = PLANT
    return blocks1


def SUNLIGHTcls(i, blocks1):
    if blocks1[i[0]][i[1] - 1][2] != SUNLIGHT and i[1] > 0:
        blocks1[i[0]][i[1]][2] = AIR
    if blocks1[i[0]][i[1] + 1][2] == AIR:
        blocks1[i[0]][i[1] + 1][2] = SUNLIGHT
    return blocks1


def POLEcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    for u in s:
        if blocks1[i[0]][i[1]][2] == POLE:
            if u[2] == POLE_POS:
                blocks1[i[0]][i[1]][2] = POLE_POS
                blocks1[u[0]][u[1]][2] = POLE
    return blocks1


def POLE_NEGcls(i, blocks1):
    return blocks1


def POLE_POScls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    for u in s:
        if blocks1[i[0]][i[1]][2] == POLE_POS:
            if u[2] == POLE:
                blocks1[i[0]][i[1]][2] = POLE
                blocks1[u[0]][u[1]][2] = POLE_POS
    return blocks1


def SOLARcls(i, blocks1):
    if blocks1[i[0]][i[1] - 1][2] == SUNLIGHT and random.random() > 0.5:
        if blocks1[i[0]][i[1] + 1][2] == POLE:
            blocks1[i[0]][i[1] + 1][2] = POLE_POS
        elif blocks1[i[0] - 1][i[1]][2] == POLE:
            blocks1[i[0] - 1][i[1]][2] = POLE_POS
        elif blocks1[i[0] + 1][i[1]][2] == POLE:
            blocks1[i[0] + 1][i[1]][2] = POLE_POS
    return blocks1


def LAMPcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    u = random.choice(s)
    if u[2] == POLE_POS:
        if blocks1[i[0]][i[1] + 1][2] == AIR:
            blocks1[i[0]][i[1] + 1][2] = SUNLIGHT
            blocks1[u[0]][u[1]][2] = POLE
    return blocks1


def BATTERYcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    for u in s:
        if u[2] == POLE_POS and blocks1[i[0]][i[1]][2] == BATTERY:
            if random.random() > 0.99:
                blocks1[i[0]][i[1]][2] = BATTERY_ON
            blocks1[u[0]][u[1]][2] = POLE
    return blocks1


def BATTERY_ONcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    for u in s:
        if u[2] == POLE and blocks1[i[0]][i[1]][2] == BATTERY_ON:
            if random.random() > 0.99:
                blocks1[i[0]][i[1]][2] = BATTERY
            blocks1[u[0]][u[1]][2] = POLE_POS
    return blocks1


def BURNERcls(i, blocks1):
    if blocks1[i[0]][i[1] - 1][2] in flameable:
        s = []
        s.append(blocks1[i[0] - 1][i[1]])
        s.append(blocks1[i[0] + 1][i[1]])
        s.append(blocks1[i[0]][i[1] - 1])
        s.append(blocks1[i[0]][i[1] + 1])
        s.append(blocks1[i[0] - 2][i[1]])
        s.append(blocks1[i[0] + 2][i[1]])
        s.append(blocks1[i[0]][i[1] - 2])
        s.append(blocks1[i[0]][i[1] + 2])
        s.append(blocks1[i[0] - 3][i[1]])
        s.append(blocks1[i[0] + 3][i[1]])
        s.append(blocks1[i[0]][i[1] - 3])
        s.append(blocks1[i[0]][i[1] + 3])
        s.append(blocks1[i[0] - 4][i[1]])
        s.append(blocks1[i[0] + 4][i[1]])
        s.append(blocks1[i[0]][i[1] - 4])
        s.append(blocks1[i[0]][i[1] + 4])
        random.shuffle(s)
        for u in s:
            if u[2] == POLE and blocks1[i[0]][i[1] - 1][2] in flameable:
                if random.random() < flameable[blocks1[i[0]][i[1] - 1][2]]:
                    blocks1[i[0]][i[1] - 1][2] = AIR
                blocks1[u[0]][u[1]][2] = POLE_POS
    return blocks1


def MINERcls(i, blocks1):
    s = []
    s.append(blocks1[i[0] - 1][i[1]])
    s.append(blocks1[i[0] + 1][i[1]])
    s.append(blocks1[i[0]][i[1] - 1])
    s.append(blocks1[i[0]][i[1] + 1])
    s.append(blocks1[i[0] - 2][i[1]])
    s.append(blocks1[i[0] + 2][i[1]])
    s.append(blocks1[i[0]][i[1] - 2])
    s.append(blocks1[i[0]][i[1] + 2])
    s.append(blocks1[i[0] - 3][i[1]])
    s.append(blocks1[i[0] + 3][i[1]])
    s.append(blocks1[i[0]][i[1] - 3])
    s.append(blocks1[i[0]][i[1] + 3])
    s.append(blocks1[i[0] - 4][i[1]])
    s.append(blocks1[i[0] + 4][i[1]])
    s.append(blocks1[i[0]][i[1] - 4])
    s.append(blocks1[i[0]][i[1] + 4])
    random.shuffle(s)
    if blocks1[i[0]][i[1] - 1][2] in airs and blocks1[i[0]][i[1] + 1][2] in mineable:
        for u in s:
            if u[2] == POLE_POS and blocks1[i[0]][i[1] - 1][2] in airs:
                if random.random() < 0.25:
                    blocks1[i[0]][i[1] - 1][2] = mineable[blocks1[i[0]][i[1] + 1][2]]
                blocks1[u[0]][u[1]][2] = POLE_POS
                if random.random() < 0.0025:
                    blocks1[i[0]][i[1] + 1][2] = AIR
    return blocks1
