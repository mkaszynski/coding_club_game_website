import pygame
import time
import random
import math

pygame.init()

# Set up the drawing window
screen = pygame.display.set_mode([1200, 600])

objects = [[0, 0, 0, 0, (255, 0, 0)]]


def dis(pos1, pos2):
    x = abs(pos2[0] - pos1[0]) ** 2
    y = abs(pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def angle2(pos2, pos1):
    n = 0
    n = math.atan2(pos2[1] - pos1[1], pos2[0] - pos1[0])
    return n - 45 / math.pi


posx, posy = 0, 0

setpos = (255, 0, 0)

sight = False

posa = 0

lvx, lvy = 0, 0

size = 1

time1 = 0

light_speed = 1000


# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    if sight:
        screen.fill((0, 30, 30))
    else:
        screen.fill((0, 0, 0))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    time1 += 1

    if keys[pygame.K_e]:
        sight = True
    if keys[pygame.K_r]:
        sight = False
    if sight:
        if keys[pygame.K_a]:
            posa -= 0.1
        if keys[pygame.K_d]:
            posa += 0.1
    for i in objects:
        if i[4] == setpos:
            k = objects.index(i)
    if not sight:
        if keys[pygame.K_a]:
            objects[k][2] -= 3
        if keys[pygame.K_d]:
            objects[k][2] += 3
        if keys[pygame.K_w]:
            objects[k][3] -= 3
        if keys[pygame.K_s]:
            objects[k][3] += 3
    else:
        if keys[pygame.K_w]:
            objects[k][2] -= math.cos(posa + math.pi / 2) * 3
            objects[k][3] -= math.sin(posa + math.pi / 2) * 3
        if keys[pygame.K_s]:
            objects[k][2] += math.cos(posa + math.pi / 2) * 3
            objects[k][3] += math.sin(posa + math.pi / 2) * 3

    if time1 % 10 == 0:
        if keys[pygame.K_DOWN]:
            size /= 2
        if keys[pygame.K_UP]:
            size *= 2

    for i in objects:
        for j in objects:
            if not i == j:
                if dis((i[0], i[1]), (j[0], j[1])) < 20:
                    m = [i[0], i[1], i[2], i[3]]
                    n = [j[0], j[1], j[2], j[3]]
                    i[2] = m[2] * 0.9 + n[2] * 0.1
                    i[3] = m[3] * 0.9 + n[3] * 0.1
                    j[2] = n[2] * 0.9 + m[2] * 0.1
                    j[3] = n[3] * 0.9 + m[3] * 0.1
                try:
                    i[2] += 5 * (j[0] - i[0]) / dis((i[0], i[1]), (j[0], j[1])) ** 2
                    i[3] += 5 * (j[1] - i[1]) / dis((i[0], i[1]), (j[0], j[1])) ** 2
                except:
                    pass
                # try:
                if dis((i[0], i[1]), (j[0], j[1])) < 14:
                    i[2] -= (j[0] - i[0]) / 2
                    i[3] -= (j[1] - i[1]) / 2
                # except:
                #     pass

    for i in objects:
        try:
            i[0] += (
                i[2]
                / 5
                * light_speed
                / dis((0, 0), (i[2] / 5, i[3] / 5))
                * dis((0, 0), (i[2] / 5, i[3] / 5))
                / (dis((0, 0), (i[2] / 5, i[3] / 5)) + light_speed)
            )
            i[1] += (
                i[3]
                / 5
                * light_speed
                / dis((0, 0), (i[2] / 5, i[3] / 5))
                * dis((0, 0), (i[2] / 5, i[3] / 5))
                / (dis((0, 0), (i[2] / 5, i[3] / 5)) + light_speed)
            )
        except:
            pass

    if len(objects) > 100:
        objects.remove(random.choice(objects))

    for i in objects:
        if dis((i[0], i[1]), (0, 0)) > 1000000:
            i[0] = -i[0] * 0.99
            i[1] = -i[1] * 0.99

    n = False
    for i in objects:
        if i[4] == setpos:
            n = True

    if not n:
        setpos = random.choice(objects)[4]

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if not sight:
        x, y = 0, 0

        for i in objects:
            if i[4] == setpos:
                x, y = i[0], i[1]

        vx, vy = 0, 0

        for i in objects:
            if i[4] == setpos:
                vx, vy = i[2], i[3]

        # print(
        #    dis((0, 0), (vx / 5, vy / 5))
        #    / (dis((0, 0), (vx / 5, vy / 5)) + light_speed)
        # )

        if mouse_held[2]:
            for i in objects:
                if (
                    dis(((mx - 600) * size + x, (my - 300) * size + y), (i[0], i[1]))
                    < 10 * size
                ):
                    setpos = i[4]

        if mouse_held[0]:
            objects.append(
                [
                    (mx - 600) * size + x,
                    (my - 300) * size + y,
                    vx,
                    vy,
                    (
                        random.random() * 255,
                        random.random() * 255,
                        random.random() * 255,
                    ),
                ]
            )

        if size > 200:
            pygame.draw.circle(
                screen,
                (255, 255, 255),
                (600 - x / size, 300 - y / size),
                1010000 / size,
                width=int(10000 / size + 1),
            )

        for i in objects:
            map1 = pygame.Rect(
                (i[0] - x) / size + 600,
                (i[1] - y) / size + 300,
                10 / size + 1,
                10 / size + 1,
            )
            pygame.draw.rect(screen, i[4], map1)

        if keys[pygame.K_f]:
            for i in objects:
                pygame.draw.line(
                    screen,
                    (255, 255, 255),
                    (600, 300),
                    (i[0] - x + 600, i[1] - y + 300),
                    width=int(
                        (dis((600, 300), (i[0] - x + 600, i[1] - y + 300))) / 1000 + 1
                    ),
                )
    else:
        x, y = 0, 0

        for i in objects:
            if i[4] == setpos:
                x, y = i[0], i[1]

        vx, vy = 0, 0

        for i in objects:
            if i[4] == setpos:
                vx, vy = i[2], i[3]

        for i in objects:
            try:
                map1 = pygame.Rect(
                    math.sin(-angle2((i[0], i[1]), (x, y)) + posa) * 600 + 600,
                    math.cos(-angle2((i[0], i[1]), (x, y)) + posa) * 600 + 600,
                    20 / dis((x, y), (i[0], i[1])) * 500 + 1,
                    20 / dis((x, y), (i[0], i[1])) * 500 + 1,
                )
                pygame.draw.rect(screen, i[4], map1)
            except:
                pass
        map1 = pygame.Rect(0, 550 - (((lvx + lvy) - (vx + vy)) * 2), 2000, 2000)
        pygame.draw.rect(screen, i[4], map1)

        if not vx == lvx or vy == lvy:
            lvx = vx
            lvy = vy
    time.sleep(1 / 60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
