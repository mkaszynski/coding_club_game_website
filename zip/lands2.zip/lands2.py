import pygame
import time
import random
from copy import copy
import numpy as np
import matplotlib.pyplot as plt

screen_size = 2

fsize = 600

size = [[1, 0], [1, 0], [1, 0], [1, 0]]
positions = [[], [], [], []]

pygame.init()

# Set up the drawing window
screen = pygame.display.set_mode([fsize * screen_size, fsize * screen_size])

people = []

font = pygame.font.Font("freesansbold.ttf", 16)


def add_line(screen, text, x, y):
    # used to print the status of the variables
    text = font.render(text, True, (0, 0, 0))
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


def dis(pos1, pos2):
    x = abs(pos2[0] - pos1[0]) ** 2
    y = abs(pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def dis3d(pos1, pos2):
    x = abs(pos2[0] - pos1[0]) ** 2
    y = abs(pos2[1] - pos1[1]) ** 2
    z = abs(pos2[2] - pos1[2]) ** 2
    return (x + y + z) ** 0.5


for i in range(50):
    people.append(
        [
            random.random() * fsize,
            random.random() * fsize,
            False,
            (random.random() * 255, random.random() * 255, random.random() * 255),
            0,
            1/3,
        ]
    )

ocean = []

for i in range(50):
    ocean.append([random.random() * 1200, random.random() * 600])

deaths = 0

births = 0

time1 = 0

peoples = []

person = 0

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((0, 128, 0))
    pygame.event.poll()
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    time1 += 1

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    if mouse_held[0]:
        people.append(
            [
                mx / screen_size,
                my / screen_size,
                False,
                (random.random() * 255, random.random() * 255, random.random() * 255),
                0,
                1 / 3,
            ]
        )
    if mouse_held[2]:
        for i in people:
            if dis((i[0], i[1]), (mx / screen_size, my / screen_size)) < 20:
                people.remove(i)

    for i in people:
        i[0] += random.random() * 2 - 1
        i[1] += random.random() * 2 - 1
        if i[5] < 0:
            i[5] = 0
        if i[5] > 1:
            i[5] = 1
        if i[0] > fsize - 10:
            i[0] = fsize - 10
        if i[0] < 0:
            i[0] = 0
        if i[1] > fsize - 10:
            i[1] = fsize - 10
        if i[1] < 0:
            i[1] = 0
        n = 0
        m = 0
        if not i[2]:
            if random.random() > 0.99:
                if len(people) < 150:
                    i[4] += 0.7
                    births += 1
                    r = i[3][0] + random.random() * 10 - 5
                    g = i[3][1] + random.random() * 10 - 5
                    b = i[3][2] + random.random() * 10 - 5
                    if r > 255:
                        r = 255
                    if r < 0:
                        r = 0
                    if g > 255:
                        g = 255
                    if g < 0:
                        g = 0
                    if b > 255:
                        b = 255
                    if b < 0:
                        b = 0
                    m = False
                    if random.random() < i[5]:
                        m = True

                    people.append(
                        [
                            i[0],
                            i[1],
                            m,
                            (r, g, b),
                            0,
                            i[5] + random.random() * 0.1 - 0.05,
                        ]
                    )
        for j in people:
            if not j == i:
                try:
                    if not i[2]:
                        if (
                            dis3d(
                                (i[3][0], i[3][1], i[3][2]), (j[3][0], j[3][1], j[3][2])
                            )
                            > 15
                        ):
                            if dis((i[0], i[1]), (j[0], j[1])) < 200:
                                n -= (
                                    (j[0] - i[0]) / dis((i[0], i[1]), (j[0], j[1])) / 10
                                )
                                m -= (
                                    (j[1] - i[1]) / dis((i[0], i[1]), (j[0], j[1])) / 10
                                )
                except:
                    pass
                try:
                    if dis((i[0], i[1]), (j[0], j[1])) < 5:
                        i[0] -= (j[0] - i[0]) / dis((i[0], i[1]), (j[0], j[1]))
                        i[1] -= (j[1] - i[1]) / dis((i[0], i[1]), (j[0], j[1]))
                except:
                    pass
        if i[2]:
            y = 200
            o = 0
            for j in people:
                if dis3d((i[3][0], i[3][1], i[3][2]), (j[3][0], j[3][1], j[3][2])) > 15:
                    if dis((i[0], i[1]), (j[0], j[1])) < y:
                        y = dis((i[0], i[1]), (j[0], j[1]))
                        o = people.index(j)
            if not y == 200:
                for j in people:
                    if o == people.index(j):
                        try:
                            if (
                                dis3d(
                                    (i[3][0], i[3][1], i[3][2]),
                                    (j[3][0], j[3][1], j[3][2]),
                                )
                                > 15
                            ):
                                if 10 < dis((i[0], i[1]), (j[0], j[1])) < 200:
                                    n = (
                                        (j[0] - i[0])
                                        / dis((i[0], i[1]), (j[0], j[1]))
                                        * 1.5
                                    )
                                    m = (
                                        (j[1] - i[1])
                                        / dis((i[0], i[1]), (j[0], j[1]))
                                        * 1.5
                                    )
                                elif dis((i[0], i[1]), (j[0], j[1])) <= 15:
                                    x = random.random()
                                    if j[2]:
                                        if x < 0.3:
                                            people.remove(i)
                                            j[4] += 3
                                            if (
                                                dis3d(
                                                    (i[3][0], i[3][1], i[3][2]),
                                                    (j[3][0], j[3][1], j[3][2]),
                                                )
                                                > 40
                                            ):
                                                deaths += 1
                                            continue
                                    if x > 0.7:
                                        people.remove(j)
                                        if (
                                            dis3d(
                                                (i[3][0], i[3][1], i[3][2]),
                                                (j[3][0], j[3][1], j[3][2]),
                                            )
                                            > 40
                                        ):
                                            deaths += 1
                                        continue
                        except:
                            pass

        try:
            if people.index(i) != person:
                if dis((0, 0), (n, m)) > 2:
                    i[0] += n / dis((0, 0), (n, m)) * 2
                    i[1] += m / dis((0, 0), (n, m)) * 2
                else:
                    i[0] += n
                    i[1] += m
            else:
                if keys[pygame.K_w]:
                    i[1] -= 1.5
                if keys[pygame.K_s]:
                    i[1] += 1.5
                if keys[pygame.K_a]:
                    i[0] -= 1.5
                if keys[pygame.K_d]:
                    i[0] += 1.5
        except:
            pass

    for i in people:
        for j in ocean:
            if i[4] < 6:
                if dis((i[0], i[1]), (j[0], j[1])) < 50:
                    i[0] += (i[0] - j[0]) / dis((i[0], i[1]), (j[0], j[1])) * 5
                    i[1] += (i[1] - j[1]) / dis((i[0], i[1]), (j[0], j[1])) * 5

    for i in people:
        if random.random() > 0.9975 and not people.index(i) == person:
            people.remove(i)

    for i in ocean:
        pygame.draw.circle(
            screen,
            (0, 0, 255),
            (i[0] * screen_size, i[1] * screen_size),
            50 * screen_size,
        )

    for i in peoples:
        map1 = pygame.Rect(
            peoples.index(i) * 10 * screen_size,
            0 * screen_size,
            10 * screen_size,
            i[1] * screen_size,
        )
        pygame.draw.rect(screen, i[0], map1)

    for i in people:
        if people.index(i) == person:
            map1 = pygame.Rect(
                i[0] * screen_size - 2 * screen_size,
                i[1] * screen_size - 2 * screen_size,
                14 * screen_size,
                14 * screen_size,
            )
            pygame.draw.rect(screen, (128, 0, 255), map1)
        if i[2]:
            map1 = pygame.Rect(
                i[0] * screen_size - 1 * screen_size,
                i[1] * screen_size - 1 * screen_size,
                12 * screen_size,
                12 * screen_size,
            )
            pygame.draw.rect(screen, (255, 0, 0), map1)
        map1 = pygame.Rect(
            i[0] * screen_size, i[1] * screen_size, 10 * screen_size, 10 * screen_size
        )
        pygame.draw.rect(screen, i[3], map1)
        if i[4] > 5:
            map1 = pygame.Rect(
                i[0] * screen_size + 2 * screen_size,
                i[1] * screen_size + 2 * screen_size,
                6 * screen_size,
                6 * screen_size,
            )
            pygame.draw.rect(screen, (0, 0, 255), map1)
        if dis((mx / screen_size, my / screen_size), (i[0], i[1])) < 30:
            map1 = pygame.Rect(
                i[0] * screen_size,
                i[1] * screen_size,
                10 * screen_size,
                10 * screen_size * i[5],
            )
            pygame.draw.rect(screen, (255, 255, 0), map1)
        # add_line(screen, str(i[4]), i[0], i[1])

    if time1 % 30 == 0:
        peoples = []

        for i in people:
            n = False
            k = False
            for j in peoples:
                if dis3d(i[3], j[0]) < 15:
                    if not k:
                        j[1] += 1
                    n = True
                    k = True
            if not n:
                peoples.append([i[3], 1])

    size[0][0] = len(people)
    size[0][1] += 1
    positions[0].append(copy([size[0][1], size[0][0]]))

    if time1 % 30 == 0:
        size[1][0] = deaths / (len(people) + 1)
        size[1][1] += 30
        positions[1].append(copy([size[1][1], size[1][0]]))
        deaths = 0

    if time1 % 30 == 0:
        size[2][0] = births
        size[2][1] += 30
        positions[2].append(copy([size[2][1], size[2][0]]))
        births = 0

    if time1 % 30 == 0:
        size[3][0] = len(peoples)
        size[3][1] += 30
        positions[3].append(copy([size[3][1], size[3][0]]))

    time.sleep(1 / 60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()

positions1 = np.array(positions[0])

plt.plot(positions1[:, 0], positions1[:, 1])
plt.show()

positions1 = np.array(positions[1])

plt.plot(positions1[:, 0], positions1[:, 1])
plt.show()

positions1 = np.array(positions[2])

plt.plot(positions1[:, 0], positions1[:, 1])
plt.show()

positions1 = np.array(positions[3])

plt.plot(positions1[:, 0], positions1[:, 1])
plt.show()
