import pygame
import random
import copy

pygame.init()

clock = pygame.time.Clock()

# Set up the drawing window
screen = pygame.display.set_mode([1800, 900])

planets = []

beams = []

ships = []

colors = {
    "solar": (0, 100, 255),
    "engine": (255, 128, 0),
    "energy": (255, 255, 0),
    "battery": (0, 255, 255),
    "factory": (128, 128, 128),
    "computer": (255, 255, 200),
    "scrap": (200, 200, 200),
    "weapons": (255, 0, 0),
}

name = "you"
k = name

x = 3000
y = 3000

dead_code = [
    "if at planet goto 4",
    "if scrap > 2 goto 4",
    "travel nearest planet",
    "build factory",
    "build computer",
    "build solar",
    "build engine",
    "build battery",
    "build weapons",
    "if scrap < 85 goto 13",
    "construct",
    "travel random planet",
    "if nearest enemy > nearest sun goto 17",
    "if energy < 20 goto 17",
    "set weapons on",
    "goto 1",
    "set weapons off",
]

for i in range(10):
    ships.append(
        [
            x,
            y,
            0,
            0,
            100,
            {
                "solar": [50, True],
                "engine": [30, True],
                "energy": [0, True],
                "battery": [20, True],
                "factory": [20, True],
                "computer": [10, True],
                "scrap": [0, True],
                "weapons": [0, False],
            },
            [x, y],
            dead_code,
            0,
            k,
        ]
    )
    dead_code = [
        "if at planet goto 4",
        "if scrap > 2 goto 4",
        "travel nearest planet",
        "build factory",
        "build computer",
        "build solar",
        "build engine",
        "build battery",
        "if scrap < 85 goto 1",
        "construct",
        "travel random planet",
    ]
    x = random.random() * 400000 - 200000
    y = random.random() * 400000 - 200000
    k = "enemy"

select_line = -1

tip_key = ""


def compair(line, i):
    n1 = [0, 0]
    if line[1] == "nearest" and line[2] == "planet":
        k = [1000000, 1000000]
        for j in planets:
            if not j[3]["sun"] and dis(k, (i[0], i[1])) > dis(
                (i[0], i[1]), (j[0], j[1])
            ):
                k = [j[0] + random.random(), j[1] + random.random()]
        n1 = k
    elif line[1] == "farthest" and line[2] == "planet":
        k = [i[0], i[1]]
        for j in planets:
            if not j[3]["sun"] and dis(k, (i[0], i[1])) < dis(
                (i[0], i[1]), (j[0], j[1])
            ):
                k = [j[0] + random.random(), j[1] + random.random()]
        n1 = k
    elif line[1] == "nearest" and line[2] == "enemy":
        k = [1000000, 1000000]
        for j in ships:
            if (
                dis(k, (i[0], i[1])) > dis((i[0], i[1]), (j[0], j[1]))
                and dis((i[0], i[1]), (j[0], j[1])) > 0
                and j[9] != i[9]
            ):
                k = [j[0] + random.random(), j[1] + random.random()]
        n1 = k
    elif line[1] == "farthest" and line[2] == "enemy":
        k = [i[0], i[1]]
        for j in ships:
            if (
                dis(k, (i[0], i[1])) < dis((i[0], i[1]), (j[0], j[1]))
                and dis((i[0], i[1]), (j[0], j[1])) > 0
                and j[9] != i[9]
            ):
                k = [j[0] + random.random(), j[1] + random.random()]
        n1 = k
    elif line[1] == "nearest" and line[2] == "sun":
        k = [1000000, 1000000]
        for j in planets:
            if j[3]["sun"] and dis(k, (i[0], i[1])) > dis((i[0], i[1]), (j[0], j[1])):
                k = [j[0] + random.random(), j[1] + random.random()]
        n1 = k
    elif line[1] == "farthest" and line[2] == "sun":
        k = [i[0], i[1]]
        for j in planets:
            if j[3]["sun"] and dis(k, (i[0], i[1])) < dis((i[0], i[1]), (j[0], j[1])):
                k = [j[0] + random.random(), j[1] + random.random()]
        n1 = k
    elif line[1] == "random" and line[2] == "planet":
        k = []
        for j in planets:
            if not j[3]["sun"]:
                k.append([j[0] + random.random(), j[1] + random.random()])
        n1 = random.choice(k)
    elif line[1] == "random" and line[2] == "enemy":
        k = []
        for j in ships:
            if dis((i[0], i[1]), (j[0], j[1])) > 0 and j[9] != i[9]:
                k.append([j[0] + random.random(), j[1] + random.random()])
        n1 = random.choice(k)
    elif line[1] == "random" and line[2] == "sun":
        k = []
        for j in planets:
            if j[3]["sun"]:
                k.append([j[0] + random.random(), j[1] + random.random()])
        n1 = random.choice(k)
    return dis(n1, (i[0], i[1]))


def dis(pos1, pos2):
    """Calculate the distance between two 2d points."""
    x = (pos2[0] - pos1[0]) ** 2
    y = (pos2[1] - pos1[1]) ** 2
    return (x + y) ** 0.5


def rgb_rand():
    return (random.random() * 255, random.random() * 255, random.random() * 255)


def accel(speed, dist, acc):
    speed2 = 0
    if 2 * acc * dist > speed**2:
        speed2 = 10000000000
    return speed2


x = 0
y = 0
n = 300

for j in range(10):
    for i in range(10):
        planets.append(
            [
                random.random() * 10000 + x,
                random.random() * 10000 + y,
                random.random() * 30 + 3,
                {"sun": False, "scrap": 10},
                rgb_rand(),
            ]
        )
    planets.append(
        [
            5000 + x,
            5000 + y,
            n,
            {"sun": True, "scrap": 10},
            (255, 255, 0),
        ]
    )
    x = random.random() * 400000 - 200000
    y = random.random() * 400000 - 200000
    n = random.random() * 300 + 150


def add_line(
    screen,
    text,
    x,
    y,
    color=(0, 0, 0),
    size=30,
    font2=pygame.font.Font("freesansbold.ttf", 20),
):
    # used to print the status of the variables
    text = font2.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text, text_rect)


posx = 0
posy = 0

zoom = 1

speed = 10

held = False

ship_select = -1

time1 = 0

light_speed = 100

# Run until the user asks to quit
running = True
while running:
    # Fill the background with white
    screen.fill((0, 0, 0))
    keys = pygame.key.get_pressed()
    mx, my = pygame.mouse.get_pos()
    mouse_held = pygame.mouse.get_pressed()

    if not mouse_held[0]:
        held = False

    time1 += 1

    if select_line == -1:
        if keys[pygame.K_w]:
            posy -= speed * zoom
        if keys[pygame.K_s]:
            posy += speed * zoom
        if keys[pygame.K_a]:
            posx -= speed * zoom
        if keys[pygame.K_d]:
            posx += speed * zoom
        if keys[pygame.K_e]:
            zoom *= 0.97
        if keys[pygame.K_r]:
            zoom /= 0.97

    if ship_select == -1:
        select_line = -1

    if ship_select > -1:
        if len(ships[ship_select][7]) > select_line > -1:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_BACKSPACE:
                        if (
                            len(ships[ship_select][7][select_line]) == 0
                            and len(ships[ship_select][7]) > 1
                        ):
                            ships[ship_select][7].remove(
                                ships[ship_select][7][select_line]
                            )
                            select_line -= 1
                        else:
                            ships[ship_select][7][select_line] = ships[ship_select][7][
                                select_line
                            ][:-1]
                    elif event.key == pygame.K_RETURN:
                        ships[ship_select][7].append("")
                        select_line += 1
                    elif event.unicode:
                        ships[ship_select][7][select_line] += event.unicode

    if mouse_held[0] and not held and ship_select < 0:
        for i in ships:
            if (
                dis(((i[0] - posx) / zoom + 900, (i[1] - posy) / zoom + 450), (mx, my))
                < 20
                and i[9] == name
            ):
                ship_select = ships.index(i)
        held = True

    if mouse_held[2]:
        ship_select = -1

    if mouse_held[0] and not held and ship_select >= 0 and mx > 600:
        ships[ship_select][6][0] = (mx - 900) * zoom + posx
        ships[ship_select][6][1] = (my - 450) * zoom + posy
        held = True

    # Did the user click the window close button?
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    for i in ships:
        for j in i[5].keys():
            if i[5][j][0] > i[4]:
                i[5][j][0] = i[4]

        speed_modifier = 0

        if (
            "engine" in i[5]
            and "energy" in i[5]
            and i[5]["engine"][1]
            and i[5]["energy"][1]
        ):
            if i[5]["energy"][0] > i[5]["engine"][0] / 1000:
                if dis((i[0], i[1]), (i[6][0], i[6][1])) > 1:
                    i[5]["energy"][0] -= i[5]["engine"][0] / 1000
                speed_modifier = i[5]["engine"][0] / 10000

        if "engine" in i[5] and i[5]["engine"][1]:
            if dis((i[0], i[1]), (i[6][0], i[6][1])) > dis(
                (i[0] + i[2], i[1] + i[3]), (i[6][0], i[6][1])
            ):
                prefx = (
                    (i[6][0] - i[0])
                    / dis((i[0], i[1]), (i[6][0], i[6][1]))
                    * accel(
                        dis((i[2], i[3]), (0, 0)),
                        dis((i[0], i[1]), (i[6][0], i[6][1])),
                        speed_modifier,
                    )
                )
                prefy = (
                    (i[6][1] - i[1])
                    / dis((i[0], i[1]), (i[6][0], i[6][1]))
                    * accel(
                        dis((i[2], i[3]), (0, 0)),
                        dis((i[0], i[1]), (i[6][0], i[6][1])),
                        speed_modifier,
                    )
                )
            else:
                prefx = 0.0000001
                prefy = 0.0000001
            i[2] += (prefx - i[2]) / dis((i[2], i[3]), (prefx, prefy)) * speed_modifier
            i[3] += (prefy - i[3]) / dis((i[2], i[3]), (prefx, prefy)) * speed_modifier

        try:
            i[0] += (
                i[2]
                / 5
                * light_speed
                / dis((0, 0), (i[2] / 5, i[3] / 5))
                * dis((0, 0), (i[2] / 5, i[3] / 5))
                / (dis((0, 0), (i[2] / 5, i[3] / 5)) + light_speed)
            )
            i[1] += (
                i[3]
                / 5
                * light_speed
                / dis((0, 0), (i[2] / 5, i[3] / 5))
                * dis((0, 0), (i[2] / 5, i[3] / 5))
                / (dis((0, 0), (i[2] / 5, i[3] / 5)) + light_speed)
            )
        except:
            pass

        max_en = 1

        if "energy" in i[5] and i[5]["energy"][1]:
            if "battery" in i[5] and i[5]["battery"][1]:
                max_en += i[5]["battery"][0]
        if (
            "solar" in i[5]
            and "energy" in i[5]
            and i[5]["energy"][1]
            and i[5]["solar"][1]
        ):
            if i[5]["energy"][0] < max_en:
                sol_it = 0
                for j in planets:
                    if j[3]["sun"]:
                        sol_it += (
                            1 / dis((i[0], i[1]), (j[0], j[1])) ** 2 * 300 * j[2] * 3
                        )
                i[5]["energy"][0] += i[5]["solar"][0] * sol_it
        if "energy" in i[5] and i[5]["energy"][1]:
            if i[5]["energy"][0] > max_en:
                i[5]["energy"][0] = max_en

        if (
            "energy" in i[5]
            and i[5]["energy"][1]
            and "weapons" in i[5]
            and i[5]["weapons"][1]
        ):
            try:
                if i[5]["energy"][0] > 1000 / i[5]["weapons"][0] and time1 % 100 == 0:
                    i[5]["energy"][0] -= 1000 / i[5]["weapons"][0]
                    beams.append([i[0], i[1], i[2], i[3], i[9], 0, 0])
            except:
                pass

        if (
            "energy" in i[5]
            and i[5]["energy"][1]
            and "scrap" in i[5]
            and i[5]["scrap"][1]
            and "factory" in i[5]
            and i[5]["factory"][1]
        ):
            for j in planets:
                if not j[3]["sun"]:
                    if dis((i[0], i[1]), (j[0], j[1])) < j[2]:
                        if i[5]["energy"][0] > i[5]["factory"][0] / 50:
                            if j[3]["scrap"] > 0:
                                i[5]["scrap"][0] += i[5]["factory"][0] / 500
                                i[5]["energy"][0] -= i[5]["factory"][0] / 50
                                j[3]["scrap"] -= i[5]["factory"][0] / 25000

        if (
            "energy" in i[5]
            and i[5]["energy"][1]
            and "computer" in i[5]
            and i[5]["computer"][1]
            and i[5]["energy"][0] > i[5]["computer"][0] / 100
            and time1 % int(500 / i[5]["computer"][0] + 1) == 0
        ):
            i[5]["energy"][0] -= i[5]["computer"][0] / 100
            if i[8] > len(i[7]) - 1:
                i[8] = 0
            line = i[7][i[8]].split(" ")
            send = False
            try:
                if line[0] == "goto":
                    i[8] = int(line[1]) - 1
                    send = True
                elif line[0] == "if":
                    if line[1] in i[5]:
                        if line[2] == "goto":
                            if i[5][line[1]][1]:
                                i[8] = int(line[3]) - 1
                                send = True
                        elif line[2] == ">":
                            if i[5][line[1]][0] > int(line[3]) and line[4] == "goto":
                                i[8] = int(line[5]) - 1
                                send = True
                        elif line[2] == "<":
                            if i[5][line[1]][0] < int(line[3]) and line[4] == "goto":
                                i[8] = int(line[5]) - 1
                                send = True
                    elif line[1] == "at":
                        if line[2] == "planet":
                            s = False
                            for k in planets:
                                if dis((i[0], i[1]), (k[0], k[1])) < k[2]:
                                    s = True
                            if s:
                                if line[3] == "goto":
                                    i[8] = int(line[4]) - 1
                                    send = True
                    elif line[3] == "<":
                        a = compair(line, i)
                        if line[5] != "goto":
                            b = compair([0, line[4], line[5]], i)
                            if a < b and line[6] == "goto":
                                i[8] = int(line[7]) - 1
                                send = True
                        else:
                            b = int(line[4])
                            if a < b and line[5] == "goto":
                                i[8] = int(line[6]) - 1
                                send = True
                    elif line[3] == ">":
                        a = compair(line, i)
                        if line[5] != "goto":
                            b = compair([0, line[4], line[5]], i)
                            if a > b and line[6] == "goto":
                                i[8] = int(line[7]) - 1
                                send = True
                        else:
                            b = int(line[4])
                            if a > b and line[5] == "goto":
                                i[8] = int(line[6]) - 1
                                send = True
                    elif line[1] == "health":
                        if line[2] == ">":
                            if i[4] > int(line[3]) and line[4] == "goto":
                                i[8] = int(line[5]) - 1
                                send = True
                        elif line[2] == "<":
                            if i[4] < int(line[3]) and line[4] == "goto":
                                i[8] = int(line[5]) - 1
                                send = True
                elif line[0] == "set":
                    if line[1] in i[5]:
                        if line[2] == "on":
                            i[5][line[1]][1] = True
                        elif line[2] == "off":
                            i[5][line[1]][1] = False
                elif line[0] == "build":
                    if line[1] in i[5]:
                        if (
                            "scrap" in i[5]
                            and i[5]["scrap"][1]
                            and "factory" in i[5]
                            and i[5]["factory"][1]
                            and i[5]["scrap"][0] > i[5]["factory"][0] / 10
                            and i[5][line[1]][0] < i[4]
                        ):
                            i[5][line[1]][0] += i[5]["factory"][0] / 20
                            i[5]["scrap"][0] -= i[5]["factory"][0] / 10
                elif line[0] == "plate":
                    if (
                        "scrap" in i[5]
                        and i[5]["scrap"][1]
                        and "factory" in i[5]
                        and i[5]["factory"][1]
                        and i[5]["scrap"][0] > i[5]["factory"][0] / 10
                        and i[4] < 300
                    ):
                        i[4] += i[5]["factory"][0] / 20
                        i[5]["scrap"][0] -= i[5]["factory"][0] / 10
                elif line[0] == "construct":
                    if (
                        "scrap" in i[5]
                        and i[5]["scrap"][1]
                        and "factory" in i[5]
                        and i[5]["factory"][1]
                        and i[5]["scrap"][0] > 80
                    ):
                        i[5]["scrap"][0] -= 80
                        x = i[0] + random.random() * 10
                        y = i[1] + random.random() * 10
                        ships.append(
                            [
                                x,
                                y,
                                0,
                                0,
                                100,
                                {
                                    "solar": [20, True],
                                    "engine": [10, True],
                                    "energy": [0, True],
                                    "battery": [10, True],
                                    "factory": [10, True],
                                    "computer": [10, True],
                                    "scrap": [0, True],
                                    "weapons": [0, False],
                                },
                                [x, y],
                                copy.deepcopy(i[7]),
                                0,
                                i[9],
                            ]
                        )
                elif line[0] == "travel":
                    if "engine" in i[5] and i[5]["engine"][1]:
                        if line[1] == "nearest" and line[2] == "planet":
                            k = [1000000, 1000000]
                            for j in planets:
                                if not j[3]["sun"] and dis(k, (i[0], i[1])) > dis(
                                    (i[0], i[1]), (j[0], j[1])
                                ):
                                    k = [j[0] + random.random(), j[1] + random.random()]
                            i[6] = k
                        elif line[1] == "farthest" and line[2] == "planet":
                            k = [i[0], i[1]]
                            for j in planets:
                                if not j[3]["sun"] and dis(k, (i[0], i[1])) < dis(
                                    (i[0], i[1]), (j[0], j[1])
                                ):
                                    k = [j[0] + random.random(), j[1] + random.random()]
                            i[6] = k
                        if line[1] == "nearest" and line[2] == "enemy":
                            k = [1000000, 1000000]
                            for j in ships:
                                if (
                                    dis(k, (i[0], i[1]))
                                    > dis((i[0], i[1]), (j[0], j[1]))
                                    and dis((i[0], i[1]), (j[0], j[1])) > 0
                                    and j[9] != i[9]
                                ):
                                    k = [j[0] + random.random(), j[1] + random.random()]
                            i[6] = k
                        elif line[1] == "farthest" and line[2] == "enemy":
                            k = [i[0], i[1]]
                            for j in ships:
                                if (
                                    dis(k, (i[0], i[1]))
                                    < dis((i[0], i[1]), (j[0], j[1]))
                                    and dis((i[0], i[1]), (j[0], j[1])) > 0
                                    and j[9] != i[9]
                                ):
                                    k = [j[0] + random.random(), j[1] + random.random()]
                            i[6] = k
                        elif line[1] == "nearest" and line[2] == "sun":
                            k = [1000000, 1000000]
                            for j in planets:
                                if j[3]["sun"] and dis(k, (i[0], i[1])) > dis(
                                    (i[0], i[1]), (j[0], j[1])
                                ):
                                    k = [j[0] + random.random(), j[1] + random.random()]
                            i[6] = k
                        elif line[1] == "farthest" and line[2] == "sun":
                            k = [i[0], i[1]]
                            for j in planets:
                                if j[3]["sun"] and dis(k, (i[0], i[1])) < dis(
                                    (i[0], i[1]), (j[0], j[1])
                                ):
                                    k = [j[0] + random.random(), j[1] + random.random()]
                            i[6] = k
                        elif line[1] == "random" and line[2] == "planet":
                            k = []
                            for j in planets:
                                if not j[3]["sun"]:
                                    k.append(
                                        [j[0] + random.random(), j[1] + random.random()]
                                    )
                            i[6] = random.choice(k)
                        elif line[1] == "random" and line[2] == "enemy":
                            k = []
                            for j in ships:
                                if dis((i[0], i[1]), (j[0], j[1])) > 0 and j[9] != i[9]:
                                    k.append(
                                        [j[0] + random.random(), j[1] + random.random()]
                                    )
                            i[6] = random.choice(k)
                        elif line[1] == "random" and line[2] == "sun":
                            k = []
                            for j in planets:
                                if j[3]["sun"]:
                                    k.append(
                                        [j[0] + random.random(), j[1] + random.random()]
                                    )
                            i[6] = random.choice(k)
                        elif line[1] == "stop":
                            i[6] = [i[0], i[1]]
            except:
                pass
            if not send:
                i[8] = (i[8] + 1) % len(i[7])
        if i[4] <= 0:
            if ships.index(i) == ship_select:
                ship_select = -1
            ships.remove(i)

    for i in beams:
        die = False
        try:
            i[0] += (
                i[2]
                / 5
                * light_speed
                / dis((0, 0), (i[2] / 5, i[3] / 5))
                * dis((0, 0), (i[2] / 5, i[3] / 5))
                / (dis((0, 0), (i[2] / 5, i[3] / 5)) + light_speed)
            )
            i[1] += (
                i[3]
                / 5
                * light_speed
                / dis((0, 0), (i[2] / 5, i[3] / 5))
                * dis((0, 0), (i[2] / 5, i[3] / 5))
                / (dis((0, 0), (i[2] / 5, i[3] / 5)) + light_speed)
            )
        except:
            pass
        l1 = [100000000, 100000000]
        for j in ships:
            if dis((i[0], i[1]), (j[0], j[1])) < 150 and i[4] != j[9]:
                j[4] -= 30.251
                die = True
            if dis(l1, (i[0], i[1])) > dis((i[0], i[1]), (j[0], j[1])) and i[4] != j[9]:
                l1 = [j[0], j[1]]

        i[2] += (l1[0] - i[0]) / dis(l1, (i[0], i[1])) / 10
        i[3] += (l1[1] - i[1]) / dis(l1, (i[0], i[1])) / 10
        i[5] = (l1[0] - i[0]) / dis(l1, (i[0], i[1]))
        i[6] = (l1[1] - i[1]) / dis(l1, (i[0], i[1]))

        if random.random() > 0.99975 or die:
            beams.remove(i)

    if len(beams) > 100:
        beams.remove(random.choice(beams))

    for i in planets:
        pygame.draw.circle(
            screen,
            (128, 128, 128),
            ((i[0] - posx) / zoom + 900, (i[1] - posy) / zoom + 450),
            i[2] / zoom + 1,
        )
        pygame.draw.circle(
            screen,
            i[4],
            ((i[0] - posx) / zoom + 900, (i[1] - posy) / zoom + 450),
            i[2] * i[3]["scrap"] / 10 / zoom + 1,
        )
        if i[3]["scrap"] < 10:
            i[3]["scrap"] += 0.002 * i[2] / 15

    for i in ships:
        if ships.index(i) == ship_select:
            map1 = pygame.Rect(
                (i[0] - posx) / zoom + 900 - 4 - 10,
                (i[1] - posy) / zoom + 450 - 4 - 10,
                28,
                28,
            )
            pygame.draw.rect(screen, (0, 128, 0), map1)
        color = (255, 0, 0)
        if i[9] == name:
            color = (255, 255, 255)
        map1 = pygame.Rect(
            (i[0] - posx) / zoom + 900 - i[4] / 10,
            (i[1] - posy) / zoom + 450 - i[4] / 10,
            i[4] / 5,
            i[4] / 5,
        )
        pygame.draw.rect(screen, color, map1)

    for i in beams:
        map1 = pygame.Rect(
            (i[0] - posx) / zoom + 900 - 5, (i[1] - posy) / zoom + 450 - 5, 10, 10
        )
        pygame.draw.rect(screen, (100, 100, 100), map1)
        pygame.draw.line(
            screen,
            (255, 255, 0),
            ((i[0] - posx) / zoom + 900, (i[1] - posy) / zoom + 450),
            (
                (i[0] - posx) / zoom + 900 - i[5] * 20,
                (i[1] - posy) / zoom + 450 - i[6] * 20,
            ),
        )

    try:
        if ships[ship_select][9] != name:
            ship_select = -1
    except:
        ship_select = -1

    if ship_select > -1 and ship_select < len(ships):
        map1 = pygame.Rect(0, 0, 600, 900)
        pygame.draw.rect(screen, (100, 100, 100), map1)
        items = []
        for i in ships[ship_select][5].keys():
            items.append(i)
        for i in range(len(ships[ship_select][5].keys())):
            map1 = pygame.Rect(
                0,
                i * 30 + 30,
                ships[ship_select][5][items[i]][0] / ships[ship_select][4] * 100,
                10,
            )
            pygame.draw.rect(screen, colors[items[i]], map1)

            map1 = pygame.Rect(
                300,
                i * 30 + 30,
                50,
                20,
            )
            pygame.draw.rect(screen, colors[items[i]], map1)

            map1 = pygame.Rect(
                300 + ships[ship_select][5][items[i]][1] * 30 - 2,
                i * 30 - 2 + 30,
                24,
                24,
            )
            pygame.draw.rect(screen, (255, 255, 255), map1)

            if mouse_held[0] and not held:
                if 300 < mx < 350 and i * 30 + 30 + 20 > my > i * 30 + 30:
                    ships[ship_select][5][items[i]][1] = not ships[ship_select][5][
                        items[i]
                    ][1]
                    held = True

        n = 0
        a = True
        for k in ships[ship_select][7]:
            if select_line == int(n / 20):
                map1 = pygame.Rect(50, 300 + n, 500, 20)
                pygame.draw.rect(screen, (255, 200, 0), map1)
            else:
                map1 = pygame.Rect(50, 300 + n, 500, 20)
                pygame.draw.rect(screen, (128, 128, 128), map1)
            add_line(screen, str(int(n / 20) + 1), 20, 300 + n)
            add_line(screen, k, 50, 300 + n)
            if mouse_held[0] and not held:
                if 50 < mx and n + 300 + 20 > my > 300 + n:
                    select_line = int(n / 20)
                    held = True
                    a = False
            else:
                a = False
            if ships[ship_select][8] == int(n / 20):
                map1 = pygame.Rect(5, 300 + n + 5, 10, 10)
                pygame.draw.rect(screen, (255, 200, 0), map1)
            n += 20
        if a:
            select_line = -1
    else:
        ship_select = -1

    clock.tick(60)

    # Flip the display
    pygame.display.flip()

# Done! Time to quit.
pygame.quit()
